package com.xenon.gui;

import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_408;

public class XenonChatScreen extends class_408 {

    public XenonChatScreen(String originalChatText) {
        super(originalChatText, false);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean bl) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();
        if (button == 0) {
            if (com.xenon.module.modules.client.SpotifyHud.handleClick(mouseX, mouseY)) {
                return true;
            }
            if (HudEditor.INSTANCE.onMouseClick(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.method_25402(click, bl);
    }

    @Override
    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        if (HudEditor.INSTANCE.isDragging()) {
            HudEditor.INSTANCE.onMouseDrag(click.comp_4798(), click.comp_4799());
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        HudEditor.INSTANCE.onMouseRelease();
        return super.method_25406(click);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        HudEditor.INSTANCE.render(context, mouseX, mouseY);
    }
}
