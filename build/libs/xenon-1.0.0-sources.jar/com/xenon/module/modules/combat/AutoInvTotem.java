package com.xenon.module.modules.combat;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import java.util.Random;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_490;

public final class AutoInvTotem extends Module {
    private final Setting<Float> delay = new Setting<>("Delay", 2.0f, 0.0f, 20.0f);
    private final Setting<Boolean> hotbar = new Setting<>("Hotbar", false);
    private final Setting<Float> totemSlot = new Setting<>("Totem Slot", 1.0f, 1.0f, 9.0f);
    private final Setting<Boolean> forceTotem = new Setting<>("Force Totem", false);
    private final Setting<Boolean> autoOpen = new Setting<>("Auto Open", false);
    private final Setting<Float> closeDelay = new Setting<>("Close Delay", 3.0f, 0.0f, 20.0f);

    
    private static final int STATE_IDLE = 0;
    private static final int STATE_WAIT_OPEN = 1; 
    private static final int STATE_INV_OPEN = 2; 
    private static final int STATE_SWAPPED = 3; 

    private int state = STATE_IDLE;
    private int tickCounter = 0;
    private boolean wasTotemInOffhand = true; 
    private final Random random = new Random();

    public AutoInvTotem() {
        super("Auto Inv Totem", Category.COMBAT);
        this.addSetting(this.delay);
        this.addSetting(this.hotbar);
        this.addSetting(this.totemSlot);
        this.addSetting(this.forceTotem);
        this.addSetting(this.autoOpen);
        this.addSetting(this.closeDelay);
    }

    @Override
    public void onEnable() {
        this.state = STATE_IDLE;
        this.tickCounter = 0;
        this.wasTotemInOffhand = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        this.state = STATE_IDLE;
        this.tickCounter = 0;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (this.mc.field_1724 == null || this.mc.field_1761 == null) {
            return;
        }

        final class_1661 inv = this.mc.field_1724.method_31548();
        final boolean totemInOffhand = this.mc.field_1724.method_6079().method_7909() == class_1802.field_8288;

        
        if (this.autoOpen.getValue()) {
            this.handleAutoOpen(inv, totemInOffhand);
            this.wasTotemInOffhand = totemInOffhand;
            return;
        }

        
        this.wasTotemInOffhand = totemInOffhand;

        if (!(this.mc.field_1755 instanceof class_490)) {
            this.tickCounter = 0;
            return;
        }

        
        if (this.tickCounter < this.delay.getValue().intValue() + randomJitter()) {
            this.tickCounter++;
            return;
        }

        
        if (!totemInOffhand) {
            if (this.swapTotemToOffhand(inv)) {
                this.tickCounter = 0;
                return;
            }
        }

        
        if (this.hotbar.getValue()) {
            this.tryHotbarTotem(inv);
        }

        this.tickCounter = 0;
    }

    




    private void handleAutoOpen(final class_1661 inv, final boolean totemInOffhand) {
        switch (this.state) {
            case STATE_IDLE:
                
                if (this.wasTotemInOffhand && !totemInOffhand) {
                    
                    if (this.findTotemSlot(inv) != -1) {
                        this.state = STATE_WAIT_OPEN;
                        
                        
                        this.tickCounter = this.delay.getValue().intValue() <= 0 ? 1 + random.nextInt(2)
                                : 1 + random.nextInt(3);
                    }
                }

                
                if (!totemInOffhand && this.state == STATE_IDLE
                        && !(this.mc.field_1755 instanceof class_490)) {
                    if (this.findTotemSlot(inv) != -1) {
                        this.state = STATE_WAIT_OPEN;
                        this.tickCounter = this.delay.getValue().intValue() <= 0 ? 1 + random.nextInt(2)
                                : 1 + random.nextInt(3);
                    }
                }
                break;

            case STATE_WAIT_OPEN:
                if (this.tickCounter > 0) {
                    this.tickCounter--;
                    return;
                }
                
                if (!(this.mc.field_1755 instanceof class_490)) {
                    
                    
                    
                    
                    this.mc.method_1507(new class_490(this.mc.field_1724));
                }
                this.state = STATE_INV_OPEN;
                
                this.tickCounter = this.delay.getValue().intValue() + randomJitter();
                break;

            case STATE_INV_OPEN:
                
                if (!(this.mc.field_1755 instanceof class_490)) {
                    
                    this.state = STATE_IDLE;
                    return;
                }

                if (this.tickCounter > 0) {
                    this.tickCounter--;
                    return;
                }

                
                boolean didSwapOffhand = false;
                if (!totemInOffhand) {
                    didSwapOffhand = this.swapTotemToOffhand(inv);
                }

                boolean didSwapHotbar = false;
                if (this.hotbar.getValue()) {
                    didSwapHotbar = this.tryHotbarTotem(inv);
                }

                if (didSwapOffhand || didSwapHotbar || totemInOffhand) {
                    this.state = STATE_SWAPPED;
                    
                    this.tickCounter = this.closeDelay.getValue().intValue() + randomJitter();
                } else {
                    
                    this.state = STATE_SWAPPED;
                    this.tickCounter = 1;
                }
                break;

            case STATE_SWAPPED:
                if (this.tickCounter > 0) {
                    this.tickCounter--;
                    return;
                }

                
                if (this.mc.field_1755 instanceof class_490) {
                    this.mc.field_1724.method_7346();
                    this.mc.method_1507(null);
                }

                this.state = STATE_IDLE;
                break;
        }
    }

    












    private boolean swapTotemToOffhand(final class_1661 inv) {
        final int invSlot = this.findTotemSlot(inv);
        if (invSlot == -1) {
            return false;
        }

        
        final int handlerSlot = convertToHandlerSlot(invSlot);

        
        this.mc.field_1761.method_2906(
                this.mc.field_1724.field_7512.field_7763,
                handlerSlot,
                40, 
                class_1713.field_7791,
                this.mc.field_1724);

        return true;
    }

    


    private boolean tryHotbarTotem(final class_1661 inv) {
        final int preferredSlot = this.totemSlot.getValue().intValue() - 1; 

        
        if (inv.method_5438(preferredSlot).method_7909() == class_1802.field_8288) {
            return false;
        }

        
        if (!inv.method_5438(preferredSlot).method_7960() && !this.forceTotem.getValue()) {
            return false;
        }

        
        final int totemSlotIdx = this.findTotemSlotMainOnly(inv);
        if (totemSlotIdx == -1) {
            return false;
        }

        final int handlerSlot = convertToHandlerSlot(totemSlotIdx);

        this.mc.field_1761.method_2906(
                this.mc.field_1724.field_7512.field_7763,
                handlerSlot,
                preferredSlot, 
                class_1713.field_7791,
                this.mc.field_1724);

        return true;
    }

    



    private int findTotemSlot(final class_1661 inv) {
        
        for (int i = 9; i < 36; i++) {
            if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
                return i;
            }
        }
        
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
                return i;
            }
        }
        return -1;
    }

    


    private int findTotemSlotMainOnly(final class_1661 inv) {
        for (int i = 9; i < 36; i++) {
            if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
                return i;
            }
        }
        return -1;
    }

    




    private static int convertToHandlerSlot(final int invSlot) {
        if (invSlot < 9) {
            return 36 + invSlot;
        }
        return invSlot;
    }

    


    private int randomJitter() {
        
        if (this.delay.getValue().intValue() <= 0) {
            return 0;
        }
        return random.nextInt(2);
    }
}
