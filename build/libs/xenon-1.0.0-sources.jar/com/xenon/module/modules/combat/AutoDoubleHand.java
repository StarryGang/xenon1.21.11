package com.xenon.module.modules.combat;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import net.minecraft.class_1661;
import net.minecraft.class_1802;

public final class AutoDoubleHand extends Module {

    private final Setting<Boolean> onTotemPop = new Setting<>("On Totem Pop", true);
    private final Setting<Boolean> onHealth = new Setting<>("On Health", true);
    private final Setting<Float> healthThreshold = new Setting<>("Health Threshold", 6.0f, 1.0f, 20.0f);
    private final Setting<Float> cooldown = new Setting<>("Cooldown", 5.0f, 0.0f, 40.0f);

    private boolean hadTotemHeldLastTick = false;
    private int cooldownTicks = 0;
    private int previousSlot = -1;

    public AutoDoubleHand() {
        super("AutoDoubleHand", Category.COMBAT);
        addSetting(onTotemPop);
        addSetting(onHealth);
        addSetting(healthThreshold);
        addSetting(cooldown);
    }

    @Override
    public void onEnable() {
        hadTotemHeldLastTick = false;
        cooldownTicks = 0;
        previousSlot = -1;
    }

    @Override
    public void onDisable() {
        hadTotemHeldLastTick = false;
        cooldownTicks = 0;
        previousSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        if (cooldownTicks > 0) cooldownTicks--;

        class_1661 inv = mc.field_1724.method_31548();
        boolean totemMain = mc.field_1724.method_6047().method_7909() == class_1802.field_8288;
        boolean totemOff  = mc.field_1724.method_6079().method_7909() == class_1802.field_8288;
        boolean totemHeld = totemMain || totemOff;

        boolean popped = hadTotemHeldLastTick && !totemHeld;
        hadTotemHeldLastTick = totemHeld;

        if (cooldownTicks > 0) return;

        boolean shouldSwitch = false;
        if (onTotemPop.getValue() && popped) shouldSwitch = true;
        if (onHealth.getValue() && mc.field_1724.method_6032() <= healthThreshold.getValue()) shouldSwitch = true;

        if (!shouldSwitch) return;

        if (totemMain) return;

        int hotbarSlot = findHotbarTotemSlot();
        if (hotbarSlot < 0) return;
        if (inv.method_67532() == hotbarSlot) return;

        previousSlot = inv.method_67532();
        inv.method_61496(hotbarSlot);
        cooldownTicks = cooldown.getValue().intValue();
    }

    private int findHotbarTotemSlot() {
        class_1661 inv = mc.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) return i;
        }
        return -1;
    }
}
