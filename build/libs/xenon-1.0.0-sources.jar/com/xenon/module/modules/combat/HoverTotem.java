package com.xenon.module.modules.combat;

import com.xenon.mixin.HandledScreenAccessor;
import com.xenon.module.Category;
import com.xenon.module.Module;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_465;




public final class HoverTotem extends Module {

    
    private int lastSwapAttemptHandlerSlotId = -1;

    public HoverTotem() {
        super("Hover Totem", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        lastSwapAttemptHandlerSlotId = -1;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        if (!(mc.field_1755 instanceof class_465<?> handled)) {
            lastSwapAttemptHandlerSlotId = -1;
            return;
        }

        class_1735 focused = ((HandledScreenAccessor) handled).xenon$getFocusedSlot();
        if (focused == null || focused.method_7677().method_7960()) {
            lastSwapAttemptHandlerSlotId = -1;
            return;
        }

        if (!focused.method_7677().method_31574(class_1802.field_8288)) {
            lastSwapAttemptHandlerSlotId = -1;
            return;
        }

        if (mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            return;
        }

        if (focused.field_7874 == lastSwapAttemptHandlerSlotId) {
            return;
        }

        int syncId = mc.field_1724.field_7512.field_7763;
        mc.field_1761.method_2906(syncId, focused.field_7874, 40, class_1713.field_7791, mc.field_1724);
        lastSwapAttemptHandlerSlotId = focused.field_7874;
    }
}
