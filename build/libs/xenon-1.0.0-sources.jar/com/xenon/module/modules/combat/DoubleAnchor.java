package com.xenon.module.modules.combat;

import com.xenon.module.Category;
import com.xenon.module.ActivatableModule;
import com.xenon.setting.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2749;
import net.minecraft.class_3965;









public final class DoubleAnchor extends ActivatableModule {

    private final Setting<Float> switchDelay = new Setting<>("Delay", 0.0f, 0.0f, 20.0f);
    
    private final Setting<Float> totemSlot = new Setting<>("Totem Slot", 1.0f, 1.0f, 9.0f);
    
    private final Setting<Boolean> switchBack = new Setting<>("Switch Back", false);

    private int delayCounter = 0;
    private int step = 0;
    private boolean isAnchoring = false;
    
    private class_2338 lastAnchorPos = null;
    
    private boolean waitingForPop = false;

    public DoubleAnchor() {
        super("Double Anchor", Category.COMBAT);
        addSetting(switchDelay);
        addSetting(totemSlot);
        addSetting(switchBack);
    }

    @Override
    public void onEnable() {
        resetState();
        isAnchoring = false;
        waitingForPop = false;
        lastAnchorPos = null;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        resetState();
        isAnchoring = false;
        waitingForPop = false;
        lastAnchorPos = null;
        super.onDisable();
    }

    


    @Override
    public void onBindPressed() {
        super.onBindPressed();
    }

    


    @Override
    public void onActivationKeyPressed() {
        
        if (!isEnabled()) return;

        resetState();
        isAnchoring = true;
        waitingForPop = false;
        lastAnchorPos = null;
    }

    @Override
    public void onPacketReceive(class_2596<?> packet) {
        
        
        if (switchBack.getValue() && waitingForPop && packet instanceof class_2749) {
            waitingForPop = false;
            if (mc.field_1724 != null) {
                int anchorSlot = findItemInHotbar(class_1802.field_23141);
                if (anchorSlot != -1) {
                    mc.field_1724.method_31548().method_61496(anchorSlot);
                }
            }
        }
    }

    @Override
    public void onTick() {
        
        if (!isAnchoring) return;

        if (mc.field_1755 != null) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!hasRequiredItems()) {
            isAnchoring = false;
            resetState();
            return;
        }

        if (!(mc.field_1765 instanceof class_3965 blockHitResult)) {
            isAnchoring = false;
            resetState();
            return;
        }

        
        if (mc.field_1687.method_8320(blockHitResult.method_17777()).method_27852(class_2246.field_10124)) {
            isAnchoring = false;
            resetState();
            return;
        }

        int switchDelayTicks = Math.max(0, switchDelay.getValue().intValue());
        if (delayCounter < switchDelayTicks) {
            delayCounter++;
            return;
        }

        
        if (step == 0) {
            swapToItem(class_1802.field_23141);
        } else if (step == 1) {
            interactWithBlock(blockHitResult);
        } else if (step == 2) {
            swapToItem(class_1802.field_8801);
        } else if (step == 3) {
            interactWithBlock(blockHitResult);
        } else if (step == 4) {
            swapToItem(class_1802.field_23141);
        } else if (step == 5) {
            
            interactWithBlock(blockHitResult);
            interactWithBlock(blockHitResult);
        } else if (step == 6) {
            swapToItem(class_1802.field_8801);
        } else if (step == 7) {
            interactWithBlock(blockHitResult);
        } else if (step == 8) {
            int desiredSlot = totemSlot.getValue().intValue() - 1;
            swapToHotbarSlot(desiredSlot);
            
            lastAnchorPos = blockHitResult.method_17777();
        } else if (step == 9) {
            interactWithBlock(blockHitResult);
            
            if (switchBack.getValue()) {
                waitingForPop = true;
            }
        } else if (step == 10) {
            
            isAnchoring = false;
            resetState();
            return;
        }

        step++;
    }

    private void resetState() {
        delayCounter = 0;
        step = 0;
    }

    private boolean hasRequiredItems() {
        boolean hasAnchor = false;
        boolean hasGlowstone = false;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_23141)) hasAnchor = true;
            if (stack.method_31574(class_1802.field_8801)) hasGlowstone = true;
        }
        return hasAnchor && hasGlowstone;
    }

    private int findItemInHotbar(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) return i;
        }
        return -1;
    }

    private void swapToItem(class_1792 item) {
        int slot = findItemInHotbar(item);
        if (slot != -1) mc.field_1724.method_31548().method_61496(slot);
    }

    private void swapToHotbarSlot(int slot) {
        if (slot < 0 || slot > 8) return;
        mc.field_1724.method_31548().method_61496(slot);
    }

    private void interactWithBlock(class_3965 hit) {
        
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }
}
