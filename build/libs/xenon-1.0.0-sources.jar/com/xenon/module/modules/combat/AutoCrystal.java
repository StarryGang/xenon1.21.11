package com.xenon.module.modules.combat;

import com.xenon.module.Category;
import com.xenon.module.ActivatableModule;
import com.xenon.setting.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public final class AutoCrystal extends ActivatableModule {
    private static final double RANGE = 5.0;

    private final Setting<Float> placeDelay = new Setting<>("Place Delay", 0.0f, 0.0f, 20.0f);
    private final Setting<Float> breakDelay = new Setting<>("Break Delay", 0.0f, 0.0f, 20.0f);

    private int placeDelayCounter;
    private int breakDelayCounter;

    public AutoCrystal() {
        super("Auto Crystal", Category.COMBAT);
        addSetting(placeDelay);
        addSetting(breakDelay);
    }

    @Override
    public void onEnable() {
        resetCounters();
        super.onEnable();
    }

    @Override
    public void onTick() {
        if (mc.field_1755 != null) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        updateCounters();

        
        if (!isRightClickHeld()) {
            resetCounters();
            return;
        }

        
        class_1297 nearestCrystal = null;
        double minDistance = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e instanceof class_1511) {
                double d = mc.field_1724.method_5739(e);
                if (d <= RANGE && d < minDistance) {
                    minDistance = d;
                    nearestCrystal = e;
                }
            }
        }

        if (nearestCrystal != null && breakDelayCounter == 0) {
            mc.field_1761.method_2918(mc.field_1724, nearestCrystal);
            mc.field_1724.method_6104(class_1268.field_5808);
            breakDelayCounter = Math.max(0, breakDelay.getValue().intValue());
        }

        
        if (!(mc.field_1765 instanceof class_3965 blockHitResult)) return;
        if (blockHitResult.method_17783() != class_239.class_240.field_1332) return;

        class_2338 pos = blockHitResult.method_17777();
        if (mc.field_1724.method_5707(pos.method_46558()) > RANGE * RANGE) return;

        
        
        
        if (!isValidCrystalPlacement(pos)) return;

        
        mc.field_1690.field_1904.method_23481(false);

        int crystalSlot = findHotbarSlot(class_1802.field_8301);
        if (crystalSlot == -1) return;

        
        if (mc.field_1724.method_6047().method_7909() != class_1802.field_8301) {
            mc.field_1724.method_31548().method_61496(crystalSlot);
        }

        if (placeDelayCounter == 0) {
            interactWithBlock(blockHitResult);
            placeDelayCounter = Math.max(0, placeDelay.getValue().intValue());
        }
    }

    private boolean isRightClickHeld() {
        return mc.method_22683() != null
                && GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    private void resetCounters() {
        placeDelayCounter = 0;
        breakDelayCounter = 0;
    }

    private void updateCounters() {
        if (placeDelayCounter > 0) placeDelayCounter--;
        if (breakDelayCounter > 0) breakDelayCounter--;
    }

    private int findHotbarSlot(net.minecraft.class_1792 item) {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(item)) return i;
        }
        return -1;
    }

    private boolean isValidCrystalPlacement(class_2338 blockPos) {
        if (!mc.field_1687.method_8320(blockPos).method_27852(class_2246.field_10540)
                && !mc.field_1687.method_8320(blockPos).method_27852(class_2246.field_9987)) {
            return false;
        }

        class_2338 up = blockPos.method_10084();
        if (!mc.field_1687.method_22347(up)) return false;

        int getX = up.method_10263();
        int getY = up.method_10264();
        int compareTo = up.method_10260();

        class_238 box = new class_238(getX, getY, compareTo, getX + 1.0, getY + 2.0, compareTo + 1.0);
        return mc.field_1687.method_8335(null, box).isEmpty();
    }

    private void interactWithBlock(class_3965 hit) {
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }
}
