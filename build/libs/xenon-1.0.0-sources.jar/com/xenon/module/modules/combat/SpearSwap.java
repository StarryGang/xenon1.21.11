package com.xenon.module.modules.combat;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import net.minecraft.class_1661;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class SpearSwap extends Module {

    public static SpearSwap INSTANCE;

    private final Setting<Boolean> lunge = new Setting<>("Lunge", true);
    private final Setting<Boolean> sharpness = new Setting<>("Sharpness", false);
    private final Setting<Boolean> onlySword = new Setting<>("Only Sword", false);
    private final Setting<Boolean> onlyAxe = new Setting<>("Only Axe", false);
    private final Setting<Boolean> switchBack = new Setting<>("Switch Back", true);
    private final Setting<Float> switchDelay = new Setting<>("Switch Delay", 1.0f, 1.0f, 20.0f);

    private int previousSlot = -1;
    private int countdown = 0;
    private boolean attackHeldLastCheck = false;

    public SpearSwap() {
        super("SpearSwap", Category.COMBAT);
        addSetting(lunge);
        addSetting(sharpness);
        addSetting(onlySword);
        addSetting(onlyAxe);
        addSetting(switchBack);
        addSetting(switchDelay);
        INSTANCE = this;
    }

    /** Called from MinecraftClientAttackMixin every frame while attack key is held.
     *  Only swaps on the rising edge (just-pressed) and waits for countdown between swaps. */
    public void preAttack() {
        if (mc.field_1724 == null) return;
        boolean wasHeld = attackHeldLastCheck;
        attackHeldLastCheck = true;
        if (wasHeld) return;
        if (countdown > 0) return;
        class_1661 inv = mc.field_1724.method_31548();
        int slot = findBestWeaponSlot();
        if (slot < 0) return;
        if (inv.method_67532() == slot) return;
        previousSlot = inv.method_67532();
        inv.method_61496(slot);
        countdown = Math.max(1, switchDelay.getValue().intValue());
    }

    /** Called when attack key is NOT held — resets the rising-edge tracker. */
    public void noAttack() {
        attackHeldLastCheck = false;
    }

@Override
    public void onEnable() {
        previousSlot = -1;
        countdown = 0;
    }

    @Override
    public void onDisable() {
        previousSlot = -1;
        countdown = 0;
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1690 == null) return;
        class_1661 inv = mc.field_1724.method_31548();

        // Switch-back countdown
        if (countdown > 0) {
            countdown--;
            if (countdown == 0) {
                if (switchBack.getValue() && previousSlot >= 0 && previousSlot < 9
                        && inv.method_67532() != previousSlot) {
                    inv.method_61496(previousSlot);
                }
                previousSlot = -1;
            }
        }

        // Backup trigger via tick polling, in case the mixin doesn't fire on this client.
        if (mc.field_1690.field_1886.method_1434()) {
            preAttack();
        } else {
            noAttack();
        }
    }

    private int findBestWeaponSlot() {
        class_1661 inv = mc.field_1724.method_31548();
        boolean swordOnly = onlySword.getValue();
        boolean axeOnly = onlyAxe.getValue();
        boolean wantLunge = lunge.getValue();
        boolean wantSharp = sharpness.getValue();

        int bestSlot = -1;
        int bestScore = Integer.MIN_VALUE;

        for (int i = 0; i < 9; i++) {
            class_1799 s = inv.method_5438(i);
            if (s.method_7960()) continue;

            String path = class_7923.field_41178.method_10221(s.method_7909()).method_12832();
            String displayName = "";
            try { displayName = s.method_7964().getString().toLowerCase(); } catch (Throwable ignored) {}

            boolean isSword = path.endsWith("_sword");
            boolean isAxe = s.method_7909() instanceof class_1743;
            boolean isSpear = s.method_7909() == class_1802.field_8547
                    || s.method_7909() == class_1802.field_49814
                    || path.contains("spear")
                    || displayName.contains("spear");
            boolean hasLunge = hasLungeEnchant(s);

            // Anything that has a lunge enchant counts as a valid swap target.
            boolean lungeItem = wantLunge && hasLunge;

            if (swordOnly && !isSword) continue;
            if (axeOnly && !isAxe) continue;
            if (!swordOnly && !axeOnly && !isSword && !isAxe && !isSpear && !lungeItem) continue;

            int score = 0;
            if (lungeItem) score += 500;
            if (isSpear) score += 300;
            else if (isSword) score += 200;
            else if (isAxe) score += 100;
            if (wantSharp) score += sharpnessLevel(s) * 60;

            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    private boolean hasLungeEnchant(class_1799 s) {
        try {
            class_9304 comp = s.method_58694(class_9334.field_49633);
            if (comp == null) return false;
            for (class_6880<class_1887> entry : comp.method_57534()) {
                // Vanilla enchants
                class_5321<class_1887> key = entry.method_40230().orElse(null);
                if (key != null) {
                    if (key.equals(class_1893.field_50159)
                            || key.equals(class_1893.field_50157)
                            || key.equals(class_1893.field_9104)) {
                        return true;
                    }
                    // Custom enchants on servers (e.g. donut "lunge")
                    String idPath = key.method_29177().toString().toLowerCase();
                    if (idPath.contains("lunge")) return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private int sharpnessLevel(class_1799 s) {
        try {
            class_9304 comp = s.method_58694(class_9334.field_49633);
            if (comp == null) return 0;
            for (class_6880<class_1887> entry : comp.method_57534()) {
                class_5321<class_1887> key = entry.method_40230().orElse(null);
                if (key != null && key.equals(class_1893.field_9118)) {
                    return comp.method_57536(entry);
                }
            }
        } catch (Throwable ignored) {}
        return 0;
    }
}
