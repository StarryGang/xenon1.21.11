package com.xenon.module.modules.client;

import com.xenon.gui.CloudConfigScreen;
import com.xenon.module.Category;
import com.xenon.module.Module;

public final class CloudConfigs extends Module {

    public CloudConfigs() {
        super("Cloud Configs", Category.CLIENT);
    }

    @Override
    public void onEnable() {
        if (mc == null) return;
        mc.execute(() -> mc.method_1507(new CloudConfigScreen(this)));
    }

    @Override
    public void onDisable() {
        if (mc != null && mc.field_1755 instanceof CloudConfigScreen) {
            mc.execute(() -> mc.method_1507(null));
        }
    }
}
