package com.xenon.module.modules.misc;

import com.xenon.XenonClient;
import com.xenon.gui.ClickGUI;
import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.render.Freecam;
import com.xenon.setting.Setting;
import com.xenon.utils.NametagRenderState;
import com.xenon.utils.RenderUtils;
import com.xenon.utils.renderer.ProjectionUtil;
import org.joml.Matrix3x2fStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.class_10799;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_9064;

public final class NameTags extends Module {

    private static final float MAX_RENDER_DISTANCE = 64.0f;
    private static final boolean SHOW_ABSORPTION = true;
    private static final int HUD_TEXT_COLOR = 0xFFFFFFFF;
    private static final int HUD_OUTLINE_COLOR = 0xFF000000;
    private static final float HUD_WORLD_SCALE = 0.025f;
    private static final int HUD_OUTLINE_RADIUS = 1;
    private static final int HUD_NAME_OFFSET = 0;
    private static final int HUD_HEALTH_OFFSET_WITH_NAME = 10;
    private static final int HUD_HEALTH_OFFSET_NO_NAME = 0;
    private static final int HUD_ITEM_SIZE = 16;
    private static final int HUD_ITEM_GAP = 2;
    private static final int HUD_ITEM_ROW_OFFSET_WITH_HEALTH = 34;
    private static final int HUD_ITEM_ROW_OFFSET_WITH_NAME = 16;
    private static final int HUD_ITEM_ROW_OFFSET_NO_TEXT = 0;
    private static final double HUD_ANCHOR_Y_ADJUST = 0.62;
    private static final double HUD_FRUSTUM_Y_PADDING = 1.25D;
    private static final long HUD_CACHE_DURATION_MS = 125L;
    private static final int HEART_ICON_SIZE = 9;
    private static final int HEART_ICON_SPACING = 8;
    private static final class_2960 HEART_CONTAINER_TEXTURE = class_2960.method_60656("hud/heart/container");
    private static final class_2960 HEART_FULL_TEXTURE = class_2960.method_60656("hud/heart/full");
    private static final class_2960 HEART_HALF_TEXTURE = class_2960.method_60656("hud/heart/half");
    private static final class_2960 HEART_ABS_FULL_TEXTURE = class_2960.method_60656("hud/heart/absorbing_full");
    private static final class_2960 HEART_ABS_HALF_TEXTURE = class_2960.method_60656("hud/heart/absorbing_half");
    private static final Pattern MINECRAFT_COLOR_CODE_PATTERN = Pattern.compile("\u00A7.");

    public static NameTags instance;

    private final Setting<Boolean> self = new Setting<>("Self", true);
    private final Setting<Boolean> name = new Setting<>("Name", true);
    private final Setting<Boolean> ping = new Setting<>("Ping", true);
    private final Setting<Boolean> health = new Setting<>("Health", true);
    private final Setting<Boolean> mainHand = new Setting<>("MainHand", true);
    private final Setting<Boolean> offHand = new Setting<>("OffHand", true);
    private final Setting<Boolean> armor = new Setting<>("Armor", true);
    private final Map<UUID, CachedHudData> hudCache = new HashMap<>();
    private final ProjectionUtil.ScreenProjection screenProjection = new ProjectionUtil.ScreenProjection();
    private int hudConfigSignature = Integer.MIN_VALUE;

    public NameTags() {
        super("NameTags", Category.MISC);
        instance = this;
        addSetting(self);
        addSetting(name);
        addSetting(ping);
        addSetting(health);
        addSetting(mainHand);
        addSetting(offHand);
        addSetting(armor);
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && mc != null && mc.field_1724 != null;
    }

    public static void renderHud(class_332 context, float tickDelta) {
        if (!isActive() || mc.field_1687 == null || mc.field_1690.field_1842 || isMenuOpen()) {
            return;
        }

        NameTags module = instance;
        if (module == null) {
            return;
        }

        module.ensureHudCacheConfig();
        module.pruneHudCacheIfNeeded();

        long now = System.currentTimeMillis();
        class_4184 camera = RenderUtils.getCamera();
        if (camera == null) {
            return;
        }

        class_243 cameraPos = RenderUtils.getCameraPos(camera);
        double cameraX = cameraPos.field_1352;
        double cameraY = cameraPos.field_1351;
        double cameraZ = cameraPos.field_1350;
        double maxDistanceSq = MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE;
        double scaleBaseX = mc.method_22683().method_4486() * 0.5D * Math.abs(ProjectionUtil.projectionMatrix.m00()) * HUD_WORLD_SCALE;
        double scaleBaseY = mc.method_22683().method_4502() * 0.5D * Math.abs(ProjectionUtil.projectionMatrix.m11()) * HUD_WORLD_SCALE;
        Matrix3x2fStack matrices = context.method_51448();

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (!module.shouldRenderFor(player)) {
                continue;
            }

            double worldX = class_3532.method_16436(tickDelta, player.field_6038, player.method_23317());
            double worldY = class_3532.method_16436(tickDelta, player.field_5971, player.method_23318());
            double worldZ = class_3532.method_16436(tickDelta, player.field_5989, player.method_23321());
            double deltaX = worldX - cameraX;
            double deltaY = worldY - cameraY;
            double deltaZ = worldZ - cameraZ;
            double squaredDistance = (deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ);
            if (squaredDistance > maxDistanceSq) {
                continue;
            }

            CachedHudData hudData = module.getCachedHudData(player, now);
            if (hudData.isEmpty()) {
                continue;
            }

            double halfWidth = Math.max(0.35D, player.method_17681() * 0.5D);
            if (!RenderUtils.isWorldBoxVisible(
                    worldX - halfWidth,
                    worldY,
                    worldZ - halfWidth,
                    worldX + halfWidth,
                    worldY + player.method_17682() + HUD_FRUSTUM_Y_PADDING,
                    worldZ + halfWidth
            )) {
                continue;
            }

            float hudScale = module.projectHudAnchor(player, tickDelta, worldX, worldY, worldZ, scaleBaseX, scaleBaseY);
            if (hudScale <= 0.0f) {
                continue;
            }

            matrices.pushMatrix();
            applyHudTransform(matrices, (float) module.screenProjection.x, (float) module.screenProjection.y, hudScale);
            renderHudLabel(context, hudData.nameLabel(), hudData.nameWidth(), HUD_NAME_OFFSET, false);
            renderHudHealth(
                    context,
                    hudData.healthData(),
                    hudData.nameLabel() != null ? HUD_HEALTH_OFFSET_WITH_NAME : HUD_HEALTH_OFFSET_NO_NAME
            );
            renderHudItems(context, hudData.items(), hudData.itemRowWidth(), hudData.nameLabel() != null, hudData.healthData() != null);
            matrices.popMatrix();
        }
    }

    public boolean shouldRenderFor(class_1309 entity) {
        if (!entity.method_5805() || entity instanceof class_1531 || !(entity instanceof class_1657)) {
            return false;
        }

        if (entity != mc.field_1724 && entity.method_5756(mc.field_1724)) {
            return false;
        }

        if (entity == mc.field_1724) {
            return self.getValue() && (!mc.field_1690.method_31044().method_31034()
                    || (Freecam.instance != null && Freecam.instance.isEnabled()));
        }

        return true;
    }

    public boolean shouldRenderForState(class_1309 entity, double squaredDistanceToCamera) {
        if (!shouldRenderFor(entity) || isMenuOpen()) {
            return false;
        }

        return squaredDistanceToCamera <= (double) (MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE);
    }

    @Override
    public void onEnable() {
        hudCache.clear();
        hudConfigSignature = Integer.MIN_VALUE;
    }

    @Override
    public void onDisable() {
        hudCache.clear();
    }

    @Override
    public void onTick() {
    }

    public class_2561 buildNameLabel(class_1309 entity) {
        class_5250 text = class_2561.method_43473();
        boolean hasContent = false;

        if (name.getValue()) {
            text.method_10852(class_2561.method_43470("| ").method_27692(class_124.field_1062));
            text.method_10852(entity.method_5476().method_27661().method_27692(class_124.field_1068));
            hasContent = true;
        }

        if (ping.getValue() && entity instanceof class_1657 player) {
            int latency = getPing(player);
            if (latency >= 0) {
                if (hasContent) {
                    text.method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1080));
                }

                text.method_10852(class_2561.method_43470("[").method_27692(class_124.field_1063));
                text.method_10852(class_2561.method_43470(latency + " ms").method_27692(getPingFormatting(latency)));
                text.method_10852(class_2561.method_43470("]").method_27692(class_124.field_1063));
                hasContent = true;
            }
        }

        if (health.getValue()) {
            float absorption = SHOW_ABSORPTION ? Math.max(0.0f, entity.method_6067()) : 0.0f;
            if (absorption > 0.0f) {
                int abs = Math.max(1, class_3532.method_15386(absorption));
                if (hasContent) {
                    text.method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1080));
                }
                text.method_10852(class_2561.method_43470("+" + abs).method_27692(class_124.field_1065));
                hasContent = true;
            }
        }

        return hasContent ? text : null;
    }

    private HealthRenderData getHealthRenderData(class_1309 entity) {
        if (!health.getValue()) {
            return null;
        }

        float maxHealth = Math.max(1.0f, entity.method_6063());
        float currentHealth = class_3532.method_15363(entity.method_6032(), 0.0f, maxHealth);
        float absorption = SHOW_ABSORPTION ? Math.max(0.0f, entity.method_6067()) : 0.0f;

        int maxHearts = Math.max(1, class_3532.method_15386(maxHealth / 2.0f));
        if (maxHearts > 10) {
            float scale = 10.0f / (float) maxHearts;
            currentHealth *= scale;
            absorption *= scale;
            maxHearts = 10;
        }

        int filledHalfHearts = class_3532.method_15340(Math.round(currentHealth), 0, maxHearts * 2);
        int fullHearts = filledHalfHearts / 2;
        boolean halfHeart = (filledHalfHearts & 1) != 0;
        int emptyHearts = Math.max(0, maxHearts - fullHearts - (halfHeart ? 1 : 0));

        int absorptionHalfHearts = Math.max(0, Math.round(absorption));
        int absorptionFullHearts = absorptionHalfHearts / 2;
        boolean absorptionHalfHeart = (absorptionHalfHearts & 1) != 0;

        int iconCount = maxHearts + absorptionFullHearts + (absorptionHalfHeart ? 1 : 0);
        if (fullHearts <= 0 && !halfHeart && absorptionFullHearts <= 0 && !absorptionHalfHeart && emptyHearts <= 0) {
            return null;
        }

        int totalWidth = ((iconCount - 1) * HEART_ICON_SPACING) + HEART_ICON_SIZE;
        return new HealthRenderData(maxHearts, fullHearts, halfHeart, emptyHearts, absorptionFullHearts, absorptionHalfHeart, totalWidth);
    }

    public List<NametagRenderState.ItemEntry> buildItemEntries(class_1309 entity) {
        List<NametagRenderState.ItemEntry> items = new ArrayList<>(6);

        if (offHand.getValue()) {
            addItem(items, entity.method_6079());
        }

        if (armor.getValue()) {
            addItem(items, entity.method_6118(class_1304.field_6166));
            addItem(items, entity.method_6118(class_1304.field_6172));
            addItem(items, entity.method_6118(class_1304.field_6174));
            addItem(items, entity.method_6118(class_1304.field_6169));
        }

        if (mainHand.getValue()) {
            addItem(items, entity.method_6047());
        }

        return items;
    }

    private void addItem(List<NametagRenderState.ItemEntry> items, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return;
        }

        items.add(new NametagRenderState.ItemEntry(stack.method_7972()));
    }

    private static void renderHudItems(
            class_332 context,
            List<NametagRenderState.ItemEntry> items,
            int rowWidth,
            boolean hasNameLabel,
            boolean hasHealthLabel
    ) {
        if (items.isEmpty()) {
            return;
        }

        int startX = -(rowWidth / 2);
        int offset = hasHealthLabel
                ? HUD_ITEM_ROW_OFFSET_WITH_HEALTH
                : hasNameLabel ? HUD_ITEM_ROW_OFFSET_WITH_NAME : HUD_ITEM_ROW_OFFSET_NO_TEXT;
        int y = -offset;

        for (int index = 0; index < items.size(); index++) {
            class_1799 stack = items.get(index).stack();
            int x = startX + (index * (HUD_ITEM_SIZE + HUD_ITEM_GAP));
            context.method_51427(stack, x, y);
            context.method_51432(mc.field_1772, stack, x, y, null);
        }
    }

    private static void renderHudLabel(
            class_332 context,
            class_2561 text,
            int textWidth,
            int yOffset,
            boolean outlined
    ) {
        if (text == null) {
            return;
        }

        int x = -(textWidth / 2);
        int y = -yOffset;

        if (outlined) {
            String plain = text.getString();
            for (int offsetX = -HUD_OUTLINE_RADIUS; offsetX <= HUD_OUTLINE_RADIUS; offsetX++) {
                for (int offsetY = -HUD_OUTLINE_RADIUS; offsetY <= HUD_OUTLINE_RADIUS; offsetY++) {
                    if (offsetX == 0 && offsetY == 0) {
                        continue;
                    }

                    context.method_51433(mc.field_1772, plain, x + offsetX, y + offsetY, HUD_OUTLINE_COLOR, false);
                }
            }
        }
        context.method_51439(mc.field_1772, text, x, y, HUD_TEXT_COLOR, false);
    }

    private static void renderHudHealth(
            class_332 context,
            HealthRenderData healthData,
            int yOffset
    ) {
        if (healthData == null) {
            return;
        }

        int x = -(healthData.totalWidth() / 2);
        int y = -yOffset;

        for (int index = 0; index < healthData.baseHeartCount(); index++) {
            int heartX = x + (index * HEART_ICON_SPACING);
            drawHeart(context, HEART_CONTAINER_TEXTURE, heartX, y);
        }

        for (int index = 0; index < healthData.fullHearts(); index++) {
            int heartX = x + (index * HEART_ICON_SPACING);
            drawHeart(context, HEART_FULL_TEXTURE, heartX, y);
        }

        if (healthData.halfHeart()) {
            int heartX = x + (healthData.fullHearts() * HEART_ICON_SPACING);
            drawHeart(context, HEART_HALF_TEXTURE, heartX, y);
        }

        int absorptionStart = x + (healthData.baseHeartCount() * HEART_ICON_SPACING);
        int absorptionIcons = healthData.absorptionFullHearts() + (healthData.absorptionHalfHeart() ? 1 : 0);
        for (int index = 0; index < absorptionIcons; index++) {
            int heartX = absorptionStart + (index * HEART_ICON_SPACING);
            drawHeart(context, HEART_CONTAINER_TEXTURE, heartX, y);
        }
        for (int index = 0; index < healthData.absorptionFullHearts(); index++) {
            int heartX = absorptionStart + (index * HEART_ICON_SPACING);
            drawHeart(context, HEART_ABS_FULL_TEXTURE, heartX, y);
        }

        if (healthData.absorptionHalfHeart()) {
            int heartX = absorptionStart + (healthData.absorptionFullHearts() * HEART_ICON_SPACING);
            drawHeart(context, HEART_ABS_HALF_TEXTURE, heartX, y);
        }
    }

    private static void drawHeart(class_332 context, class_2960 texture, int x, int y) {
        context.method_52706(class_10799.field_56883, texture, x, y, HEART_ICON_SIZE, HEART_ICON_SIZE);
    }

    private void ensureHudCacheConfig() {
        int currentSignature = getHudConfigSignature();
        if (currentSignature != hudConfigSignature) {
            hudConfigSignature = currentSignature;
            hudCache.clear();
        }
    }

    private void pruneHudCacheIfNeeded() {
        if (mc.field_1687 == null || hudCache.size() <= mc.field_1687.method_18456().size() + 8) {
            return;
        }

        hudCache.keySet().removeIf(uuid -> mc.field_1687.method_18470(uuid) == null);
    }

    private int getHudConfigSignature() {
        int signature = 0;
        if (self.getValue()) signature |= 1;
        if (name.getValue()) signature |= 1 << 1;
        if (ping.getValue()) signature |= 1 << 2;
        if (health.getValue()) signature |= 1 << 3;
        if (mainHand.getValue()) signature |= 1 << 4;
        if (offHand.getValue()) signature |= 1 << 5;
        if (armor.getValue()) signature |= 1 << 6;
        return signature;
    }

    private CachedHudData getCachedHudData(class_1657 player, long now) {
        CachedHudData cached = hudCache.get(player.method_5667());
        if (cached != null && cached.expiresAtMs() > now) {
            return cached;
        }

        class_2561 nameLabel = buildNameLabel(player);
        List<NametagRenderState.ItemEntry> items = buildItemEntries(player);
        CachedHudData rebuilt = new CachedHudData(
                now + HUD_CACHE_DURATION_MS,
                nameLabel,
                nameLabel != null ? mc.field_1772.method_27525(nameLabel) : 0,
                getHealthRenderData(player),
                items,
                items.isEmpty() ? 0 : (items.size() * HUD_ITEM_SIZE) + ((items.size() - 1) * HUD_ITEM_GAP)
        );
        hudCache.put(player.method_5667(), rebuilt);
        return rebuilt;
    }

    private static void applyHudTransform(Matrix3x2fStack matrices, float screenX, float screenY, float scale) {
        matrices.translate(screenX, screenY);
        matrices.scale(scale, scale);
    }

    private float projectHudAnchor(class_1657 player, float tickDelta, double worldX, double worldY, double worldZ, double scaleBaseX, double scaleBaseY) {
        class_243 localAnchor = player.method_56072()
                .method_55675(class_9064.field_47745, 0, player.method_61415(tickDelta));

        double anchorX;
        double anchorY;
        double anchorZ;
        if (localAnchor == null) {
            anchorX = worldX;
            anchorY = worldY + player.method_17682() + 0.5 + HUD_ANCHOR_Y_ADJUST;
            anchorZ = worldZ;
        } else {
            anchorX = worldX + localAnchor.field_1352;
            anchorY = worldY + localAnchor.field_1351 + HUD_ANCHOR_Y_ADJUST;
            anchorZ = worldZ + localAnchor.field_1350;
        }

        if (!ProjectionUtil.projectToScreen(
                ProjectionUtil.modelViewMatrix,
                ProjectionUtil.projectionMatrix,
                anchorX,
                anchorY,
                anchorZ,
                screenProjection
        )) {
            return 0.0f;
        }

        if (!screenProjection.visible || screenProjection.z < 0.0 || screenProjection.z > 1.0 || screenProjection.w <= 0.0) {
            return 0.0f;
        }

        double scaleX = scaleBaseX / screenProjection.w;
        double scaleY = scaleBaseY / screenProjection.w;
        float screenScale = (float) ((scaleX + scaleY) * 0.5D);
        return Float.isFinite(screenScale) && screenScale > 0.0f ? screenScale : 0.0f;
    }

    private static boolean isMenuOpen() {
        return mc.field_1755 instanceof ClickGUI;
    }

    private int getPing(class_1657 player) {
        if (mc.method_1562() == null) {
            return -1;
        }

        class_640 entry = mc.method_1562().method_2871(player.method_5667());
        return entry != null ? entry.method_2959() : -1;
    }

    private class_124 getPingFormatting(int latency) {
        if (latency < 75) {
            return class_124.field_1060;
        }
        if (latency < 150) {
            return class_124.field_1054;
        }
        return class_124.field_1061;
    }

    private String stripMinecraftFormatting(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        return MINECRAFT_COLOR_CODE_PATTERN.matcher(text).replaceAll("").trim();
    }

    private boolean containsLetters(String text) {
        for (int index = 0; index < text.length(); index++) {
            if (Character.isLetter(text.charAt(index))) {
                return true;
            }
        }
        return false;
    }

    private String sanitizeLogText(String text) {
        if (text == null) {
            return "";
        }
        return text.replace('\n', ' ').replace('\r', ' ');
    }

    private String normalizeLookupName(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private record CachedHudData(
            long expiresAtMs,
            class_2561 nameLabel,
            int nameWidth,
            HealthRenderData healthData,
            List<NametagRenderState.ItemEntry> items,
            int itemRowWidth
    ) {
        private boolean isEmpty() {
            return nameLabel == null && healthData == null && items.isEmpty();
        }
    }

    private record HealthRenderData(
            int baseHeartCount,
            int fullHearts,
            boolean halfHeart,
            int emptyHearts,
            int absorptionFullHearts,
            boolean absorptionHalfHeart,
            int totalWidth
    ) {
    }

}
