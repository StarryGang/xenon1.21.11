package com.xenon.module.modules.misc;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import net.minecraft.class_2561;
import net.minecraft.class_634;

public final class HomeSetter extends Module {

    private final Setting<Boolean> chatFeedback = new Setting<>("Chat Feedback", true);
    private final Setting<Float> homeSlot = new Setting<>("Home Slot", 1.0f, 1.0f, 5.0f);

    private volatile boolean running = false;

    public HomeSetter() {
        super("HomeSetter", Category.MISC);
        this.addSetting(chatFeedback);
        this.addSetting(homeSlot);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (running) return;
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            this.toggle();
            return;
        }

        running = true;
        final int slot = Math.round(homeSlot.getValue());
        final int wait = 750;

        mc.execute(() -> {
            sendServerCommand("/delhome " + slot);
            new Thread(() -> {
                try {
                    Thread.sleep(wait);
                } catch (InterruptedException ignored) {}
                mc.execute(() -> {
                    sendServerCommand("/sethome " + slot);
                    if (chatFeedback.getValue()) {
                        try {
                            mc.field_1705.method_1743().method_1812(
                                    class_2561.method_43470("§aHome " + slot + " deleted and set successfully!"));
                        } catch (Exception ignored) {}
                    }
                    running = false;
                    this.toggle();
                });
            }, "HomeSetter-DelayThread").start();
        });
    }

    @Override
    public void onDisable() {
        super.onDisable();
        running = false;
    }

    private void sendServerCommand(String command) {
        if (mc == null) return;
        class_634 nh = null;
        try {
            if (mc.field_1724 != null) nh = mc.field_1724.field_3944;
        } catch (Throwable ignored) {}
        if (nh == null) {
            try { nh = mc.method_1562(); } catch (Throwable ignored) {}
        }
        if (nh == null) return;

        String cmdNoSlash = command.startsWith("/") ? command.substring(1) : command;
        try {
            nh.method_45730(cmdNoSlash);
            return;
        } catch (Throwable ignored) {}
        try {
            nh.method_45729(command);
        } catch (Throwable ignored) {}
    }
}