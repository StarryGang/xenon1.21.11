package com.xenon.module.modules.misc;

import com.xenon.gui.notification.NotificationManager;
import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.ModeSetting;
import com.xenon.setting.Setting;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public final class WeatherNotifier extends Module {

    private final ModeSetting notificationMode = new ModeSetting("Notification Mode", "Both", "Chat", "Toast", "Both");
    private final Setting<Boolean> notifyThunder = new Setting<>("Notify Thunder", true);

    private Boolean wasRaining = null;
    private Boolean wasThundering = null;

    public WeatherNotifier() {
        super("WeatherNotifier", Category.MISC);
        addSetting(notificationMode);
        addSetting(notifyThunder);
    }

    @Override
    public void onEnable() {
        wasRaining = null;
        wasThundering = null;
    }

    @Override
    public void onDisable() {
        wasRaining = null;
        wasThundering = null;
    }

    @Override
    public void onTick() {
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        boolean raining = mc.field_1687.method_8419();
        boolean thundering = mc.field_1687.method_8546();

        if (wasRaining == null) {
            wasRaining = raining;
            wasThundering = thundering;
            return;
        }

        if (raining && !wasRaining) {
            notify("The rain started.", "Rain Started", 0xFF5AA9E6);
        } else if (!raining && wasRaining) {
            notify("The rain stopped.", "Rain Stopped", 0xFFFACC15);
        }

        if (notifyThunder.getValue()) {
            if (thundering && !wasThundering) {
                notify("A thunderstorm started.", "Thunder Started", 0xFFB58CFF);
            } else if (!thundering && wasThundering) {
                notify("The thunderstorm ended.", "Thunder Ended", 0xFFFACC15);
            }
        }

        wasRaining = raining;
        wasThundering = thundering;
    }

    private void notify(String chatMessage, String toastTitle, int accent) {
        String mode = notificationMode.getValue();
        boolean toChat = "Chat".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);
        boolean toToast = "Toast".equalsIgnoreCase(mode) || "Both".equalsIgnoreCase(mode);

        if (toChat) {
            try {
                mc.field_1705.method_1743().method_1812(class_2561.method_43470("[WeatherNotifier] " + chatMessage));
            } catch (Throwable ignored) {}
        }
        if (toToast) {
            NotificationManager.INSTANCE.push("WeatherNotifier", toastTitle, class_1799.field_8037, accent);
        }
    }
}
