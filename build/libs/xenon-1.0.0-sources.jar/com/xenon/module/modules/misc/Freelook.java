package com.xenon.module.modules.misc;

import com.xenon.module.Category;
import com.xenon.module.ActivatableModule;
import com.xenon.setting.ModeSetting;
import com.xenon.setting.Setting;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

public final class Freelook extends ActivatableModule {
    private static final float MIN_DISTANCE = 1.0f;
    private static final float MAX_DISTANCE = 15.0f;
    private static final float MIN_SENSITIVITY = 0.1f;
    private static final float MAX_SENSITIVITY = 3.0f;

    public static Freelook instance;

    private final ModeSetting activationMode = new ModeSetting("Mode", "Hold", new String[]{"Activation Mode"}, "Hold", "Toggle");
    private final Setting<Float> distance = new Setting<>("Distance", 4.0f, MIN_DISTANCE, MAX_DISTANCE);
    private final Setting<Boolean> wallClip = new Setting<>("Wall Clip", true);
    private final Setting<Float> sensitivity = new Setting<>("Sensitivity", 1.0f, MIN_SENSITIVITY, MAX_SENSITIVITY);
    private final Setting<Boolean> invertY = new Setting<>("Invert Y", false);

    private boolean active;
    private class_5498 savedPerspective;
    private boolean savedChunkCullingEnabled;
    private float cameraYaw;
    private float cameraPitch;


    public Freelook() {
        super("FreeLook", Category.MISC);
        instance = this;
        addSetting(activationMode);
        addSetting(distance);
        addSetting(wallClip);
        addSetting(sensitivity);
        addSetting(invertY);
    }

    @Override
    public void onEnable() {
        active = false;
        savedPerspective = null;
    }

    @Override
    public void onDisable() {
        deactivateCamera();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1690 == null || mc.method_22683() == null) {
            deactivateCamera();
            return;
        }

        if (isHoldMode()) {
            int key = getActivationKey();
            boolean pressed = key != 0 && GLFW.glfwGetKey(mc.method_22683().method_4490(), key) == GLFW.GLFW_PRESS;
            if (pressed) {
                activateCamera();
            } else {
                deactivateCamera();
            }
        } else if (active) {
            ensureCameraState();
        }
    }

    @Override
    public void onActivationKeyPressed() {
        if (!isEnabled() || isHoldMode()) {
            return;
        }

        if (active) {
            deactivateCamera();
        } else {
            activateCamera();
        }
    }

    public boolean isCameraActive() {
        return isEnabled() && active && mc.field_1724 != null;
    }

    public void consumeMouseDelta(double deltaX, double deltaY) {
        if (!isCameraActive()) {
            return;
        }

        double pitchSign = invertY.getValue() ? -1.0D : 1.0D;
        double multiplier = 0.15D * getSensitivity();
        cameraYaw = class_3532.method_15393(cameraYaw + (float) (deltaX * multiplier));
        cameraPitch = class_3532.method_15363(cameraPitch + (float) (deltaY * multiplier * pitchSign), -90.0f, 90.0f);
    }

    public float getCameraYaw() {
        return cameraYaw;
    }

    public float getCameraPitch() {
        return cameraPitch;
    }

    public float getDistance() {
        return class_3532.method_15363(distance.getValue(), MIN_DISTANCE, MAX_DISTANCE);
    }

    public boolean shouldWallClip() {
        return wallClip.getValue();
    }

    public float getSensitivity() {
        return class_3532.method_15363(sensitivity.getValue(), MIN_SENSITIVITY, MAX_SENSITIVITY);
    }

    private boolean isHoldMode() {
        return activationMode.is("Hold");
    }

    private void activateCamera() {
        if (active || mc.field_1724 == null || mc.field_1690 == null) {
            ensureCameraState();
            return;
        }

        savedPerspective = mc.field_1690.method_31044();
        savedChunkCullingEnabled = mc.field_1730;
        mc.field_1690.method_31043(class_5498.field_26665);
        mc.field_1730 = false;
        cameraYaw = mc.field_1724.method_36454();
        cameraPitch = mc.field_1724.method_36455();
        active = true;
    }

    private void ensureCameraState() {
        if (!active || mc.field_1690 == null) {
            return;
        }

        if (!mc.field_1690.method_31044().method_31035() && !mc.field_1690.method_31044().method_31034()) {
            return;
        }

        mc.field_1690.method_31043(class_5498.field_26665);
        mc.field_1730 = false;
    }

    private void deactivateCamera() {
        if (!active) {
            return;
        }

        active = false;
        if (mc.field_1690 != null) {
            mc.field_1690.method_31043(savedPerspective == null ? class_5498.field_26664 : savedPerspective);
        }
        mc.field_1730 = savedChunkCullingEnabled;
    }
}
