package com.xenon.module.modules.misc;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.client.Friends;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3966;
import net.minecraft.class_8646;
import net.minecraft.class_9011;

public final class AutoLog extends Module {

    private static final long COMBAT_COOLDOWN_MS = 20_000L;
    private static final int COMBAT_COOLDOWN_TICKS = (int) (COMBAT_COOLDOWN_MS / 50L);
    private static final double COMBAT_GRACE_RANGE = 8.0;
    private static final long SERVER_COMBAT_GRACE_MS = 1_500L;
    private static final int MAX_TEXT_SCAN_DEPTH = 4;

    private long lastHitTime;
    private long lastAttackTime;
    private long lastServerCombatTagTime;
    private float lastCombinedHealth = -1.0f;
    private int lastObservedAttackedTick = -1;
    private int lastObservedAttackTick = -1;

    public AutoLog() {
        super("AutoLog", Category.MISC);
    }

    @Override
    public void onEnable() {
        lastHitTime = 0L;
        lastAttackTime = 0L;
        lastServerCombatTagTime = 0L;
        lastCombinedHealth = getCurrentCombinedHealth();
        lastObservedAttackedTick = getCurrentAttackedTick();
        lastObservedAttackTick = getCurrentAttackTick();

        if (mc.field_1724 != null
                && mc.field_1687 != null
                && (isCombatContextPresent() || isRecentPlayerCombat() || isServerCombatTagged())) {
            startCombatCooldown(System.currentTimeMillis());
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        long now = System.currentTimeMillis();
        float currentCombinedHealth = getCurrentCombinedHealth();
        boolean tookDamage = lastCombinedHealth >= 0.0f && currentCombinedHealth + 0.001f < lastCombinedHealth;
        lastCombinedHealth = currentCombinedHealth;

        if (mc.field_1724.field_6235 > 0 || tookDamage || hasNewPlayerHit()) {
            lastHitTime = now;
        }
        boolean serverCombatTagged = isServerCombatTagged();
        if (serverCombatTagged) {
            lastServerCombatTagTime = now;
        }

        if (mc.field_1690.field_1886.method_1434()
                && mc.field_1765 != null
                && mc.field_1765.method_17783() == class_239.class_240.field_1331
                && mc.field_1765 instanceof class_3966 entityHitResult
                && entityHitResult.method_17782() instanceof class_1657 target
                && target != mc.field_1724) {
            lastAttackTime = now;
        }
        if (hasNewPlayerAttack()) {
            lastAttackTime = now;
        }

        if (isCombatCooldownActive(now, serverCombatTagged)) {
            return;
        }

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || player.method_7325()) {
                continue;
            }
            if (Friends.isAutoLog() && Friends.isFriend(player.method_5477().getString())) {
                continue;
            }

            if (mc.method_1562() != null && mc.method_1562().method_48296() != null) {
                mc.method_1562().method_48296()
                        .method_10747(class_2561.method_43470("[AutoLog] Player detected: " + player.method_5477().getString()));
                toggle();
            }
            return;
        }
    }

    private boolean isCombatCooldownActive(long now, boolean serverCombatTagged) {
        if (serverCombatTagged || isRecentPlayerCombat() || now - lastServerCombatTagTime < SERVER_COMBAT_GRACE_MS) {
            return true;
        }
        if (lastHitTime <= 0L && lastAttackTime <= 0L) {
            return false;
        }

        long lastCombatTime = Math.max(lastHitTime, lastAttackTime);
        return now - lastCombatTime < COMBAT_COOLDOWN_MS;
    }

    private boolean isCombatContextPresent() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return false;
        }
        if (mc.field_1724.field_6235 > 0 || isRecentPlayerCombat()) {
            return true;
        }
        if (mc.field_1765 != null
                && mc.field_1765.method_17783() == class_239.class_240.field_1331
                && mc.field_1765 instanceof class_3966 entityHitResult
                && entityHitResult.method_17782() instanceof class_1657 target
                && target != mc.field_1724
                && !target.method_7325()) {
            return true;
        }

        double maxDistanceSq = COMBAT_GRACE_RANGE * COMBAT_GRACE_RANGE;
        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || player.method_7325()) {
                continue;
            }
            if (mc.field_1724.method_5858(player) <= maxDistanceSq) {
                return true;
            }
        }
        return false;
    }

    private void startCombatCooldown(long now) {
        lastHitTime = now;
        lastAttackTime = now;
        lastServerCombatTagTime = now;
    }

    private boolean isRecentPlayerCombat() {
        return isRecentPlayerHit() || isRecentPlayerAttack();
    }

    private boolean hasNewPlayerHit() {
        int currentAttackedTick = getCurrentAttackedTick();
        if (currentAttackedTick <= 0 || currentAttackedTick == lastObservedAttackedTick) {
            return false;
        }

        lastObservedAttackedTick = currentAttackedTick;
        return isRecentPlayerHit();
    }

    private boolean hasNewPlayerAttack() {
        int currentAttackTick = getCurrentAttackTick();
        if (currentAttackTick <= 0 || currentAttackTick == lastObservedAttackTick) {
            return false;
        }

        lastObservedAttackTick = currentAttackTick;
        return isRecentPlayerAttack();
    }

    private boolean isRecentPlayerHit() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (!(mc.field_1724.method_49107() instanceof class_1657 attacker)
                || attacker == mc.field_1724
                || attacker.method_7325()) {
            return false;
        }
        return isRecentCombatTick(mc.field_1724.method_6117());
    }

    private boolean isRecentPlayerAttack() {
        if (mc.field_1724 == null) {
            return false;
        }
        if (!(mc.field_1724.method_6052() instanceof class_1657 target)
                || target == mc.field_1724
                || target.method_7325()) {
            return false;
        }
        return isRecentCombatTick(mc.field_1724.method_6083());
    }

    private boolean isRecentCombatTick(int tickTimestamp) {
        if (mc.field_1724 == null || tickTimestamp <= 0) {
            return false;
        }

        int elapsedTicks = mc.field_1724.field_6012 - tickTimestamp;
        return elapsedTicks >= 0 && elapsedTicks < COMBAT_COOLDOWN_TICKS;
    }

    private int getCurrentAttackedTick() {
        return mc.field_1724 != null ? mc.field_1724.method_6117() : -1;
    }

    private int getCurrentAttackTick() {
        return mc.field_1724 != null ? mc.field_1724.method_6083() : -1;
    }

    private boolean isServerCombatTagged() {
        if (mc.field_1687 != null && containsCombatScoreboardText(mc.field_1687.method_8428())) {
            return true;
        }
        Set<Object> visited = Collections.newSetFromMap(new IdentityHashMap<>());
        return mc.field_1705 != null && containsCombatText(mc.field_1705, 0, visited);
    }

    private boolean containsCombatScoreboardText(class_269 scoreboard) {
        if (scoreboard == null) {
            return false;
        }

        for (class_266 objective : scoreboard.method_1151()) {
            if (containsCombatKeyword(objective.method_1113()) || containsCombatText(objective.method_1114())) {
                return true;
            }
        }

        for (class_8646 slot : class_8646.values()) {
            class_266 objective = scoreboard.method_1189(slot);
            if (objective == null) {
                continue;
            }
            if (containsCombatKeyword(objective.method_1113()) || containsCombatText(objective.method_1114())) {
                return true;
            }

            for (class_9011 entry : scoreboard.method_1184(objective)) {
                if (containsCombatKeyword(entry.comp_2127())
                        || containsCombatText(entry.method_55387())
                        || containsCombatText(entry.comp_2129())) {
                    return true;
                }

                class_268 team = scoreboard.method_1164(entry.comp_2127());
                if (containsCombatTeamText(team)) {
                    return true;
                }
            }
        }

        for (class_268 team : scoreboard.method_1159()) {
            if (containsCombatTeamText(team)) {
                return true;
            }
        }
        return false;
    }

    private boolean containsCombatTeamText(class_268 team) {
        return team != null
                && (containsCombatKeyword(team.method_1197())
                || containsCombatText(team.method_1140())
                || containsCombatText(team.method_1144())
                || containsCombatText(team.method_1136()));
    }

    private boolean containsCombatText(Object value, int depth, Set<Object> visited) {
        if (value == null || depth > MAX_TEXT_SCAN_DEPTH) {
            return false;
        }

        if (value instanceof class_2561 text) {
            return containsCombatKeyword(text.getString());
        }
        if (value instanceof String string) {
            return containsCombatKeyword(string);
        }
        if (!visited.add(value)) {
            return false;
        }

        if (value instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (containsCombatText(entry.getKey(), depth + 1, visited)
                        || containsCombatText(entry.getValue(), depth + 1, visited)) {
                    return true;
                }
            }
            return false;
        }
        if (value instanceof Collection<?> collection) {
            for (Object element : collection) {
                if (containsCombatText(element, depth + 1, visited)) {
                    return true;
                }
            }
            return false;
        }

        Class<?> clazz = value.getClass();
        if (!isInspectableClass(clazz)) {
            return false;
        }

        Class<?> current = clazz;
        while (current != null && current != Object.class) {
            for (Field field : current.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers()) || field.getType().isPrimitive()) {
                    continue;
                }

                field.setAccessible(true);
                try {
                    Object fieldValue = field.get(value);
                    if (containsCombatText(fieldValue, depth + 1, visited)) {
                        return true;
                    }
                } catch (IllegalAccessException ignored) {
                }
            }
            current = current.getSuperclass();
        }
        return false;
    }

    private boolean isInspectableClass(Class<?> clazz) {
        String name = clazz.getName();
        return name.startsWith("net.minecraft.scoreboard.")
                || name.startsWith("net.minecraft.text.")
                || name.startsWith("net.minecraft.client.gui.hud.")
                || name.startsWith("net.minecraft.client.network.")
                || name.startsWith("java.util.");
    }

    private boolean containsCombatKeyword(String value) {
        if (value == null) {
            return false;
        }
        String lower = value.toLowerCase();
        return lower.contains("combat");
    }

    private boolean containsCombatText(class_2561 text) {
        return text != null && containsCombatKeyword(text.getString());
    }

    private float getCurrentCombinedHealth() {
        if (mc.field_1724 == null) {
            return -1.0f;
        }
        return mc.field_1724.method_6032() + mc.field_1724.method_6067();
    }
}
