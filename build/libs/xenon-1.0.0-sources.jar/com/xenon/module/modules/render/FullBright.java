package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.minecraft.class_7172;

public final class FullBright extends Module {

    private static final double FULL_BRIGHT_GAMMA = 10.0;

    private double previousGamma = 1.0;
    private boolean gammaApplied = false;

    private static Field valueField;

    public FullBright() {
        super("FullBright", Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (mc.field_1690 == null) return;
        previousGamma = mc.field_1690.method_42473().method_41753();
        setGamma(FULL_BRIGHT_GAMMA);
        gammaApplied = true;
    }

    @Override
    public void onDisable() {
        if (!gammaApplied) return;
        setGamma(previousGamma);
        gammaApplied = false;
    }

    @Override
    public void onTick() {
        if (!gammaApplied || mc.field_1690 == null) {
            return;
        }

        try {
            double current = mc.field_1690.method_42473().method_41753();
            if (Math.abs(current - FULL_BRIGHT_GAMMA) > 1.0E-4D) {
                setGamma(FULL_BRIGHT_GAMMA);
            }
        } catch (Exception ignored) {
        }
    }

    private void setGamma(double gamma) {
        class_7172<Double> opt = mc.field_1690.method_42473();
        Field field = valueField;
        if (field == null) {
            field = resolveValueField(opt);
            valueField = field;
        }
        if (field != null) {
            try {
                field.set(opt, gamma);
                Double applied = opt.method_41753();
                if (applied != null && Math.abs(applied - gamma) <= 1.0E-4D) {
                    return;
                }
                valueField = null;
            } catch (Exception ignored) {
            }
        }
        try {
            opt.method_41748(gamma);
        } catch (Exception ignored) {
        }
    }

    private Field resolveValueField(class_7172<?> option) {
        Object current;
        try {
            current = option.method_41753();
        } catch (Exception ignored) {
            current = null;
        }

        Field fallback = null;
        for (Field field : class_7172.class.getDeclaredFields()) {
            if (Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            if ("value".equals(field.getName())) {
                fallback = field;
            }
            field.setAccessible(true);
            try {
                Object value = field.get(option);
                if (current == null ? value == null : current.equals(value)) {
                    return field;
                }
            } catch (Exception ignored) {
            }
        }

        if (fallback != null) {
            fallback.setAccessible(true);
            return fallback;
        }
        return null;
    }
}
