package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.client.XenonPlus;
import com.xenon.setting.MobsSetting;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class MobESP extends Module {

    private static final double TRACER_START_DISTANCE = 150.0D;
    private static final double TRACER_END_DISTANCE = 24.0D;
    private static final double TRACER_BEHIND_MIN_SPREAD = 2.75D;

    private final MobsSetting mobs = new MobsSetting("Mobs");
    private final Setting<Double> alpha = new Setting<>("Alpha", 100.0, 0.0, 255.0);
    private final Setting<Double> range = new Setting<>("Range", 128.0, 16.0, 512.0);
    private final Setting<Boolean> tracers = new Setting<>("Tracers", false);
    private final Setting<Color> outlineColor = new Setting<>("Outline color", new Color(255, 80, 80));
    private final Setting<Color> fillColor = new Setting<>("Fill color", new Color(255, 80, 80));
    private final Setting<Color> tracerColor = new Setting<>("Tracer color", new Color(255, 80, 80));

    public MobESP() {
        super("Mob ESP", Category.RENDER);
        addSetting(mobs);
        addSetting(alpha);
        addSetting(range);
        addSetting(tracers);
        addSetting(outlineColor);
        addSetting(fillColor);
        addSetting(tracerColor);
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        Set<net.minecraft.class_1299<?>> targets = mobs.getSelectedMobs();
        if (targets.isEmpty()) return;

        class_4184 cam = RenderUtils.getCamera();
        if (cam == null) return;

        class_243 camPos = RenderUtils.getCameraPos(cam);
        double camX = camPos.field_1352, camY = camPos.field_1351, camZ = camPos.field_1350;
        double maxRangeSq = range.getValue() * range.getValue();
        int alphaValue = clampAlpha(alpha.getValue());
        boolean renderTracers = tracers.getValue();
        Color boxColor = applyOpacity(outlineColor.getValue(), alphaValue);
        Color fill = applyOpacity(fillColor.getValue(), Math.max(0, alphaValue / 3));
        Color tracer = renderTracers ? applyOpacity(tracerColor.getValue(), 255) : null;

        class_243 cameraForward = renderTracers ? RenderUtils.getCameraForward(cam) : null;
        class_243 cameraRight = renderTracers ? RenderUtils.getCameraRight(cam) : null;
        class_243 cameraUp = renderTracers ? RenderUtils.getCameraUp(cameraForward, cameraRight) : null;
        class_243 tracerStart = renderTracers ? cameraForward.method_1021(TRACER_START_DISTANCE) : null;

        List<RenderData> renderData = new ArrayList<>();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724) continue;
            if (entity instanceof class_1657) continue;
            if (!(entity instanceof class_1309) || !entity.method_5805()) continue;
            if (!targets.contains(entity.method_5864())) continue;

            class_243 lerped = getLerpedPosCompat(entity, tickDelta);
            double dx = lerped.field_1352 - camX;
            double dy = lerped.field_1351 - camY;
            double dz = lerped.field_1350 - camZ;
            double distSq = dx * dx + dy * dy + dz * dz;
            if (distSq > maxRangeSq) continue;

            double halfWidth = entity.method_17681() / 2.0D;
            double height = entity.method_17682();
            double tracerTargetY = dy + height * 0.5D;
            renderData.add(new RenderData(dx, dy, dz, tracerTargetY, halfWidth, height));
        }

        if (renderData.isEmpty()) return;

        matrices.method_22903();
        RenderUtils.WorldBatch boxBatch = RenderUtils.beginWorldBatch(matrices);
        for (RenderData d : renderData) {
            boxBatch.renderOutlineBox(
                    d.dx - d.halfWidth, d.dy, d.dz - d.halfWidth,
                    d.dx + d.halfWidth, d.dy + d.height, d.dz + d.halfWidth,
                    boxColor);
            boxBatch.renderFilledBox(
                    d.dx - d.halfWidth, d.dy, d.dz - d.halfWidth,
                    d.dx + d.halfWidth, d.dy + d.height, d.dz + d.halfWidth,
                    fill);
        }
        boxBatch.flush();

        if (renderTracers) {
            RenderUtils.WorldBatch tb = RenderUtils.beginWorldBatch(matrices);
            for (RenderData d : renderData) {
                class_243 tracerEnd = RenderUtils.getSpreadTracerEnd(
                        d.dx, d.tracerTargetY, d.dz,
                        cameraForward, cameraRight, cameraUp,
                        TRACER_END_DISTANCE, TRACER_BEHIND_MIN_SPREAD);
                tb.renderLine(tracer, tracerStart, tracerEnd, XenonPlus.tracerLineWidth());
            }
            tb.flush();
        }

        matrices.method_22909();
    }

    private int clampAlpha(double value) {
        int a = (int) Math.round(value);
        return Math.max(0, Math.min(255, a));
    }

    private Color applyOpacity(Color base, int alphaValue) {
        int combined = Math.max(0, Math.min(255, Math.round((base.getAlpha() / 255.0f) * alphaValue)));
        return new Color(base.getRed(), base.getGreen(), base.getBlue(), combined);
    }

    private class_243 getLerpedPosCompat(class_1297 e, float tickDelta) {
        try {
            return e.method_30950(tickDelta);
        } catch (Throwable ignored) {
            double x = class_3532.method_16436(tickDelta, e.field_6038, e.method_23317());
            double y = class_3532.method_16436(tickDelta, e.field_5971, e.method_23318());
            double z = class_3532.method_16436(tickDelta, e.field_5989, e.method_23321());
            return new class_243(x, y, z);
        }
    }

    private static final class RenderData {
        final double dx, dy, dz, tracerTargetY, halfWidth, height;
        RenderData(double dx, double dy, double dz, double tracerTargetY, double halfWidth, double height) {
            this.dx = dx; this.dy = dy; this.dz = dz;
            this.tracerTargetY = tracerTargetY;
            this.halfWidth = halfWidth; this.height = height;
        }
    }
}
