package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.client.Friends;
import com.xenon.module.modules.client.XenonPlus;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class PlayerESP extends Module {

    private static final double TRACER_START_DISTANCE = 150.0D;
    private static final double TRACER_END_DISTANCE = 24.0D;
    private static final double TRACER_BEHIND_MIN_SPREAD = 2.75D;

    private final Setting<Double> alpha = new Setting<>("Alpha", 100.0, 0.0, 255.0);
    private final Setting<Double> range = new Setting<>("Range", 256.0, 16.0, 512.0);
    private final Setting<Boolean> tracers = new Setting<>("Tracers", false);
    private final Setting<Color> outlineColor = new Setting<>("Outline color", new Color(255, 0, 0));
    private final Setting<Color> fillColor = new Setting<>("Fill color", new Color(255, 0, 0));
    private final Setting<Color> tracerColor = new Setting<>("Tracer color", new Color(255, 0, 0));

    public PlayerESP() {
        super("Player ESP", Category.RENDER);
        addSetting(alpha);
        addSetting(range);
        addSetting(tracers);
        addSetting(outlineColor);
        addSetting(fillColor);
        addSetting(tracerColor);
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_4184 cam = RenderUtils.getCamera();
        if (cam == null) return;

        class_243 camPos = RenderUtils.getCameraPos(cam);
        double camX = camPos.field_1352;
        double camY = camPos.field_1351;
        double camZ = camPos.field_1350;
        double maxRangeSq = range.getValue() * range.getValue();
        int alphaValue = clampAlpha(alpha.getValue());
        boolean renderTracers = tracers.getValue();
        Color boxColor = applyOpacity(outlineColor.getValue(), alphaValue);
        Color fill = applyOpacity(fillColor.getValue(), Math.max(0, alphaValue / 3));
        Color tracer = renderTracers ? applyOpacity(tracerColor.getValue(), 255) : null;

        class_243 cameraForward = renderTracers ? RenderUtils.getCameraForward(cam) : null;
        class_243 cameraRight = renderTracers ? RenderUtils.getCameraRight(cam) : null;
        class_243 cameraUp = renderTracers ? RenderUtils.getCameraUp(cameraForward, cameraRight) : null;
        class_243 tracerStart = renderTracers ? cameraForward.method_1021(TRACER_START_DISTANCE) : null;

        List<RenderData> renderData = new ArrayList<>();

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724 || !player.method_5805() || player.method_7325() || player.method_5756(mc.field_1724)) {
                continue;
            }
            boolean friend = Friends.isEspColor() && Friends.isFriend(getFriendLookupName(player));

            class_243 lerped = getLerpedPosCompat(player, tickDelta);
            double worldX = lerped.field_1352;
            double worldY = lerped.field_1351;
            double worldZ = lerped.field_1350;
            double dx = worldX - camX;
            double dy = worldY - camY;
            double dz = worldZ - camZ;
            double distSq = (dx * dx) + (dy * dy) + (dz * dz);
            if (distSq > maxRangeSq) {
                continue;
            }

            Color curOutline;
            Color curFill;
            Color curTracer;
            if (friend) {
                Color fc = Friends.getColor();
                curOutline = applyOpacity(fc, alphaValue);
                curFill = applyOpacity(fc, Math.max(0, alphaValue / 3));
                curTracer = renderTracers ? applyOpacity(fc, 255) : null;
            } else {
                curOutline = boxColor;
                curFill = fill;
                curTracer = tracer;
            }

            // Dynamic hitbox based on current pose (crouch/swim/etc).
            double halfWidth = player.method_17681() / 2.0D;
            double height = player.method_17682();

            // Visibility culling: distance check above is sufficient; avoid aggressive AABB visibility culling.
            boolean boxVisible = true;
            double tracerTargetY = dy + (player.method_17682() * 0.5D);
            renderData.add(new RenderData(dx, dy, dz, tracerTargetY, halfWidth, height, curOutline, curFill, curTracer, boxVisible));
        }

        if (renderData.isEmpty()) {
            return;
        }

        matrices.method_22903();
        RenderUtils.WorldBatch boxBatch = RenderUtils.beginWorldBatch(matrices);
        for (RenderData data : renderData) {
            if (!data.boxVisible) {
                continue;
            }
            boxBatch.renderOutlineBox(
                    data.dx - data.halfWidth,
                    data.dy,
                    data.dz - data.halfWidth,
                    data.dx + data.halfWidth,
                    data.dy + data.height,
                    data.dz + data.halfWidth,
                    data.outline
            );
            boxBatch.renderFilledBox(
                    data.dx - data.halfWidth,
                    data.dy,
                    data.dz - data.halfWidth,
                    data.dx + data.halfWidth,
                    data.dy + data.height,
                    data.dz + data.halfWidth,
                    data.fill
            );
        }
        boxBatch.flush();

        if (renderTracers) {
            RenderUtils.WorldBatch tracerBatch = RenderUtils.beginWorldBatch(matrices);
            for (RenderData data : renderData) {
                if (data.tracer == null) {
                    continue;
                }
                class_243 tracerEnd = RenderUtils.getSpreadTracerEnd(
                        data.dx,
                        data.tracerTargetY,
                        data.dz,
                        cameraForward,
                        cameraRight,
                        cameraUp,
                        TRACER_END_DISTANCE,
                        TRACER_BEHIND_MIN_SPREAD
                );
                tracerBatch.renderLine(data.tracer, tracerStart, tracerEnd, XenonPlus.tracerLineWidth());
            }
            tracerBatch.flush();
        }

        matrices.method_22909();
    }

    private int clampAlpha(double value) {
        int alphaValue = (int) Math.round(value);
        if (alphaValue < 0) return 0;
        if (alphaValue > 255) return 255;
        return alphaValue;
    }

    private Color applyOpacity(Color base, int alphaValue) {
        int combinedAlpha = Math.max(0, Math.min(255, Math.round((base.getAlpha() / 255.0f) * alphaValue)));
        return new Color(base.getRed(), base.getGreen(), base.getBlue(), combinedAlpha);
    }

    private class_243 getLerpedPosCompat(class_1657 player, float tickDelta) {
        try {
            // Prefer native interpolation if present in this MC version.
            return player.method_30950(tickDelta);
        } catch (Throwable ignored) {
            double worldX = class_3532.method_16436(tickDelta, player.field_6038, player.method_23317());
            double worldY = class_3532.method_16436(tickDelta, player.field_5971, player.method_23318());
            double worldZ = class_3532.method_16436(tickDelta, player.field_5989, player.method_23321());
            return new class_243(worldX, worldY, worldZ);
        }
    }

    private String getFriendLookupName(class_1657 player) {
        if (player == null) {
            return "";
        }
        try {
            Object profile = player.method_7334();
            if (profile != null) {
                // Different mappings/MC versions can expose the profile name differently.
                try {
                    Object v = profile.getClass().getMethod("getName").invoke(profile);
                    if (v instanceof String s && !s.isBlank()) return s;
                } catch (Throwable ignored) {}
                try {
                    Object v = profile.getClass().getMethod("name").invoke(profile);
                    if (v instanceof String s && !s.isBlank()) return s;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return player.method_5477().getString();
    }

    private static final class RenderData {
        final double dx;
        final double dy;
        final double dz;
        final double tracerTargetY;
        final double halfWidth;
        final double height;
        final Color outline;
        final Color fill;
        final Color tracer;
        final boolean boxVisible;

        private RenderData(double dx, double dy, double dz, double tracerTargetY, double halfWidth, double height, Color outline, Color fill, Color tracer, boolean boxVisible) {
            this.dx = dx;
            this.dy = dy;
            this.dz = dz;
            this.tracerTargetY = tracerTargetY;
            this.halfWidth = halfWidth;
            this.height = height;
            this.outline = outline;
            this.fill = fill;
            this.tracer = tracer;
            this.boxVisible = boxVisible;
        }
    }
}
