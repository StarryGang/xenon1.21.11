package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.client.XenonPlus;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import java.awt.Color;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_1944;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class AmethystESP extends Module {

    private static final double TRACER_START_DISTANCE = 150.0D;
    private static final double TRACER_END_DISTANCE   = 24.0D;
    private static final double TRACER_BEHIND_SPREAD  = 2.75D;
    private static final double CHUNK_THICKNESS       = 0.05D;

    private final Setting<Float>   simDistance      = new Setting<>("Sim Distance",     8.0f,  1.0f, 32.0f);
    private final Setting<Float>   clusterThreshold = new Setting<>("Min Cluster Size", 3.0f,  1.0f, 20.0f);
    private final Setting<Float>   chunkY           = new Setting<>("Chunk Y Level",    55.0f, -64.0f, 320.0f);
    private final Setting<Boolean> esp              = new Setting<>("Block ESP",        true);
    private final Setting<Boolean> chunkMark        = new Setting<>("Chunk Mark",       true);
    private final Setting<Boolean> tracers          = new Setting<>("Show Tracers",     true);
    private final Setting<Boolean> chatNotify       = new Setting<>("Chat Alert",       true);
    private final Setting<Color>   espColor         = new Setting<>("ESP Color",        new Color(180, 100, 255));
    private final Setting<Color>   chunkColor       = new Setting<>("Chunk Color",      new Color(180, 100, 255));

    private static AmethystESP INSTANCE;
    private final Map<class_1923, Set<class_2338>> foundClusters = new ConcurrentHashMap<>();
    private final Set<class_1923> notifiedChunks = ConcurrentHashMap.newKeySet();
    private int tickCounter = 0;

    public AmethystESP() {
        super("Amethyst ESP", Category.RENDER);
        INSTANCE = this;
        addSetting(simDistance);
        addSetting(clusterThreshold);
        addSetting(chunkY);
        addSetting(esp);
        addSetting(chunkMark);
        addSetting(tracers);
        addSetting(chatNotify);
        addSetting(espColor);
        addSetting(chunkColor);
    }

    public static AmethystESP instance() { return INSTANCE; }

    @Override
    public void onEnable() {
        foundClusters.clear();
        notifiedChunks.clear();
        fullScan();
    }

    @Override
    public void onDisable() {
        foundClusters.clear();
        notifiedChunks.clear();
    }

    private void fullScan() {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        class_1923 center = mc.field_1724.method_31476();
        int radius = simDistance.getValue().intValue();
        int scanned = 0;

        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                class_2818 chunk = mc.field_1687.method_2935()
                        .method_12126(center.field_9181 + x, center.field_9180 + z, false);
                if (chunk != null) { scanChunk(chunk); scanned++; }
            }
        }
        sendChat("§7Scan: " + scanned + " Chunks | §d" + foundClusters.size() + " §7Geoden");
    }

    private void scanChunk(class_2818 chunk) {
        if (mc.field_1687 == null) return;

        class_1923 cp = chunk.method_12004();
        Set<class_2338> hits = new HashSet<>();
        int baseX = cp.field_9181 << 4;
        int baseZ = cp.field_9180 << 4;

        for (int y = -64; y <= 70; y++) {
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    class_2338 pos = new class_2338(baseX + lx, y, baseZ + lz);
                    if (y <= 50 && mc.field_1687.method_8314(class_1944.field_9282, pos) == 5) {
                        if (isAmethystNearby(pos)) {
                            hits.add(pos.method_10062());
                        }
                    }
                }
            }
        }

        if (hits.size() >= clusterThreshold.getValue().intValue()) {
            foundClusters.put(cp, hits);
            if (chatNotify.getValue() && notifiedChunks.add(cp)) {
                sendChat("Amethyst Clusters on " + cp.method_33940() + " " + cp.method_33942()
                        + " §7(" + hits.size() + " hits)");
            }
        } else {
            foundClusters.remove(cp);
            notifiedChunks.remove(cp);
        }
    }

    private boolean isAmethystNearby(class_2338 pos) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    class_2680 state = mc.field_1687.method_8320(pos.method_10069(dx, dy, dz));
                    if (state.method_27852(class_2246.field_27161)
                            || state.method_27852(class_2246.field_27162)
                            || state.method_27852(class_2246.field_27163)
                            || state.method_27852(class_2246.field_27164)
                            || state.method_27852(class_2246.field_27160)
                            || state.method_27852(class_2246.field_27159)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void onTick() {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        if (++tickCounter % 40 == 0) {
            class_1923 center = mc.field_1724.method_31476();
            int radius = simDistance.getValue().intValue();
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    class_2818 chunk = mc.field_1687.method_2935()
                            .method_12126(center.field_9181 + x, center.field_9180 + z, false);
                    if (chunk != null) scanChunk(chunk);
                }
            }
        }
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null || foundClusters.isEmpty()) return;

        class_4184 camera = RenderUtils.getCamera();
        if (camera == null) return;

        class_243 camPos      = RenderUtils.getCameraPos(camera);
        class_243 camForward  = RenderUtils.getCameraForward(camera);
        class_243 camRight    = RenderUtils.getCameraRight(camera);
        class_243 camUp       = RenderUtils.getCameraUp(camForward, camRight);
        class_243 tracerStart = camForward.method_1021(TRACER_START_DISTANCE);

        Color espFill   = withAlpha(espColor.getValue(),   180);
        Color chunkFill = withAlpha(chunkColor.getValue(), 200);
        Color tracer    = withAlpha(espColor.getValue(),   220);

        matrices.method_22903();

        org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);

        RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);

        org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);

        double fixedY = chunkY.getValue().doubleValue();

        for (Map.Entry<class_1923, Set<class_2338>> entry : foundClusters.entrySet()) {
            class_1923 cp = entry.getKey();
            Set<class_2338> positions = entry.getValue();
            if (positions.isEmpty()) continue;

            if (chunkMark.getValue()) {
                double x1 = cp.method_8326() - camPos.field_1352;
                double z1 = cp.method_8328() - camPos.field_1350;
                double x2 = cp.method_8327()   - camPos.field_1352 + 1;
                double z2 = cp.method_8329()   - camPos.field_1350 + 1;
                double y1 = fixedY - camPos.field_1351;
                double y2 = y1 + CHUNK_THICKNESS;

                batch.renderFilledBox(x1, y1, z1, x2, y2, z2, chunkFill);
            }

            if (esp.getValue()) {
                for (class_2338 p : positions) {
                    double x1 = p.method_10263() - camPos.field_1352;
                    double y1 = p.method_10264() - camPos.field_1351;
                    double z1 = p.method_10260() - camPos.field_1350;
                    batch.renderFilledBox(x1, y1, z1, x1 + 1.0, y1 + 1.0, z1 + 1.0, espFill);
                }
            }

            if (tracers.getValue()) {
                class_2338 nearest = null;
                double nearestDist = Double.MAX_VALUE;
                for (class_2338 p : positions) {
                    double dist = p.method_10262(mc.field_1724.method_24515());
                    if (dist < nearestDist) { nearestDist = dist; nearest = p; }
                }

                if (nearest != null) {
                    class_243 relTarget = new class_243(
                            nearest.method_10263() + 0.5 - camPos.field_1352,
                            nearest.method_10264() + 0.5 - camPos.field_1351,
                            nearest.method_10260() + 0.5 - camPos.field_1350
                    );
                    class_243 tracerEnd = RenderUtils.getSpreadTracerEnd(
                            relTarget, camForward, camRight, camUp,
                            TRACER_END_DISTANCE, TRACER_BEHIND_SPREAD
                    );
                    batch.renderLine(tracer, tracerStart, tracerEnd, XenonPlus.tracerLineWidth());
                }
            }
        }

        batch.flush();

        org.lwjgl.opengl.GL11.glEnable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);
        matrices.method_22909();
    }

    private Color withAlpha(Color base, int alpha) {
        return new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, alpha));
    }

    public static void onChunkData(int cx, int cz) {
        if (INSTANCE == null || !INSTANCE.isEnabled()) return;
        class_2818 chunk = class_310.method_1551().field_1687
                .method_2935().method_12126(cx, cz, false);
        if (chunk != null) INSTANCE.scanChunk(chunk);
    }

    public static void onBlockUpdate(class_2338 pos, class_2680 state) {
        onChunkData(pos.method_10263() >> 4, pos.method_10260() >> 4);
    }

    public static void onParticle(String type, double x, double y, double z) {}

    public static void renderHud(class_332 context, float delta) {
        if (INSTANCE == null || !INSTANCE.isEnabled()) return;
        context.method_51433(
                class_310.method_1551().field_1772,
                "§dAmethystESP: §f" + INSTANCE.foundClusters.size() + " Geoden",
                10, 10, -1, true
        );
    }

    private void sendChat(String message) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470("§d[AmethystESP] §f" + message), false);
        }
    }
}
