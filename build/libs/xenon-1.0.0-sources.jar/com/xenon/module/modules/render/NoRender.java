package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import net.minecraft.class_1959;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public final class NoRender extends Module {

    public static NoRender instance;

    private final Setting<Boolean> rain = new Setting<>("Rain", true);
    private final Setting<Boolean> snow = new Setting<>("Snow", true);
    private final Setting<Boolean> thunder = new Setting<>("Thunder", true);

    public NoRender() {
        super("NoRender", Category.RENDER);
        instance = this;
        addSetting(rain);
        addSetting(snow);
        addSetting(thunder);
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled() && mc != null && mc.field_1687 != null;
    }

    public static boolean hideRain() {
        return isActive() && instance.rain.getValue();
    }

    public static boolean hideSnow() {
        return isActive() && instance.snow.getValue();
    }

    public static boolean hideThunder() {
        return isActive() && instance.thunder.getValue();
    }

    public static boolean hideAllPrecipitation() {
        return hideRain() && hideSnow();
    }

    public static boolean hideRainGradient() {
        return hideAllPrecipitation();
    }

    public static class_1959.class_1963 filterPrecipitation(class_1959.class_1963 precipitation) {
        if (!isActive() || precipitation == null) {
            return precipitation;
        }

        if (precipitation == class_1959.class_1963.field_9382 && hideRain()) {
            return class_1959.class_1963.field_9384;
        }

        if (precipitation == class_1959.class_1963.field_9383 && hideSnow()) {
            return class_1959.class_1963.field_9384;
        }

        return precipitation;
    }

    public static boolean shouldCancelWeatherSound(class_3414 soundEvent) {
        if (!isActive() || soundEvent == null) {
            return false;
        }

        if (hideRain() && (soundEvent == class_3417.field_14946 || soundEvent == class_3417.field_15020)) {
            return true;
        }

        return hideThunder() && (soundEvent == class_3417.field_14865
                || soundEvent == class_3417.field_14956);
    }
}
