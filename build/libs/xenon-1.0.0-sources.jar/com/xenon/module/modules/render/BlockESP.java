package com.xenon.module.modules.render;

import com.xenon.gui.notification.NotificationManager;
import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.BlocksSetting;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import com.xenon.module.modules.client.XenonPlus;
import org.lwjgl.opengl.GL11;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7923;

public final class BlockESP extends Module {

    private static final int RESCAN_INTERVAL_TICKS = 40;
    private static final int CHUNKS_PER_TICK = 6;
    private static final long NOTIFY_COOLDOWN_MS = 750L;
    private static final int DEFAULT_ALPHA = 110;
    private static final double BOX_INSET = 0.0625;
    private static final double TRACER_START_DISTANCE = 150.0D;
    private static final double TRACER_END_DISTANCE = 24.0D;
    private static final double TRACER_BEHIND_MIN_SPREAD = 2.75D;

    private final BlocksSetting blocks = new BlocksSetting("Blocks", class_2246.field_10260);
    private final Setting<Boolean> notify = new Setting<>("Notification", true);
    private final Setting<Boolean> esp = new Setting<>("ESP", true);
    private final Setting<Boolean> tracers = new Setting<>("Tracers", false);

    private final Map<Long, Set<class_2338>> cachedBlocks = new ConcurrentHashMap<>();
    private final Map<class_2338, class_2248> posTypeMap = new ConcurrentHashMap<>();
    private final Map<Long, Long> lastNotifiedAt = new ConcurrentHashMap<>();
    private final ArrayDeque<Long> scanQueue = new ArrayDeque<>();
    private final Set<Long> queuedChunks = new HashSet<>();
    private final Object queueLock = new Object();

    private volatile Set<class_2248> targets = Collections.emptySet();
    private long lastBlocksVersion = -1L;
    private int tickCounter = 0;
    private boolean fullRescanRequested = true;
    private class_1923 lastCenterChunk;
    private int lastChunkRadius = -1;

    public BlockESP() {
        super("Block ESP", Category.RENDER);
        addSetting(blocks);
        addSetting(notify);
        addSetting(esp);
        addSetting(tracers);
    }

    @Override
    public void onEnable() {
        clearCaches();
        lastBlocksVersion = -1L;
        fullRescanRequested = true;
        tickCounter = 0;
        lastCenterChunk = null;
        lastChunkRadius = -1;
    }

    @Override
    public void onDisable() {
        clearCaches();
        lastCenterChunk = null;
        lastChunkRadius = -1;
    }

    @Override
    public void onTick() {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }

        updateTargets();
        if (targets.isEmpty()) {
            clearCaches();
            return;
        }

        tickCounter++;
        class_1923 currentChunk = mc.field_1724.method_31476();
        int currentChunkRadius = getChunkRadius();
        boolean forceRescan = fullRescanRequested || tickCounter % RESCAN_INTERVAL_TICKS == 0;
        if (forceRescan || lastCenterChunk == null || !lastCenterChunk.equals(currentChunk) || lastChunkRadius != currentChunkRadius) {
            rebuildLoadedChunkQueue(forceRescan);
            fullRescanRequested = false;
            lastCenterChunk = currentChunk;
            lastChunkRadius = currentChunkRadius;
        }

        for (int i = 0; i < CHUNKS_PER_TICK; i++) {
            Long chunkKey;
            synchronized (queueLock) {
                chunkKey = scanQueue.poll();
                if (chunkKey != null) {
                    queuedChunks.remove(chunkKey);
                }
            }
            if (chunkKey == null) {
                break;
            }
            int chunkX = class_1923.method_8325(chunkKey);
            int chunkZ = class_1923.method_8332(chunkKey);
            class_2818 chunk = mc.field_1687.method_2935().method_12126(chunkX, chunkZ, false);
            if (chunk != null) {
                scanChunk(chunk);
            }
        }
    }

    @Override
    public void onPacketReceive(class_2596<?> packet) {
        if (mc.field_1687 == null) {
            return;
        }

        if (packet instanceof class_2672 chunkData) {
            queueChunk(class_1923.method_8331(chunkData.method_11523(), chunkData.method_11524()), true);
            return;
        }

        if (packet instanceof class_2637 deltaUpdate) {
            deltaUpdate.method_30621((pos, state) -> queueChunk(new class_1923(pos).method_8324(), true));
            return;
        }

        if (packet instanceof class_2626 blockUpdate) {
            queueChunk(new class_1923(blockUpdate.method_11309()).method_8324(), true);
        }
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null || cachedBlocks.isEmpty()) {
            return;
        }
        if (!esp.getValue() && !tracers.getValue()) {
            return;
        }
        Set<class_2248> localTargets = this.targets;
        if (localTargets.isEmpty()) {
            return;
        }

        class_4184 cam = RenderUtils.getCamera();
        if (cam == null) {
            return;
        }

        class_243 camPos = RenderUtils.getCameraPos(cam);
        class_243 cameraForward = RenderUtils.getCameraForward(cam);
        class_243 cameraRight = RenderUtils.getCameraRight(cam);
        class_243 cameraUp = RenderUtils.getCameraUp(cameraForward, cameraRight);
        class_243 tracerStart = cameraForward.method_1021(TRACER_START_DISTANCE);
        double maxDistanceSq = getMaxRenderDistanceSq();
        RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);
        boolean rendered = false;

        // Must be on render thread and placed after the batch setup but before we emit any vertices.
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        try {
            for (Set<class_2338> positions : cachedBlocks.values()) {
                for (class_2338 pos : positions) {
                    if (pos.method_40081(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()) > maxDistanceSq) {
                        continue;
                    }

                    class_2248 block = posTypeMap.get(pos);
                    if (block == null) {
                        class_2680 state = mc.field_1687.method_8320(pos);
                        block = state.method_26204();
                    }
                    if (!localTargets.contains(block)) {
                        continue;
                    }

                    Color color = getBlockColor(block, DEFAULT_ALPHA);
                    double x = pos.method_10263() - camPos.field_1352;
                    double y = pos.method_10264() - camPos.field_1351;
                    double z = pos.method_10260() - camPos.field_1350;
                    Color outline = new Color(color.getRed(), color.getGreen(), color.getBlue(), 255);

                    if (esp.getValue()) {
                        batch.renderOutlineBox(
                                x + BOX_INSET,
                                y + BOX_INSET,
                                z + BOX_INSET,
                                x + 1.0 - BOX_INSET,
                                y + 1.0 - BOX_INSET,
                                z + 1.0 - BOX_INSET,
                                outline
                        );
                        batch.renderFilledBox(
                                x + BOX_INSET,
                                y + BOX_INSET,
                                z + BOX_INSET,
                                x + 1.0 - BOX_INSET,
                                y + 1.0 - BOX_INSET,
                                z + 1.0 - BOX_INSET,
                                color
                        );
                    }
                    if (tracers.getValue()) {
                        class_243 relativeTarget = new class_243(x + 0.5D, y + 0.5D, z + 0.5D);
                    class_243 tracerEnd = RenderUtils.getSpreadTracerEnd(
                            relativeTarget,
                            cameraForward,
                            cameraRight,
                            cameraUp,
                            TRACER_END_DISTANCE,
                            TRACER_BEHIND_MIN_SPREAD
                    );
                    batch.renderLine(outline, tracerStart, tracerEnd, XenonPlus.tracerLineWidth());
                }
                rendered = true;
            }
        }

            if (rendered) {
                batch.flush();
            }
        } finally {
            GL11.glEnable(GL11.GL_DEPTH_TEST);
        }
    }

    private void updateTargets() {
        long version = blocks.getVersion();
        if (version == lastBlocksVersion) {
            return;
        }

        lastBlocksVersion = version;
        // Snapshot: only blocks explicitly selected by the user.
        targets = Set.copyOf(blocks.getSelectedBlocks());
        clearCaches();
        fullRescanRequested = true;
    }

    public boolean isSelected(class_2248 block) {
        updateTargets();
        return blocks.contains(block);
    }

    public int getSelectedCount() {
        updateTargets();
        return blocks.size();
    }

    private void rebuildLoadedChunkQueue(boolean forceRescan) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }

        int viewDist = getChunkRadius();
        class_1923 center = mc.field_1724.method_31476();
        List<class_2818> loadedChunks = new ArrayList<>();
        Set<Long> loadedChunkKeys = new HashSet<>();
        for (int x = -viewDist; x <= viewDist; x++) {
            for (int z = -viewDist; z <= viewDist; z++) {
                class_2818 chunk = mc.field_1687.method_2935().method_12126(center.field_9181 + x, center.field_9180 + z, false);
                if (chunk != null) {
                    loadedChunks.add(chunk);
                    loadedChunkKeys.add(chunk.method_12004().method_8324());
                }
            }
        }

        loadedChunks.sort(Comparator.comparingInt(chunk -> getChunkDistanceSq(center, chunk.method_12004())));

        synchronized (queueLock) {
            scanQueue.removeIf(chunkKey -> !loadedChunkKeys.contains(chunkKey));
            queuedChunks.retainAll(loadedChunkKeys);
            for (class_2818 chunk : loadedChunks) {
                long chunkKey = chunk.method_12004().method_8324();
                boolean shouldQueue = forceRescan || !cachedBlocks.containsKey(chunkKey);
                if (shouldQueue && queuedChunks.add(chunkKey)) {
                    scanQueue.addLast(chunkKey);
                }
            }
        }

        pruneOutOfRange(center, viewDist);
    }

    private void queueChunk(long chunkKey, boolean prioritized) {
        synchronized (queueLock) {
            if (prioritized && queuedChunks.contains(chunkKey)) {
                scanQueue.remove(chunkKey);
                scanQueue.addFirst(chunkKey);
                return;
            }

            if (!queuedChunks.add(chunkKey)) {
                return;
            }

            if (prioritized) {
                scanQueue.addFirst(chunkKey);
            } else {
                scanQueue.add(chunkKey);
            }
        }
    }

    private void scanChunk(class_2818 chunk) {
        Set<class_2248> localTargets = this.targets;
        if (localTargets.isEmpty()) {
            return;
        }
        int worldBottom = mc.field_1687.method_31607();
        int worldTopExclusive = mc.field_1687.method_31607() + mc.field_1687.method_31605();
        int minSection = mc.field_1687.method_32891();

        class_1923 chunkPos = chunk.method_12004();
        long chunkKey = chunkPos.method_8324();
        Set<class_2338> oldSet = cachedBlocks.get(chunkKey);
        Set<class_2338> newSet = new HashSet<>();
        class_2248 firstNewBlock = null;
        class_2338 firstNewPos = null;

        class_2826[] sections = chunk.method_12006();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            class_2826 section = sections[sectionIndex];
            if (section == null || section.method_38292()) {
                continue;
            }

            int sectionYBase = (minSection + sectionIndex) * 16;
            if (sectionYBase + 16 <= worldBottom || sectionYBase >= worldTopExclusive) {
                continue;
            }

            for (int localX = 0; localX < 16; localX++) {
                for (int localZ = 0; localZ < 16; localZ++) {
                    for (int localY = 0; localY < 16; localY++) {
                        class_2680 state = section.method_12254(localX, localY, localZ);
                        class_2248 block = state.method_26204();
                        if (!localTargets.contains(block)) {
                            continue;
                        }

                        class_2338 pos = new class_2338(chunkPos.method_8326() + localX, sectionYBase + localY, chunkPos.method_8328() + localZ);
                        newSet.add(pos);
                        posTypeMap.put(pos, block);
                        if (firstNewBlock == null && (oldSet == null || !oldSet.contains(pos))) {
                            firstNewBlock = block;
                            firstNewPos = pos;
                        }
                    }
                }
            }
        }

        if (oldSet != null) {
            for (class_2338 pos : oldSet) {
                if (!newSet.contains(pos)) {
                    posTypeMap.remove(pos);
                }
            }
        }

        if (newSet.isEmpty()) {
            removeChunkCache(chunkKey);
            lastNotifiedAt.remove(chunkKey);
            return;
        }

        cachedBlocks.put(chunkKey, newSet);
        if (firstNewBlock != null && firstNewPos != null) {
            maybeNotify(chunkKey, firstNewBlock, firstNewPos, chunkPos);
        }
    }

    private void maybeNotify(long chunkKey, class_2248 block, class_2338 pos, class_1923 chunkPos) {
        if (!notify.getValue() || mc.field_1724 == null) {
            return;
        }

        long now = System.currentTimeMillis();
        long last = lastNotifiedAt.getOrDefault(chunkKey, 0L);
        if (now - last < NOTIFY_COOLDOWN_MS) {
            return;
        }

        lastNotifiedAt.put(chunkKey, now);
        NotificationManager.INSTANCE.push(
                safeBlockName(block) + " found",
                "X " + pos.method_10263() + "  Y " + pos.method_10264() + "  Z " + pos.method_10260(),
                createNotificationStack(block),
                getBlockColor(block, 255).getRGB()
        );
        mc.field_1687.method_43128(
                mc.field_1724,
                mc.field_1724.method_23317(),
                mc.field_1724.method_23318(),
                mc.field_1724.method_23321(),
                class_3417.field_14627,
                class_3419.field_15250,
                0.6f,
                0.95f
        );
    }

    private class_1799 createNotificationStack(class_2248 block) {
        class_1799 stack = new class_1799(block.method_8389());
        return stack.method_7960() ? class_1799.field_8037 : stack;
    }

    private int getChunkDistanceSq(class_1923 origin, class_1923 target) {
        int dx = target.field_9181 - origin.field_9181;
        int dz = target.field_9180 - origin.field_9180;
        return dx * dx + dz * dz;
    }

    private int getChunkRadius() {
        return mc.field_1690.method_38521();
    }

    private double getMaxRenderDistanceSq() {
        double maxDistance = (getChunkRadius() * 16.0D) + 16.0D;
        return maxDistance * maxDistance;
    }

    private void pruneOutOfRange(class_1923 center, int chunkRadius) {
        List<Long> toRemove = new ArrayList<>();
        for (Long chunkKey : cachedBlocks.keySet()) {
            class_1923 chunkPos = new class_1923(class_1923.method_8325(chunkKey), class_1923.method_8332(chunkKey));
            if (Math.abs(chunkPos.field_9181 - center.field_9181) > chunkRadius || Math.abs(chunkPos.field_9180 - center.field_9180) > chunkRadius) {
                toRemove.add(chunkKey);
            }
        }

        for (Long chunkKey : toRemove) {
            removeChunkCache(chunkKey);
            lastNotifiedAt.remove(chunkKey);
        }
    }

    private void removeChunkCache(long chunkKey) {
        Set<class_2338> removed = cachedBlocks.remove(chunkKey);
        if (removed == null) {
            return;
        }

        for (class_2338 pos : removed) {
            posTypeMap.remove(pos);
        }
    }

    private Color getBlockColor(class_2248 block, int alphaValue) {
        class_2960 id = class_7923.field_41175.method_10221(block);
        String path = id == null ? "" : id.method_12832();

        if (block == class_2246.field_10260) {
            return new Color(138, 126, 166, alphaValue);
        }
        if (path.contains("diamond")) {
            return new Color(0, 255, 255, alphaValue);
        }
        if (path.contains("ancient_debris")) {
            return new Color(196, 120, 72, alphaValue);
        }
        if (path.contains("emerald")) {
            return new Color(0, 255, 127, alphaValue);
        }
        if (path.contains("gold")) {
            return new Color(255, 215, 0, alphaValue);
        }
        if (path.contains("iron")) {
            return new Color(213, 213, 213, alphaValue);
        }
        if (path.contains("redstone")) {
            return new Color(255, 70, 70, alphaValue);
        }
        if (path.contains("lapis")) {
            return new Color(70, 110, 255, alphaValue);
        }
        return new Color(255, 255, 0, alphaValue);
    }

    private String safeBlockName(class_2248 block) {
        try {
            return block.method_9518().getString();
        } catch (Exception ignored) {
            class_2960 id = class_7923.field_41175.method_10221(block);
            return id == null ? "Block" : id.toString();
        }
    }

    private void clearCaches() {
        cachedBlocks.clear();
        posTypeMap.clear();
        lastNotifiedAt.clear();
        synchronized (queueLock) {
            scanQueue.clear();
            queuedChunks.clear();
        }
    }
}
