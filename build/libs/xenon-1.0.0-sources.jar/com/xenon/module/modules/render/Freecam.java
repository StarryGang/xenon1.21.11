package com.xenon.module.modules.render;

import com.xenon.module.Category;
import com.xenon.module.Module;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.joml.Vector3d;

public class Freecam extends Module {

    private static final float MIN_SCROLL_SPEED = 0.1f;
    private static final float MAX_SCROLL_SPEED = 10.0f;
    private static final float SCROLL_SPEED_STEP = 0.2f;

    public final Vector3d currentPosition = new Vector3d();
    public final Vector3d previousPosition = new Vector3d();
    private final Vector3d velocity = new Vector3d();

    public float yaw;
    public float pitch;
    public float previousYaw;
    public float previousPitch;

    public final com.xenon.setting.Setting<Float> speed = new com.xenon.setting.Setting<>("Speed", 1.0f, 0.1f, 10.0f);
    private boolean smoothing = true;
    private float lookSensitivity = 0.5f;
    private float currentSpeed;

    private class_5498 savedPerspective;
    private boolean savedChunkCullingEnabled;
    private long lastFrameTime;

    private float savedPlayerYaw;
    private float savedPlayerPitch;

    public static Freecam instance;

    public Freecam() {
        super("Freecam", Category.RENDER);
        instance = this;
        addSetting(speed);
    }

    @Override
    public void onEnable() {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            this.toggle();
            return;
        }

        savedPerspective = mc.field_1690.method_31044();
        savedChunkCullingEnabled = mc.field_1730;
        mc.field_1730 = false;

        savedPlayerYaw = mc.field_1724.method_36454();
        savedPlayerPitch = mc.field_1724.method_36455();

        yaw = mc.field_1724.method_36454();
        pitch = mc.field_1724.method_36455();

        class_243 eyePos = mc.field_1724.method_5836(1.0f);
        currentPosition.set(eyePos.field_1352, eyePos.field_1351, eyePos.field_1350);
        previousPosition.set(eyePos.field_1352, eyePos.field_1351, eyePos.field_1350);

        previousYaw = yaw;
        previousPitch = pitch;

        lastFrameTime = System.currentTimeMillis();
        velocity.set(0, 0, 0);
        currentSpeed = getConfiguredSpeed();
        mc.field_1724.method_18800(0.0, mc.field_1724.method_18798().field_1351, 0.0);
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 != null) {
            mc.field_1724.method_36456(savedPlayerYaw);
            mc.field_1724.method_36457(savedPlayerPitch);
            mc.field_1724.method_5847(savedPlayerYaw);
            mc.field_1724.method_5636(savedPlayerYaw);
        }
        if (savedPerspective != null) {
            mc.field_1690.method_31043(savedPerspective);
        } else {
            mc.field_1690.method_31043(class_5498.field_26664);
        }
        mc.field_1730 = savedChunkCullingEnabled;
        velocity.set(0, 0, 0);
        currentSpeed = getConfiguredSpeed();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) {
            return;
        }

        
        mc.field_1724.method_36456(savedPlayerYaw);
        mc.field_1724.method_36457(savedPlayerPitch);
        mc.field_1724.method_5847(savedPlayerYaw);
        mc.field_1724.method_5636(savedPlayerYaw);
    }

    public void updateCameraMovement() {
        if (mc.field_1724 == null)
            return;

        previousPosition.set(currentPosition);
        previousYaw = yaw;
        previousPitch = pitch;

        long currentTime = System.currentTimeMillis();
        float deltaTime = (float) (currentTime - lastFrameTime) / 1000.0f;
        lastFrameTime = currentTime;

        deltaTime = Math.min(deltaTime, 0.1f);
        if (deltaTime < 0.001f)
            deltaTime = 0.016f;

        float yawRad = (float) Math.toRadians(yaw);
        double forwardX = -Math.sin(yawRad);
        double forwardZ = Math.cos(yawRad);
        double rightX = -Math.cos(yawRad);
        double rightZ = -Math.sin(yawRad);

        double moveX = 0.0, moveY = 0.0, moveZ = 0.0;
        double moveSpeed = currentSpeed * 2.0;

        if (mc.field_1690 != null && mc.field_1690.field_1867.method_1434()) {
            moveSpeed *= 2.0;
        }

        if (mc.field_1690.field_1894.method_1434()) {
            moveX += forwardX * moveSpeed;
            moveZ += forwardZ * moveSpeed;
        }
        if (mc.field_1690.field_1881.method_1434()) {
            moveX -= forwardX * moveSpeed;
            moveZ -= forwardZ * moveSpeed;
        }
        if (mc.field_1690.field_1849.method_1434()) {
            moveX += rightX * moveSpeed;
            moveZ += rightZ * moveSpeed;
        }
        if (mc.field_1690.field_1913.method_1434()) {
            moveX -= rightX * moveSpeed;
            moveZ -= rightZ * moveSpeed;
        }
        if (mc.field_1690.field_1903.method_1434()) {
            moveY += moveSpeed;
        }
        if (mc.field_1690.field_1832.method_1434()) {
            moveY -= moveSpeed;
        }

        double multiplier = 5.0;

        if (smoothing) {
            double lerpFactor = 1.0 - Math.pow(0.001, deltaTime);
            velocity.x = class_3532.method_16436(lerpFactor, velocity.x, moveX * multiplier);
            velocity.y = class_3532.method_16436(lerpFactor, velocity.y, moveY * multiplier);
            velocity.z = class_3532.method_16436(lerpFactor, velocity.z, moveZ * multiplier);
        } else {
            velocity.set(moveX * multiplier, moveY * multiplier, moveZ * multiplier);
        }

        currentPosition.x += velocity.x * (double) deltaTime;
        currentPosition.y += velocity.y * (double) deltaTime;
        currentPosition.z += velocity.z * (double) deltaTime;
    }

    



    public void onScrollWheel(double scrollDelta) {
        float current = currentSpeed;
        float step = 0.5f;
        float newVal = current + (float) scrollDelta * step;
        currentSpeed = class_3532.method_15363(newVal, MIN_SCROLL_SPEED, MAX_SCROLL_SPEED);
    }

    public void updateRotation(double deltaYaw, double deltaPitch) {
        yaw += (float) deltaYaw;
        pitch += (float) deltaPitch;
        yaw = class_3532.method_15393(yaw);
        pitch = class_3532.method_15363(pitch, -90.0f, 90.0f);
    }

    public double getInterpolatedX(float partialTicks) {
        return class_3532.method_16436((double) partialTicks, previousPosition.x, currentPosition.x);
    }

    public double getInterpolatedY(float partialTicks) {
        return class_3532.method_16436((double) partialTicks, previousPosition.y, currentPosition.y);
    }

    public double getInterpolatedZ(float partialTicks) {
        return class_3532.method_16436((double) partialTicks, previousPosition.z, currentPosition.z);
    }

    public float getInterpolatedYaw(float partialTicks) {
        return class_3532.method_16439(partialTicks, previousYaw, yaw);
    }

    public float getInterpolatedPitch(float partialTicks) {
        return class_3532.method_16439(partialTicks, previousPitch, pitch);
    }

    public float getLookSensitivity() {
        return lookSensitivity;
    }

    public void adjustSpeed(double scrollAmount) {
        if (scrollAmount == 0.0) {
            return;
        }

        float nextSpeed = currentSpeed + (float) Math.signum(scrollAmount) * SCROLL_SPEED_STEP;
        currentSpeed = class_3532.method_15363(nextSpeed, MIN_SCROLL_SPEED, MAX_SCROLL_SPEED);
    }

    private float getConfiguredSpeed() {
        return class_3532.method_15363(speed.getValue(), MIN_SCROLL_SPEED, MAX_SCROLL_SPEED);
    }
}
