package com.xenon.module.modules.donut;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2541;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3830;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5689;

public final class GrowthFinder extends Module {

    private final Setting<Boolean> renderVines = new Setting<>("Render Vines", true);
    private final Setting<Boolean> renderDripstone = new Setting<>("Render Dripstone", true);
    private final Setting<Boolean> renderBerries = new Setting<>("Render Berries", true);
    private final Setting<Boolean> renderStandardChunks = new Setting<>("Render Gray Chunks", true);
    private final Setting<Float> alpha = new Setting<>("Alpha", 80.0f, 0.0f, 255.0f);

    private static final int SCAN_RADIUS = 8;
    private static final int CHUNKS_PER_TICK = 12;
    private static final int MIN_VINE_LENGTH = 6;
    private static final int MAX_VINE_SCAN_PER_CHUNK = 2;
    private static final double PLATE_HEIGHT = 0.08;

    private static final Color HIGH_SUSPICION_GRAY = new Color(135, 135, 135);
    private static final Color LOW_SUSPICION_GRAY = new Color(100, 100, 100);
    private static final Color SOURCE_PLATE_COLOR_BASE = new Color(203, 64, 255);
    private static final Color EXTREME_PLATE_COLOR_BASE = new Color(255, 198, 64);

    private final Set<class_1923> scannedChunks = new HashSet<>();
    private final Map<class_1923, SuspiciousGrowthData> suspiciousChunks = new HashMap<>();
    private final List<class_1923> scanQueue = new ArrayList<>();
    private class_1923 lastQueueCenter = null;
    private int scanCursor = 0;

    private final List<class_1923> lockedBaseChunks = new ArrayList<>();
    private final Map<class_1923, Double> sourceHistory = new HashMap<>();

    public GrowthFinder() {
        super("Growth Finder", Category.DONUT);
        addSetting(renderVines);
        addSetting(renderDripstone);
        addSetting(renderBerries);
        addSetting(renderStandardChunks);
        addSetting(alpha);
    }

    @Override
    public void onEnable() { clearData(); }

    @Override
    public void onDisable() { clearData(); }

    private void clearData() {
        suspiciousChunks.clear();
        scannedChunks.clear();
        scanQueue.clear();
        scanCursor = 0;
        lastQueueCenter = null;
        lockedBaseChunks.clear();
        sourceHistory.clear();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_1923 playerChunk = new class_1923(mc.field_1724.method_24515());
        rebuildScanQueueIfNeeded(playerChunk);
        processChunkBatch(mc.field_1687);
        pruneFarChunks(playerChunk, SCAN_RADIUS);

        if (mc.field_1687.method_75260() % 20 == 0) {
            refreshLockedBaseChunk();
        }
    }

    private void rebuildScanQueueIfNeeded(class_1923 playerChunk) {
        if (lastQueueCenter == null
                || playerChunk.field_9181 != lastQueueCenter.field_9181 || playerChunk.field_9180 != lastQueueCenter.field_9180
                || scanCursor >= scanQueue.size()) {
            scanQueue.clear();
            for (int x = -SCAN_RADIUS; x <= SCAN_RADIUS; x++) {
                for (int z = -SCAN_RADIUS; z <= SCAN_RADIUS; z++) {
                    scanQueue.add(new class_1923(playerChunk.field_9181 + x, playerChunk.field_9180 + z));
                }
            }
            scanCursor = 0;
            lastQueueCenter = playerChunk;
        }
    }

    private void processChunkBatch(class_1937 world) {
        int processed = 0;
        while (scanCursor < scanQueue.size() && processed < CHUNKS_PER_TICK) {
            class_1923 chunkPos = scanQueue.get(scanCursor++);
            if (scannedChunks.contains(chunkPos)) continue;
            class_2818 chunk = world.method_8398().method_12126(chunkPos.field_9181, chunkPos.field_9180, false);
            if (chunk != null) {
                analyzeChunk(chunk, chunkPos);
                scannedChunks.add(chunkPos);
            }
            processed++;
        }
    }

    private void pruneFarChunks(class_1923 playerChunk, int radius) {
        int maxDistance = radius + 2;
        int pX = playerChunk.field_9181;
        int pZ = playerChunk.field_9180;
        suspiciousChunks.entrySet().removeIf(entry ->
                Math.abs(entry.getKey().field_9181 - pX) > maxDistance
                        || Math.abs(entry.getKey().field_9180 - pZ) > maxDistance);
        scannedChunks.removeIf(chunkPos ->
                Math.abs(chunkPos.field_9181 - pX) > maxDistance
                        || Math.abs(chunkPos.field_9180 - pZ) > maxDistance);
    }

    private void refreshLockedBaseChunk() {
        if (suspiciousChunks.isEmpty()) {
            sourceHistory.clear();
            return;
        }

        for (SuspiciousGrowthData data : suspiciousChunks.values()) {
            class_1923 sourceChunk = data.baseChunk;
            sourceHistory.merge(sourceChunk, (double) data.suspicionLevel, Double::sum);
        }

        sourceHistory.entrySet().removeIf(e -> {
            double val = e.getValue() * 0.95;
            e.setValue(val);
            return val < 0.5;
        });

        List<Map.Entry<class_1923, Double>> ranked = new ArrayList<>(sourceHistory.entrySet());
        ranked.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        lockedBaseChunks.clear();
        for (int i = 0; i < Math.min(2, ranked.size()); i++) {
            lockedBaseChunks.add(ranked.get(i).getKey());
        }
    }

    private void analyzeChunk(class_2818 chunk, class_1923 chunkPos) {
        int xStart = chunkPos.method_8326();
        int zStart = chunkPos.method_8328();

        List<VineCluster> vineClusters = renderVines.getValue()
                ? detectTallGroundedVines(chunk, xStart, zStart) : Collections.emptyList();
        List<DripstoneCluster> dripstoneClusters = renderDripstone.getValue()
                ? detectMaxDripstoneClusters(chunk, xStart, zStart) : Collections.emptyList();
        List<BerryCluster> berryClusters = renderBerries.getValue()
                ? detectMaxGrownBerries(chunk, xStart, zStart) : Collections.emptyList();

        List<WeightedEvidence> evidencePoints = new ArrayList<>();
        double vineWeight = 0;
        int maxVineLength = 0;
        for (VineCluster cluster : vineClusters) {
            double weight = cluster.length;
            vineWeight += weight;
            if (cluster.length > maxVineLength) maxVineLength = cluster.length;
            evidencePoints.add(new WeightedEvidence(cluster.centroid(), weight));
        }

        double dripWeight = 0;
        for (DripstoneCluster cluster : dripstoneClusters) {
            dripWeight += 2.5;
            evidencePoints.add(new WeightedEvidence(cluster.center, 2.5));
        }
        double berryWeight = 0;
        for (BerryCluster cluster : berryClusters) {
            berryWeight += 1.0;
            evidencePoints.add(new WeightedEvidence(cluster.pos, 1.0));
        }

        int suspicionLevel = (int) Math.round(vineWeight * 0.5 + dripWeight * 0.75 + berryWeight * 1.0);
        if (suspicionLevel > 0) {
            class_2338 estimatedSource = calculateWeightedSource(evidencePoints, chunkPos);
            boolean isExtreme = maxVineLength >= 100;
            boolean isSource = maxVineLength >= 25;
            suspiciousChunks.put(chunkPos, new SuspiciousGrowthData(chunkPos, suspicionLevel,
                    new class_1923(estimatedSource), isExtreme, isSource, maxVineLength));
        } else {
            suspiciousChunks.remove(chunkPos);
        }
    }

    private List<VineCluster> detectTallGroundedVines(class_2818 chunk, int xStart, int zStart) {
        List<VineCluster> clusters = new ArrayList<>();
        Set<class_2338> visited = new HashSet<>();
        int groundY = chunk.method_31607();
        int tallClusters = 0;

        for (int x = xStart; x < xStart + 16; x += 2) {
            for (int z = zStart; z < zStart + 16; z += 2) {
                if (tallClusters >= MAX_VINE_SCAN_PER_CHUNK) break;
                int y = chunk.method_12032(class_2902.class_2903.field_13197).method_12603(x - xStart, z - zStart);
                while (y >= groundY) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (visited.contains(pos)) { y--; continue; }
                    class_2680 state = chunk.method_8320(pos);
                    if (!isVineBlock(state.method_26204())) { y--; continue; }

                    List<class_2338> positions = new ArrayList<>();
                    class_2338 currTrace = pos;
                    while (currTrace.method_10264() >= groundY && isVineBlock(chunk.method_8320(currTrace).method_26204())) {
                        visited.add(currTrace);
                        positions.add(currTrace);
                        currTrace = currTrace.method_10074();
                    }

                    if (positions.size() >= MIN_VINE_LENGTH) {
                        clusters.add(new VineCluster(positions));
                        tallClusters++;
                    }
                    y = currTrace.method_10264() - 1;
                }
            }
        }
        return clusters;
    }

    private boolean isVineBlock(class_2248 block) {
        return block instanceof class_2541
                || block == class_2246.field_28675
                || block == class_2246.field_28676
                || block == class_2246.field_22123
                || block == class_2246.field_22124
                || block == class_2246.field_23078
                || block == class_2246.field_23079;
    }

    private List<DripstoneCluster> detectMaxDripstoneClusters(class_2818 chunk, int xStart, int zStart) {
        List<DripstoneCluster> clusters = new ArrayList<>();
        for (int x = xStart; x < xStart + 16; x += 4) {
            for (int z = zStart; z < zStart + 16; z += 4) {
                int heightmapY = chunk.method_12032(class_2902.class_2903.field_13197).method_12603(x - xStart, z - zStart);
                for (int y = -64; y <= heightmapY; y += 4) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (chunk.method_8320(pos).method_26204() instanceof class_5689) {
                        clusters.add(new DripstoneCluster(pos));
                        break;
                    }
                }
            }
        }
        return clusters;
    }

    private List<BerryCluster> detectMaxGrownBerries(class_2818 chunk, int xStart, int zStart) {
        List<BerryCluster> clusters = new ArrayList<>();
        for (int x = xStart; x < xStart + 16; x += 2) {
            for (int z = zStart; z < zStart + 16; z += 2) {
                int heightmapY = chunk.method_12032(class_2902.class_2903.field_13197).method_12603(x - xStart, z - zStart);
                for (int y = heightmapY; y >= heightmapY - 5; y--) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = chunk.method_8320(pos);
                    if (state.method_26204() instanceof class_3830) {
                        try {
                            if (state.method_11654(class_3830.field_17000) == 3) {
                                clusters.add(new BerryCluster(pos));
                            }
                        } catch (Exception ignored) {}
                    }
                }
            }
        }
        return clusters;
    }

    private class_2338 calculateWeightedSource(List<WeightedEvidence> evidencePoints, class_1923 chunkPos) {
        if (evidencePoints.isEmpty())
            return new class_2338(chunkPos.method_8326() + 8, 30, chunkPos.method_8328() + 8);
        double sumX = 0, sumY = 0, sumZ = 0, sumW = 0;
        for (WeightedEvidence e : evidencePoints) {
            sumX += e.pos.method_10263() * e.weight;
            sumY += e.pos.method_10264() * e.weight;
            sumZ += e.pos.method_10260() * e.weight;
            sumW += e.weight;
        }
        return new class_2338((int) (sumX / sumW), (int) (sumY / sumW), (int) (sumZ / sumW));
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        if (suspiciousChunks.isEmpty()) return;

        class_4184 cam = RenderUtils.getCamera();
        if (cam == null) return;
        class_243 camPos = RenderUtils.getCameraPos(cam);

        int alphaInt = Math.max(0, Math.min(255, alpha.getValue().intValue()));

        matrices.method_22903();
        RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);
        for (SuspiciousGrowthData data : suspiciousChunks.values()) {
            boolean isStandard = !(data.extreme || data.source);
            if (isStandard && !renderStandardChunks.getValue()) continue;

            Color baseColor;
            if (data.extreme) baseColor = EXTREME_PLATE_COLOR_BASE;
            else if (data.source) baseColor = SOURCE_PLATE_COLOR_BASE;
            else if (data.suspicionLevel >= 5 || data.maxVineLength >= 4) baseColor = HIGH_SUSPICION_GRAY;
            else baseColor = LOW_SUSPICION_GRAY;

            Color finalColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), alphaInt);

            double startX = data.chunkPos.method_8326();
            double startZ = data.chunkPos.method_8328();
            double y = 30.0;

            double x1 = startX - camPos.field_1352;
            double z1 = startZ - camPos.field_1350;
            double x2 = startX + 16 - camPos.field_1352;
            double z2 = startZ + 16 - camPos.field_1350;
            double y1 = y - camPos.field_1351;
            double y2 = y + PLATE_HEIGHT - camPos.field_1351;
            batch.renderFilledBox(x1, y1, z1, x2, y2, z2, finalColor);
        }
        batch.flush();
        matrices.method_22909();
    }

    private static class VineCluster {
        final int length;
        final List<class_2338> positions;
        VineCluster(List<class_2338> p) { positions = p; length = p.size(); }
        class_2338 centroid() {
            long x = 0, y = 0, z = 0;
            for (class_2338 p : positions) { x += p.method_10263(); y += p.method_10264(); z += p.method_10260(); }
            return new class_2338((int) (x / positions.size()), (int) (y / positions.size()), (int) (z / positions.size()));
        }
    }

    private static class DripstoneCluster {
        final class_2338 center;
        DripstoneCluster(class_2338 c) { center = c; }
    }

    private record BerryCluster(class_2338 pos) {}
    private record WeightedEvidence(class_2338 pos, double weight) {}
    private record SuspiciousGrowthData(class_1923 chunkPos, int suspicionLevel, class_1923 baseChunk,
                                        boolean extreme, boolean source, int maxVineLength) {}
}
