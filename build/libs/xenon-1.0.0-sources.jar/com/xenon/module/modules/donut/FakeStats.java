package com.xenon.module.modules.donut;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9014;
import net.minecraft.class_9015;
import net.minecraft.class_9020;

public final class FakeStats extends Module {

    private static final String OBJECTIVE_NAME = "xenon_fake_stats";
    private static final int MAX_SIDEBAR_LINES = 15;

    private final Setting<String> money = new Setting<>("Money", "0");
    private final Setting<String> shards = new Setting<>("Shards", "0");
    private final Setting<String> kills = new Setting<>("Kills", "0");
    private final Setting<String> deaths = new Setting<>("Deaths", "0");
    private final Setting<String> playtime = new Setting<>("Playtime", "0m");

    private final Random randomSource = new Random();

    private class_266 originalObjective;
    private String originalObjectiveName;
    private class_266 customObjective;
    private AppliedStats appliedStats;
    private Object lastWorld;
    private String lastSnapshotSignature = "";
    private boolean needsRefresh;

    public FakeStats() {
        super("FakeStats", Category.DONUT);
        addSetting(money);
        addSetting(shards);
        addSetting(kills);
        addSetting(deaths);
        addSetting(playtime);

        randomizeSettings();
        applyCurrentValues();
    }

    @Override
    public void onEnable() {
        lastWorld = mc.field_1687;
        originalObjective = null;
        originalObjectiveName = null;
        customObjective = null;
        lastSnapshotSignature = "";
        randomizeSettings();
        applyCurrentValues();
        needsRefresh = true;
    }

    @Override
    public void onDisable() {
        restoreOriginalScoreboard();
        lastWorld = null;
        originalObjective = null;
        originalObjectiveName = null;
        customObjective = null;
        lastSnapshotSignature = "";
        needsRefresh = false;
    }

    @Override
    public void onTick() {
        if (mc.field_1687 == null) {
            originalObjective = null;
            originalObjectiveName = null;
            customObjective = null;
            lastWorld = null;
            lastSnapshotSignature = "";
            return;
        }

        if (mc.field_1687 != lastWorld) {
            originalObjective = null;
            originalObjectiveName = null;
            customObjective = null;
            lastSnapshotSignature = "";
            lastWorld = mc.field_1687;
            needsRefresh = true;
        }

        captureOriginalObjective();
        if (originalObjective == null) {
            return;
        }

        class_269 scoreboard = mc.field_1687.method_8428();
        if (!scoreboard.method_1151().contains(originalObjective)) {
            originalObjective = null;
            captureOriginalObjective();
            if (originalObjective == null) {
                return;
            }
        }

        Snapshot snapshot = createSnapshot(scoreboard, originalObjective);
        if (snapshot == null) {
            return;
        }

        syncAppliedStatsWithSettings();

        if (!snapshot.signature().equals(lastSnapshotSignature) || customObjective == null) {
            needsRefresh = true;
        }

        rebuildIfPossible(scoreboard, snapshot);

        if (customObjective != null && scoreboard.method_1189(class_8646.field_45157) != customObjective) {
            scoreboard.method_1158(class_8646.field_45157, customObjective);
        }
    }

    private void randomizeSettings() {
        money.setValue(formatCompactNumber(randomBetweenLong(10_000L, 5_000_000_000L)));
        shards.setValue(formatCompactNumber(randomBetweenLong(0L, 2_500_000L)));
        kills.setValue(String.valueOf(randomBetweenLong(0L, 2_000L)));
        deaths.setValue(String.valueOf(randomBetweenLong(0L, 1_000L)));
        playtime.setValue(formatCompactPlaytime(randomBetweenLong(0L, 180L * 24L * 60L * 60L)));
    }

    private void applyCurrentValues() {
        appliedStats = new AppliedStats(
                sanitize(money.getValue(), "0"),
                sanitize(shards.getValue(), "0"),
                sanitize(kills.getValue(), "0"),
                sanitize(deaths.getValue(), "0"),
                sanitize(playtime.getValue(), "0m")
        );
        needsRefresh = true;
    }

    private void syncAppliedStatsWithSettings() {
        AppliedStats current = new AppliedStats(
                sanitize(money.getValue(), "0"),
                sanitize(shards.getValue(), "0"),
                sanitize(kills.getValue(), "0"),
                sanitize(deaths.getValue(), "0"),
                sanitize(playtime.getValue(), "0m")
        );
        if (appliedStats == null || !appliedStats.signature().equals(current.signature())) {
            appliedStats = current;
            needsRefresh = true;
        }
    }

    private void captureOriginalObjective() {
        if (mc.field_1687 == null) {
            return;
        }

        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 current = scoreboard.method_1189(class_8646.field_45157);
        if (current != null && !OBJECTIVE_NAME.equals(current.method_1113())) {
            originalObjective = current;
            originalObjectiveName = current.method_1113();
            return;
        }

        if (originalObjective != null && scoreboard.method_1151().contains(originalObjective)) {
            return;
        }

        if (originalObjectiveName != null) {
            class_266 namedObjective = scoreboard.method_1170(originalObjectiveName);
            if (namedObjective != null && !OBJECTIVE_NAME.equals(namedObjective.method_1113())) {
                originalObjective = namedObjective;
                return;
            }
        }

        for (class_266 objective : scoreboard.method_1151()) {
            if (!OBJECTIVE_NAME.equals(objective.method_1113())) {
                originalObjective = objective;
                originalObjectiveName = objective.method_1113();
                return;
            }
        }
    }

    private Snapshot createSnapshot(class_269 scoreboard, class_266 objective) {
        List<SourceLine> lines = new ArrayList<>();
        List<class_9011> entries = new ArrayList<>(scoreboard.method_1184(objective));
        entries.removeIf(class_9011::method_55385);
        entries.sort(Comparator.comparingInt(class_9011::comp_2128).reversed());
        if (entries.size() > MAX_SIDEBAR_LINES) {
            entries = new ArrayList<>(entries.subList(0, MAX_SIDEBAR_LINES));
        }

        for (class_9011 entry : entries) {
            lines.add(new SourceLine(entry.comp_2128(), getVisibleLine(scoreboard, entry)));
        }

        class_2561 title = objective.method_1114() != null ? objective.method_1114().method_27661() : class_2561.method_43470("Donut SMP");

        StringBuilder signature = new StringBuilder(title.getString());
        for (SourceLine line : lines) {
            signature.append('\n').append(line.score()).append(':').append(line.text().getString());
        }
        signature.append('\n').append(appliedStats != null ? appliedStats.signature() : "");
        return new Snapshot(title, lines, signature.toString());
    }

    private class_2561 getVisibleLine(class_269 scoreboard, class_9011 entry) {
        if (entry.comp_2129() != null) {
            return entry.comp_2129().method_27661();
        }

        class_2561 baseText = entry.method_55387() != null ? entry.method_55387().method_27661() : class_2561.method_43470(entry.comp_2127());
        class_268 team = scoreboard.method_1164(entry.comp_2127());
        return class_268.method_1142(team, baseText).method_27661();
    }

    private void rebuildIfPossible(class_269 scoreboard, Snapshot snapshot) {
        if (!needsRefresh || appliedStats == null) {
            return;
        }

        class_266 existing = scoreboard.method_1170(OBJECTIVE_NAME);
        if (existing != null) {
            scoreboard.method_1194(existing);
        }

        customObjective = scoreboard.method_1168(
                OBJECTIVE_NAME,
                class_274.field_1468,
                snapshot.title().method_27661(),
                class_274.class_275.field_1472,
                true,
                class_9020.field_47557
        );
        scoreboard.method_1158(class_8646.field_45157, customObjective);

        List<SourceLine> lines = snapshot.lines();
        for (int i = 0; i < lines.size(); i++) {
            SourceLine line = lines.get(i);
            class_9015 holder = class_9015.method_55422("fake_stats_line_" + i);
            class_9014 score = scoreboard.method_1180(holder, customObjective);
            score.method_55410(lines.size() - i);
            score.method_55411(replaceTrackedStat(line.text()));
            score.method_55412(class_9020.field_47557);
        }

        lastSnapshotSignature = snapshot.signature();
        needsRefresh = false;
    }

    private class_2561 replaceTrackedStat(class_2561 originalText) {
        class_2561 replaced = tryReplaceValue(originalText, "money", appliedStats.money());
        if (replaced != null) {
            return replaced;
        }

        replaced = tryReplaceValue(originalText, "shards", appliedStats.shards());
        if (replaced != null) {
            return replaced;
        }

        replaced = tryReplaceValue(originalText, "kills", appliedStats.kills());
        if (replaced != null) {
            return replaced;
        }

        replaced = tryReplaceValue(originalText, "deaths", appliedStats.deaths());
        if (replaced != null) {
            return replaced;
        }

        replaced = tryReplaceValue(originalText, "playtime", appliedStats.playtime());
        if (replaced != null) {
            return replaced;
        }

        return originalText.method_27661();
    }

    private class_2561 tryReplaceValue(class_2561 originalText, String label, String newValue) {
        String rendered = originalText.getString();
        int valueStart = findValueStart(rendered, label);
        if (valueStart < 0) {
            return null;
        }

        List<TextSegment> segments = collectSegments(originalText);
        class_5250 result = class_2561.method_43473();
        appendTextRange(result, segments, valueStart);
        result.method_10852(class_2561.method_43470(newValue).method_10862(findStyleAt(segments, valueStart)));
        return result;
    }

    private int findValueStart(String rendered, String label) {
        String lower = rendered.toLowerCase(Locale.ROOT);
        int labelIndex = lower.indexOf(label);
        if (labelIndex < 0) {
            return -1;
        }

        int index = labelIndex + label.length();
        while (index < rendered.length() && Character.isWhitespace(rendered.charAt(index))) {
            index++;
        }
        return index < rendered.length() ? index : -1;
    }

    private List<TextSegment> collectSegments(class_2561 text) {
        List<TextSegment> segments = new ArrayList<>();
        text.method_27658((style, string) -> {
            if (!string.isEmpty()) {
                segments.add(new TextSegment(string, style));
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return segments;
    }

    private void appendTextRange(class_5250 result, List<TextSegment> segments, int endExclusive) {
        int remaining = Math.max(0, endExclusive);
        for (TextSegment segment : segments) {
            if (remaining <= 0) {
                return;
            }

            String value = segment.value();
            int length = Math.min(value.length(), remaining);
            result.method_10852(class_2561.method_43470(value.substring(0, length)).method_10862(segment.style()));
            remaining -= length;
        }
    }

    private class_2583 findStyleAt(List<TextSegment> segments, int charIndex) {
        int index = Math.max(0, charIndex);
        class_2583 fallback = class_2583.field_24360;
        for (TextSegment segment : segments) {
            if (!segment.value().isEmpty()) {
                fallback = segment.style();
            }
            if (index < segment.value().length()) {
                return segment.style();
            }
            index -= segment.value().length();
        }
        return fallback;
    }

    private void restoreOriginalScoreboard() {
        if (mc.field_1687 == null) {
            return;
        }

        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 existing = scoreboard.method_1170(OBJECTIVE_NAME);
        if (existing != null) {
            scoreboard.method_1194(existing);
        }

        if (originalObjective != null && scoreboard.method_1151().contains(originalObjective)) {
            scoreboard.method_1158(class_8646.field_45157, originalObjective);
        }
    }

    private long randomBetweenLong(long min, long max) {
        if (min >= max) {
            return min;
        }
        return min + (long) Math.floor(randomSource.nextDouble() * (double) (max - min + 1L));
    }

    private String formatCompactNumber(long value) {
        long absolute = Math.abs(value);
        if (absolute < 1_000L) {
            return Long.toString(value);
        }
        if (absolute < 1_000_000L) {
            return formatCompactValue(value / 1_000.0, "K");
        }
        if (absolute < 1_000_000_000L) {
            return formatCompactValue(value / 1_000_000.0, "M");
        }
        return formatCompactValue(value / 1_000_000_000.0, "B");
    }

    private String formatCompactValue(double value, String suffix) {
        String pattern = value >= 100.0 ? "%.0f%s" : value >= 10.0 ? "%.1f%s" : "%.2f%s";
        return String.format(Locale.US, pattern, value, suffix);
    }

    private String formatCompactPlaytime(long totalSeconds) {
        long totalHours = totalSeconds / 3600L;
        long totalDays = totalHours / 24L;
        long hours = totalHours % 24L;
        long minutes = (totalSeconds % 3600L) / 60L;

        if (totalDays > 0L) {
            return String.format(Locale.US, "%dd %dh", totalDays, hours);
        }
        if (totalHours > 0L) {
            return String.format(Locale.US, "%dh %dm", totalHours, minutes);
        }
        return String.format(Locale.US, "%dm", minutes);
    }

    private String sanitize(String value, String fallback) {
        if (value == null) {
            return fallback;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? fallback : trimmed;
    }

    private record TextSegment(String value, class_2583 style) {
    }

    private record SourceLine(int score, class_2561 text) {
    }

    private record Snapshot(class_2561 title, List<SourceLine> lines, String signature) {
    }

    private record AppliedStats(String money, String shards, String kills, String deaths, String playtime) {
        private String signature() {
            return money + "|" + shards + "|" + kills + "|" + deaths + "|" + playtime;
        }
    }
}
