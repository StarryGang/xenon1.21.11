package com.xenon.module.modules.donut;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;

public final class AntiTrap extends Module {

    private final Setting<Boolean> armorStands = new Setting<>("Armor Stands", true);
    private final Setting<Boolean> minecarts = new Setting<>("Minecarts", true);
    private final Setting<Boolean> chestMinecarts = new Setting<>("Chest Minecarts", true);
    private final Setting<Boolean> hopperMinecarts = new Setting<>("Hopper Minecarts", true);

    public AntiTrap() {
        super("AntiTrap", Category.DONUT);
        addSetting(armorStands);
        addSetting(minecarts);
        addSetting(chestMinecarts);
        addSetting(hopperMinecarts);
    }

    @Override
    public void onEnable() {
        removeTrapEntities();
    }

    @Override
    public void onTick() {
        removeTrapEntities();
    }

    private void removeTrapEntities() {
        if (mc.field_1687 == null) return;
        List<class_1297> trapEntities = new ArrayList<>();
        mc.field_1687.method_18112().forEach(entity -> {
            if (entity != null && isTrapEntity(entity.method_5864())) {
                trapEntities.add(entity);
            }
        });
        trapEntities.forEach(e -> {
            if (!e.method_31481()) e.method_5650(class_1297.class_5529.field_26999);
        });
    }

    private boolean isTrapEntity(class_1299<?> type) {
        if (type == null) return false;
        if (armorStands.getValue() && type.equals(class_1299.field_6131)) return true;
        if (minecarts.getValue() && type.equals(class_1299.field_6096)) return true;
        if (chestMinecarts.getValue() && type.equals(class_1299.field_6126)) return true;
        if (hopperMinecarts.getValue() && type.equals(class_1299.field_6058)) return true;
        return false;
    }
}
