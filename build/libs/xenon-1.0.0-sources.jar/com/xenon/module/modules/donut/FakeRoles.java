package com.xenon.module.modules.donut;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.ModeSetting;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public final class FakeRoles extends Module {
   public static FakeRoles instance;
   private static final String MODE_NONE = "None";
   private static final String MODE_SRMOD = "SRMOD";
   private static final String MODE_MEDIA = "MEDIA";
   private static final String MODE_SRADMIN = "SRADMIN";
   private static final int TAG_BRACKET = 8355711;
   private static final int TAG_SRMOD = 5635925;
   private static final int TAG_MEDIA = 16733695;
   private static final int TAG_SRADMIN = 16733525;
   private static final int TAG_WHITE = 16777215;
   private final ModeSetting role = new ModeSetting("Role", "None", new String[]{"None", "SRMOD", "MEDIA", "SRADMIN"});

   public FakeRoles() {
      super("FakeRoles", Category.DONUT);
      instance = this;
      this.addSetting(this.role);
   }

   public static boolean isActive() {
      return instance != null && instance.isEnabled() && !instance.role.is("None") && mc != null && mc.field_1724 != null;
   }

   public static String getActiveRole() {
      return !isActive() ? null : (String)instance.role.getValue();
   }

   public static String getPlayerName() {
      return mc != null && mc.method_1548() != null ? mc.method_1548().method_1676() : null;
   }

   public static class_2561 modifyChatText(class_2561 original) {
      if (isActive() && original != null) {
         String playerName = getPlayerName();
         if (playerName != null && !playerName.isBlank()) {
            String plain = original.getString();
            if (!plain.contains(playerName)) {
               return original;
            } else {
               class_2561 prefixed = buildPrefixedName(playerName);
               int idx = plain.indexOf(playerName);
               class_5250 result = class_2561.method_43473();
               if (idx > 0) {
                  result.method_10852(class_2561.method_43470(plain.substring(0, idx)));
               }

               result.method_10852(prefixed);
               int afterIdx = idx + playerName.length();
               if (afterIdx < plain.length()) {
                  result.method_10852(class_2561.method_43470(plain.substring(afterIdx)));
               }

               return result;
            }
         } else {
            return original;
         }
      } else {
         return original;
      }
   }

   public static class_2561 buildPrefixedDisplayName(String playerName) {
      return isActive() && playerName != null ? buildPrefixedName(playerName) : null;
   }

   public static String getPrefixedNameString() {
      if (!isActive()) {
         return null;
      } else {
         String playerName = getPlayerName();
         if (playerName == null) {
            return null;
         } else {
            class_2561 prefixed = buildPrefixedName(playerName);
            return prefixed.getString();
         }
      }
   }

   public static class_2583 getRolePrefixStyle() {
      if (!isActive()) {
         return class_2583.field_24360;
      } else {
         String activeRole = (String)instance.role.getValue();

         return switch (activeRole) {
            case "SRMOD" -> roleStyle(5635925);
            case "MEDIA" -> roleStyle(16733695);
            case "SRADMIN" -> roleStyle(16733525);
            default -> class_2583.field_24360;
         };
      }
   }

   public static class_2583 getRoleBracketStyle() {
      return isActive() ? class_2583.field_24360.method_27703(class_5251.method_27717(8355711)).method_10982(false) : class_2583.field_24360;
   }

   public static class_2583 getRolePrefixStyleForChar(int codePoint) {
      return codePoint != 91 && codePoint != 93 && !Character.isWhitespace(codePoint) ? getRolePrefixStyle() : getRoleBracketStyle();
   }

   public static class_2583 getRoleNameStyle() {
      if (!isActive()) {
         return class_2583.field_24360;
      } else {
         String activeRole = (String)instance.role.getValue();

         return switch (activeRole) {
            case "SRMOD" -> roleStyle(5635925);
            case "MEDIA" -> class_2583.field_24360.method_27703(class_5251.method_27717(16777215)).method_10982(false);
            case "SRADMIN" -> roleStyle(16733525);
            default -> class_2583.field_24360;
         };
      }
   }

   public static String getRolePrefixString() {
      if (!isActive()) {
         return null;
      } else {
         String activeRole = (String)instance.role.getValue();

         return switch (activeRole) {
            case "SRMOD" -> "[SR.MOD] ";
            case "MEDIA" -> "[MEDIA] ";
            case "SRADMIN" -> "[SR.ADMIN] ";
            default -> null;
         };
      }
   }

   private static class_2561 buildPrefixedName(String playerName) {
      String activeRole = (String)instance.role.getValue();

      return (class_2561)(switch (activeRole) {
         case "SRMOD" -> buildSrmodName(playerName);
         case "MEDIA" -> buildMediaName(playerName);
         case "SRADMIN" -> buildSradminName(playerName);
         default -> class_2561.method_43470(playerName);
      });
   }

   private static class_2561 buildSrmodName(String playerName) {
      class_5250 result = class_2561.method_43473();
      appendTag(result, "SR.MOD", roleStyle(5635925));
      result.method_10852(class_2561.method_43470(playerName).method_10862(getRoleNameStyle()));
      return result;
   }

   private static class_2561 buildMediaName(String playerName) {
      class_5250 result = class_2561.method_43473();
      appendTag(result, "MEDIA", roleStyle(16733695));
      result.method_10852(class_2561.method_43470(playerName).method_10862(getRoleNameStyle()));
      return result;
   }

   private static class_2561 buildSradminName(String playerName) {
      class_5250 result = class_2561.method_43473();
      appendTag(result, "SR.ADMIN", roleStyle(16733525));
      result.method_10852(class_2561.method_43470(playerName).method_10862(getRoleNameStyle()));
      return result;
   }

   private static void appendTag(class_5250 result, String roleText, class_2583 roleStyle) {
      class_2583 bracketStyle = class_2583.field_24360.method_27703(class_5251.method_27717(8355711)).method_10982(false);
      result.method_10852(class_2561.method_43470("[").method_10862(bracketStyle));
      result.method_10852(class_2561.method_43470(roleText).method_10862(roleStyle));
      result.method_10852(class_2561.method_43470("] ").method_10862(bracketStyle));
   }

   private static class_2583 roleStyle(int rgb) {
      return class_2583.field_24360.method_27703(class_5251.method_27717(rgb)).method_10982(true);
   }
}
