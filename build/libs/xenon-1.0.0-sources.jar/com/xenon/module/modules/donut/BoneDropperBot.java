package com.xenon.module.modules.donut;

import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.ModeSetting;
import com.xenon.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_634;

public final class BoneDropperBot extends Module {
    private static final int MIN_DELAY_MS = 100;
    private static final int MAX_DELAY_MS = 2000;
    private static final int DEFAULT_DELAY_MS = 300;
    private static final int PLAYER_INVENTORY_SLOT_COUNT = 36;
    private static final int PRIMARY_CLICK_BUTTON = 0;
    private static final long SPAWNER_DROP_TIMEOUT_MS = 4_000L;

    private final ModeSetting mode = new ModeSetting("Mode", "Spawner", "Spawner", "Orders");
    private final Setting<Integer> delayMs = new Setting<>("Delay", DEFAULT_DELAY_MS, MIN_DELAY_MS, MAX_DELAY_MS);

    private BotState state = BotState.SPAWNER_OPEN_MENU;
    private String lastMode = mode.getValue();
    private long nextActionAtMs;
    private int spawnerBoneCountBeforeDrop;
    private long spawnerDropRequestedAtMs;
    private boolean spawnerGridWasFullBeforeDrop;

    public BoneDropperBot() {
        super("BoneDropper", Category.DONUT);
        addSetting(mode);
        addSetting(delayMs);
    }

    @Override
    public void onEnable() {
        resetState();
    }

    @Override
    public void onDisable() {
        state = BotState.SPAWNER_OPEN_MENU;
        nextActionAtMs = 0L;
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }
        if (mc.field_1755 != null && !(mc.field_1755 instanceof class_465<?>)) {
            return;
        }

        if (!mode.getValue().equalsIgnoreCase(lastMode)) {
            resetState();
        }

        long now = System.currentTimeMillis();
        if (now < nextActionAtMs) {
            return;
        }

        if (mode.is("Spawner")) {
            tickSpawnerMode();
        } else {
            tickOrdersMode();
        }
    }

    private void tickSpawnerMode() {
        switch (state) {
            case SPAWNER_OPEN_MENU -> {
                if (isHandledMenuOpen()) {
                    state = BotState.SPAWNER_WAIT_MENU;
                    scheduleNextAction();
                    return;
                }

                interactWithTargetBlock();
                state = BotState.SPAWNER_WAIT_MENU;
                scheduleNextAction();
            }
            case SPAWNER_WAIT_MENU -> {
                if (!isHandledMenuOpen()) {
                    state = BotState.SPAWNER_OPEN_MENU;
                    scheduleNextAction();
                    return;
                }

                state = BotState.SPAWNER_SCAN_GRID;
                scheduleNextAction();
            }
            case SPAWNER_SCAN_GRID -> {
                class_1703 handler = getMenuHandler();
                if (handler == null) {
                    state = BotState.SPAWNER_OPEN_MENU;
                    scheduleNextAction();
                    return;
                }

                if (!isSpawnerGridFull(handler)) {
                    scheduleNextAction();
                    return;
                }

                state = BotState.SPAWNER_CLICK_DROPPER;
                scheduleNextAction();
            }
            case SPAWNER_CLICK_DROPPER -> {
                class_1703 handler = getMenuHandler();
                if (handler == null) {
                    state = BotState.SPAWNER_OPEN_MENU;
                    scheduleNextAction();
                    return;
                }

                class_1735 dropperSlot = findSpawnerDropperSlot(handler);
                if (dropperSlot == null) {
                    scheduleNextAction();
                    return;
                }

                spawnerGridWasFullBeforeDrop = isSpawnerGridFull(handler);
                if (!spawnerGridWasFullBeforeDrop) {
                    state = BotState.SPAWNER_SCAN_GRID;
                    scheduleNextAction();
                    return;
                }

                spawnerBoneCountBeforeDrop = countInventoryItem(class_1802.field_8606);
                spawnerDropRequestedAtMs = System.currentTimeMillis();
                clickSlot(dropperSlot);
                state = BotState.SPAWNER_WAIT_DROP_CONFIRM;
                scheduleNextAction();
            }
            case SPAWNER_WAIT_DROP_CONFIRM -> {
                long now = System.currentTimeMillis();
                class_1703 handler = getMenuHandler();
                boolean gridCleared = spawnerGridWasFullBeforeDrop && handler != null && !isSpawnerGridFull(handler);
                boolean gainedBones = countInventoryItem(class_1802.field_8606) > spawnerBoneCountBeforeDrop;

                if (gridCleared || gainedBones) {
                    if (handler != null) {
                        closeMenu();
                    }
                    state = BotState.SPAWNER_DONE;
                    nextActionAtMs = Long.MAX_VALUE;
                    return;
                }

                if (spawnerDropRequestedAtMs > 0L && now - spawnerDropRequestedAtMs > SPAWNER_DROP_TIMEOUT_MS) {
                    state = handler == null ? BotState.SPAWNER_OPEN_MENU : BotState.SPAWNER_SCAN_GRID;
                    scheduleNextAction();
                    return;
                }

                scheduleNextAction();
            }
            case SPAWNER_DONE -> {
            }
            default -> {
                state = BotState.SPAWNER_OPEN_MENU;
                scheduleNextAction();
            }
        }
    }

    private void tickOrdersMode() {
        switch (state) {
            case ORDERS_SEND_COMMAND -> {
                if (!isHandledMenuOpen()) {
                    sendServerCommand("/order");
                    state = BotState.ORDERS_WAIT_MENU;
                    scheduleNextAction();
                    return;
                }

                state = BotState.ORDERS_CLICK_CHEST_ONE;
                scheduleNextAction();
            }
            case ORDERS_WAIT_MENU -> {
                if (!isHandledMenuOpen()) {
                    sendServerCommand("/order");
                    scheduleNextAction();
                    return;
                }

                state = BotState.ORDERS_CLICK_CHEST_ONE;
                scheduleNextAction();
            }
            case ORDERS_CLICK_CHEST_ONE -> handleOrdersClickStep(MenuTarget.CHEST, BotState.ORDERS_CLICK_BONE);
            case ORDERS_CLICK_BONE -> handleOrdersClickStep(MenuTarget.BONE, BotState.ORDERS_CLICK_CHEST_TWO);
            case ORDERS_CLICK_CHEST_TWO -> handleOrdersClickStep(MenuTarget.CHEST, BotState.ORDERS_CLICK_DROPPER_ONE);
            case ORDERS_CLICK_DROPPER_ONE -> handleOrdersClickStep(MenuTarget.DROPPER, BotState.ORDERS_CLICK_ARROW);
            case ORDERS_CLICK_ARROW -> handleOrdersClickStep(MenuTarget.ARROW, BotState.ORDERS_CLICK_DROPPER_TWO);
            case ORDERS_CLICK_DROPPER_TWO -> handleOrdersClickStep(MenuTarget.DROPPER, BotState.ORDERS_CLICK_CHEST_ONE);
            default -> {
                state = BotState.ORDERS_SEND_COMMAND;
                scheduleNextAction();
            }
        }
    }

    private void handleOrdersClickStep(MenuTarget target, BotState nextState) {
        class_1703 handler = getMenuHandler();
        if (handler == null) {
            sendServerCommand("/order");
            scheduleNextAction();
            return;
        }

        class_1735 slot = findUpperMenuSlot(handler, target, target == MenuTarget.DROPPER || target == MenuTarget.ARROW);
        if (slot == null) {
            scheduleNextAction();
            return;
        }

        clickSlot(slot);
        state = nextState;
        scheduleNextAction();
    }

    private boolean isSpawnerGridFull(class_1703 handler) {
        List<class_1735> gridSlots = getSpawnerGridSlots(handler);
        if (gridSlots.isEmpty()) {
            return false;
        }

        for (class_1735 slot : gridSlots) {
            if (!slot.method_7682()) {
                continue;
            }

            class_1799 stack = slot.method_7677();
            if (stack.method_7960() || !matchesTarget(stack, MenuTarget.BONE)) {
                return false;
            }
        }

        return true;
    }

    private List<class_1735> getSpawnerGridSlots(class_1703 handler) {
        List<class_1735> upperSlots = getUpperMenuSlots(handler);
        if (upperSlots.isEmpty()) {
            return List.of();
        }

        int maxY = upperSlots.stream().mapToInt(slot -> slot.field_7872).max().orElse(Integer.MIN_VALUE);
        List<class_1735> gridSlots = new ArrayList<>();
        for (class_1735 slot : upperSlots) {
            if (slot.field_7872 < maxY) {
                gridSlots.add(slot);
            }
        }

        return gridSlots.isEmpty() ? upperSlots : gridSlots;
    }

    private class_1735 findSpawnerDropperSlot(class_1703 handler) {
        List<class_1735> upperSlots = getUpperMenuSlots(handler);
        if (upperSlots.isEmpty()) {
            return null;
        }

        int maxY = upperSlots.stream().mapToInt(slot -> slot.field_7872).max().orElse(Integer.MIN_VALUE);
        class_1735 controlDropper = chooseBestMatchingSlot(upperSlots, MenuTarget.DROPPER, true, maxY);
        if (controlDropper != null) {
            return controlDropper;
        }

        class_1735 anyDropper = chooseBestMatchingSlot(upperSlots, MenuTarget.DROPPER, true, Integer.MIN_VALUE);
        if (anyDropper != null) {
            return anyDropper;
        }

        for (int i = upperSlots.size() - 1; i >= 0; i--) {
            class_1735 slot = upperSlots.get(i);
            if (slot.method_7682()) {
                return slot;
            }
        }

        return null;
    }

    private class_1735 findUpperMenuSlot(class_1703 handler, MenuTarget target, boolean preferBottomRight) {
        return chooseBestMatchingSlot(getUpperMenuSlots(handler), target, preferBottomRight, Integer.MIN_VALUE);
    }

    private class_1735 chooseBestMatchingSlot(List<class_1735> slots, MenuTarget target, boolean preferBottomRight, int yFilter) {
        class_1735 best = null;
        for (class_1735 slot : slots) {
            if (!slot.method_7682()) {
                continue;
            }
            if (yFilter != Integer.MIN_VALUE && slot.field_7872 != yFilter) {
                continue;
            }
            if (!matchesTarget(slot.method_7677(), target)) {
                continue;
            }

            if (best == null) {
                best = slot;
                continue;
            }

            if (preferBottomRight) {
                if (slot.field_7872 > best.field_7872 || (slot.field_7872 == best.field_7872 && slot.field_7873 >= best.field_7873)) {
                    best = slot;
                }
            } else if (slot.field_7872 < best.field_7872 || (slot.field_7872 == best.field_7872 && slot.field_7873 < best.field_7873)) {
                best = slot;
            }
        }
        return best;
    }

    private boolean matchesTarget(class_1799 stack, MenuTarget target) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        class_1792 item = stack.method_7909();
        String lowerName = stack.method_7964().getString().toLowerCase(Locale.ROOT);

        return switch (target) {
            case BONE -> item == class_1802.field_8606 || lowerName.contains("bone");
            case CHEST -> item == class_1802.field_8106
                    || item == class_1802.field_8247
                    || item == class_1802.field_8466
                    || lowerName.contains("chest")
                    || lowerName.contains("truhe");
            case DROPPER -> item == class_1802.field_8878 || lowerName.contains("dropper");
            case ARROW -> item == class_1802.field_8107 || lowerName.contains("arrow") || lowerName.contains("pfeil");
        };
    }

    private List<class_1735> getUpperMenuSlots(class_1703 handler) {
        if (handler == null || handler.field_7761 == null || handler.field_7761.isEmpty()) {
            return List.of();
        }

        int upperSlotCount = Math.max(0, handler.field_7761.size() - PLAYER_INVENTORY_SLOT_COUNT);
        if (upperSlotCount == 0) {
            upperSlotCount = handler.field_7761.size();
        }

        List<class_1735> upperSlots = new ArrayList<>(upperSlotCount);
        for (int i = 0; i < upperSlotCount; i++) {
            upperSlots.add(handler.field_7761.get(i));
        }
        return upperSlots;
    }

    private int countInventoryItem(class_1792 item) {
        if (mc.field_1724 == null) {
            return 0;
        }

        int count = 0;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_31574(item)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private void clickSlot(class_1735 slot) {
        if (slot == null || mc.field_1724 == null || mc.field_1761 == null) {
            return;
        }

        mc.field_1761.method_2906(
                mc.field_1724.field_7512.field_7763,
                slot.field_7874,
                PRIMARY_CLICK_BUTTON,
                class_1713.field_7790,
                mc.field_1724
        );
    }

    private void interactWithTargetBlock() {
        if (!(mc.field_1765 instanceof class_3965 hit) || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
            return;
        }

        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void closeMenu() {
        if (mc.field_1724 == null) {
            return;
        }

        if (mc.field_1755 instanceof class_465<?>) {
            mc.field_1724.method_7346();
            mc.method_1507(null);
        }
    }

    private class_1703 getMenuHandler() {
        if (!(mc.field_1755 instanceof class_465<?>) || mc.field_1724 == null) {
            return null;
        }
        return mc.field_1724.field_7512;
    }

    private boolean isHandledMenuOpen() {
        return getMenuHandler() != null;
    }

    private void sendServerCommand(String command) {
        class_634 networkHandler = mc.field_1724 != null ? mc.field_1724.field_3944 : mc.method_1562();
        if (networkHandler == null) {
            return;
        }

        String commandWithoutSlash = command.startsWith("/") ? command.substring(1) : command;
        try {
            networkHandler.method_45730(commandWithoutSlash);
        } catch (Throwable ignored) {
            networkHandler.method_45729(command);
        }
    }

    private void resetState() {
        lastMode = mode.getValue();
        state = mode.is("Spawner") ? BotState.SPAWNER_OPEN_MENU : BotState.ORDERS_SEND_COMMAND;
        nextActionAtMs = 0L;
        spawnerBoneCountBeforeDrop = 0;
        spawnerDropRequestedAtMs = 0L;
        spawnerGridWasFullBeforeDrop = false;
    }

    private void scheduleNextAction() {
        nextActionAtMs = System.currentTimeMillis() + delayMs.getValue();
    }

    private enum MenuTarget {
        BONE,
        CHEST,
        DROPPER,
        ARROW
    }

    private enum BotState {
        SPAWNER_OPEN_MENU,
        SPAWNER_WAIT_MENU,
        SPAWNER_SCAN_GRID,
        SPAWNER_CLICK_DROPPER,
        SPAWNER_WAIT_DROP_CONFIRM,
        SPAWNER_DONE,
        ORDERS_SEND_COMMAND,
        ORDERS_WAIT_MENU,
        ORDERS_CLICK_CHEST_ONE,
        ORDERS_CLICK_BONE,
        ORDERS_CLICK_CHEST_TWO,
        ORDERS_CLICK_DROPPER_ONE,
        ORDERS_CLICK_ARROW,
        ORDERS_CLICK_DROPPER_TWO
    }
}
