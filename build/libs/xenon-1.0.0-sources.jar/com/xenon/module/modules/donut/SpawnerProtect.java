package com.xenon.module.modules.donut;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.xenon.XenonClient;
import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.module.modules.client.Friends;
import com.xenon.setting.Setting;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3965;
import net.minecraft.class_642;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class SpawnerProtect extends Module {
    private static final String SILK_TOUCH_REQUIRED = "Need a Silk Touch pickaxe in hotbar";
    private static final int SCAN_RADIUS = 32;
    private static final double MAX_BREAK_REACH = 5.0;
    private static final Duration HTTP_TIMEOUT = Duration.ofSeconds(8);
    private static final int SUCCESS_COLOR = 0x55D4A2;
    private static final int ERROR_COLOR = 0xE26A6A;
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder()
            .connectTimeout(HTTP_TIMEOUT)
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private final Setting<Integer> criticalDistance = new Setting<>("Critical Distance", 5, 1, 20);
    private final Setting<String> webhookUrl = new Setting<>("Webhook", "") {
        @Override
        public boolean matchesName(String settingName) {
            return super.matchesName(settingName) || "Webhook URL".equalsIgnoreCase(settingName);
        }
    };

    private class_2338 currentTarget;
    private boolean disconnectScheduled;
    private int minedSpawnerCount;

    public SpawnerProtect() {
        super("SpawnerProtect", Category.DONUT);
        addSetting(criticalDistance);
        addSetting(webhookUrl);
    }

    @Override
    public void onEnable() {
        resetRuntimeState();
        if (!hasSilkTouchPickaxeInHotbar()) {
            disconnectAndDisable(SILK_TOUCH_REQUIRED);
        }
    }

    @Override
    public void onDisable() {
        stopMining();
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) {
            return;
        }

        if (disconnectScheduled) {
            return;
        }

        if (!hasSilkTouchPickaxeInHotbar()) {
            disconnectAndDisable(SILK_TOUCH_REQUIRED);
            return;
        }

        EnemyStatus enemyStatus = getEnemyStatus();
        if (enemyStatus.hasCriticalThreat()) {
            fireWebhookThenDisconnect(captureCriticalSnapshot(enemyStatus.threat(), enemyStatus.distance()));
            return;
        }

        if (!enemyStatus.hasAnyEnemy()) {
            stopMining();
            return;
        }

        int silkSlot = findSilkTouchPickaxeHotbarSlot();
        if (silkSlot == -1) {
            disconnectAndDisable(SILK_TOUCH_REQUIRED);
            return;
        }

        selectHotbarSlot(silkSlot);
        applySneak();

        if (currentTarget == null || !isSpawner(currentTarget) || !mc.field_1724.method_56093(currentTarget, MAX_BREAK_REACH)) {
            currentTarget = findClosestSpawner();
            if (currentTarget == null) {
                fireWebhookThenDisconnect(captureSuccessSnapshot());
                return;
            }
        }

        class_2350 side = getClosestFace(currentTarget);
        lookAtSpawner(currentTarget, side);
        mc.field_1761.method_2902(currentTarget, side);
        mc.field_1687.method_74254(currentTarget, side);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (!isSpawner(currentTarget)) {
            minedSpawnerCount++;
            currentTarget = null;
        }
    }

    private EnemyStatus getEnemyStatus() {
        double criticalDistanceSq = square(criticalDistance.getValue());
        boolean anyEnemy = false;
        boolean criticalThreat = false;
        class_1657 threat = null;
        double threatDistance = -1.0;

        for (class_1657 other : mc.field_1687.method_18456()) {
            if (other == mc.field_1724 || other.method_7325() || other.method_5722(mc.field_1724)) {
                continue;
            }
            if (Friends.isSpawnerProtect() && Friends.isFriend(other.method_5477().getString())) {
                continue;
            }

            anyEnemy = true;
            double distanceSq = mc.field_1724.method_5858(other);
            if (distanceSq <= criticalDistanceSq) {
                criticalThreat = true;
                double distance = Math.sqrt(distanceSq);
                if (threat == null || distance < threatDistance) {
                    threat = other;
                    threatDistance = distance;
                }
                break;
            }
        }

        return new EnemyStatus(anyEnemy, criticalThreat, threat, threatDistance);
    }

    private class_2338 findClosestSpawner() {
        List<class_2338> spawners = new ArrayList<>();
        class_2338 center = mc.field_1724.method_24515();
        int radiusSq = SCAN_RADIUS * SCAN_RADIUS;

        for (int x = -SCAN_RADIUS; x <= SCAN_RADIUS; x++) {
            for (int y = -SCAN_RADIUS; y <= SCAN_RADIUS; y++) {
                for (int z = -SCAN_RADIUS; z <= SCAN_RADIUS; z++) {
                    int distSq = x * x + y * y + z * z;
                    if (distSq > radiusSq) {
                        continue;
                    }

                    class_2338 pos = center.method_10069(x, y, z);
                    if (isSpawner(pos) && mc.field_1724.method_56093(pos, MAX_BREAK_REACH)) {
                        spawners.add(pos.method_10062());
                    }
                }
            }
        }

        return spawners.stream()
                .min(Comparator.comparingDouble(this::distanceSqTo))
                .orElse(null);
    }

    private boolean hasSilkTouchPickaxeInHotbar() {
        return findSilkTouchPickaxeHotbarSlot() != -1;
    }

    private int findSilkTouchPickaxeHotbarSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (isSilkTouchPickaxe(mc.field_1724.method_31548().method_5438(slot))) {
                return slot;
            }
        }
        return -1;
    }

    private boolean isSilkTouchPickaxe(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        String itemPath = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
        if (!itemPath.endsWith("_pickaxe")) {
            return false;
        }

        class_6880<net.minecraft.class_1887> silkTouch = mc.field_1687.method_30349()
                .method_30530(class_7924.field_41265)
                .method_47983(mc.field_1687.method_30349().method_30530(class_7924.field_41265).method_29107(class_1893.field_9099));
        return silkTouch != null && class_1890.method_8225(silkTouch, stack) > 0;
    }

    private boolean isSpawner(class_2338 pos) {
        return mc.field_1687 != null && mc.field_1687.method_8320(pos).method_27852(class_2246.field_10260);
    }

    private class_2350 getClosestFace(class_2338 pos) {
        class_243 delta = mc.field_1724.method_33571().method_1020(class_243.method_24953(pos));
        return class_2350.method_10142(delta.field_1352, delta.field_1351, delta.field_1350);
    }

    private void lookAtSpawner(class_2338 pos, class_2350 direction) {
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 target = class_243.method_24953(pos);
        double dx = target.field_1352 - eyePos.field_1352;
        double dy = target.field_1351 - eyePos.field_1351;
        double dz = target.field_1350 - eyePos.field_1350;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontalDist)));

        mc.field_1724.method_36456(yaw);
        mc.field_1724.method_36457(pitch);
        mc.field_1765 = new class_3965(target, direction, pos, false);
    }

    private void selectHotbarSlot(int slot) {
        if (slot >= 0 && slot < 9 && mc.field_1724.method_31548().method_67532() != slot) {
            mc.field_1724.method_31548().method_61496(slot);
        }
    }

    private void applySneak() {
        mc.field_1690.field_1832.method_23481(true);
        mc.field_1724.method_5660(true);
    }

    private void stopMining() {
        currentTarget = null;
        if (mc.field_1761 != null && mc.field_1761.method_2923()) {
            mc.field_1761.method_2925();
        }
        if (mc.field_1724 != null) {
            mc.field_1690.field_1832.method_23481(false);
            mc.field_1724.method_5660(false);
        }
    }

    private void fireWebhookThenDisconnect(WebhookSnapshot snapshot) {
        stopMining();

        String webhook = normalizeWebhook(webhookUrl.getValue());
        if (!isValidWebhook(webhook)) {
            disconnectScheduled = false;
            disconnectAndDisable(snapshot.disconnectReason());
            return;
        }

        disconnectScheduled = true;
        CompletableFuture
                .runAsync(() -> sendWebhook(snapshot), class_156.method_27958().method_64116("coordsnapper-send"))
                .whenComplete((ignored, throwable) -> mc.execute(() -> {
                    if (throwable != null) {
                        XenonClient.LOGGER.error("SpawnerProtect webhook failed", throwable);
                    }
                    disconnectScheduled = false;
                    disconnectAndDisable(snapshot.disconnectReason());
                }));
    }

    private WebhookSnapshot captureSuccessSnapshot() {
        String webhook = normalizeWebhook(webhookUrl.getValue());
        return new WebhookSnapshot(
                webhook,
                "[SpawnerProtect]",
                "All your spawners have been collected.",
                SUCCESS_COLOR,
                mc.field_1724.method_5477().getString(),
                "",
                "",
                countSpawnersInInventory(),
                true,
                resolveServerIp(),
                TIME_FORMATTER.format(LocalTime.now()),
                "https://mc-heads.net/body/" + encodeSkinName(mc.field_1724.method_5477().getString()),
                "SpawnerProtect finished"
        );
    }

    private WebhookSnapshot captureCriticalSnapshot(class_1657 threat, double distance) {
        String webhook = normalizeWebhook(webhookUrl.getValue());
        String threatName = threat != null ? threat.method_5477().getString() : "Unknown";
        return new WebhookSnapshot(
                webhook,
                "[SpawnerProtect]",
                threatName + " came too close.",
                ERROR_COLOR,
                mc.field_1724.method_5477().getString(),
                threatName,
                String.format(Locale.ROOT, "%.1f", distance),
                countSpawnersInInventory(),
                false,
                resolveServerIp(),
                TIME_FORMATTER.format(LocalTime.now()),
                "https://mc-heads.net/body/" + encodeSkinName(threatName),
                "Enemy within critical distance"
        );
    }

    private void sendWebhook(WebhookSnapshot snapshot) {
        JsonObject payload = new JsonObject();
        payload.addProperty("username", "SpawnerProtect");

        JsonObject embed = new JsonObject();
        embed.addProperty("title", snapshot.title());
        embed.addProperty("description", snapshot.description());
        embed.addProperty("color", snapshot.color());

        JsonArray fields = new JsonArray();
        fields.add(createField("Player", snapshot.playerName(), false));
        fields.add(createField("Time", snapshot.time(), true));
        fields.add(createField("Server", snapshot.serverIp(), true));
        fields.add(createField("All spawners mined", snapshot.allMined() ? "✅ Yes" : "❌ No", false));
        fields.add(createField("Spawners in bag", snapshot.spawnersInInventory() + " spawners", false));
        if (!snapshot.threatName().isBlank()) {
            fields.add(createField("Threat", snapshot.threatName() + " (" + snapshot.distance() + " blocks)", false));
        }
        embed.add("fields", fields);

        JsonObject thumbnail = new JsonObject();
        thumbnail.addProperty("url", snapshot.skinRenderUrl());
        embed.add("thumbnail", thumbnail);

        JsonArray embeds = new JsonArray();
        embeds.add(embed);
        payload.add("embeds", embeds);

        HttpRequest request = HttpRequest.newBuilder(buildWebhookUri(snapshot.webhook()))
                .timeout(HTTP_TIMEOUT)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("User-Agent", "Xenon-CoordSnapper")
                .POST(HttpRequest.BodyPublishers.ofString(payload.toString()))
                .build();

        HttpResponse<String> response;
        try {
            response = HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (Exception exception) {
            XenonClient.LOGGER.error("SpawnerProtect webhook request failed", exception);
            throw new IllegalStateException("Webhook request failed", exception);
        }

        int status = response.statusCode();
        if (status >= 200 && status < 300) {
            XenonClient.LOGGER.info("SpawnerProtect webhook sent");
            return;
        }

        String body = response.body();
        if (body != null && !body.isBlank()) {
            XenonClient.LOGGER.warn("SpawnerProtect webhook rejected with status {} and body {}", status, trimSingleLine(body, 240));
            throw new IllegalStateException("HTTP " + status + ": " + trimSingleLine(body, 120));
        }
        XenonClient.LOGGER.warn("SpawnerProtect webhook rejected with status {}", status);
        throw new IllegalStateException("HTTP " + status);
    }

    private JsonObject createField(String name, String value, boolean inline) {
        JsonObject field = new JsonObject();
        field.addProperty("name", name);
        field.addProperty("value", value == null || value.isBlank() ? "-" : value);
        field.addProperty("inline", inline);
        return field;
    }

    private String resolveServerIp() {
        class_642 serverInfo = mc.method_1558();
        if (serverInfo == null || serverInfo.field_3761 == null || serverInfo.field_3761.isBlank()) {
            return "Singleplayer";
        }

        String host = normalizeHost(serverInfo.field_3761);
        return host.isEmpty() ? "Singleplayer" : host;
    }

    private String normalizeHost(String address) {
        String normalized = address == null ? "" : address.trim().toLowerCase(Locale.ROOT);
        int slashIndex = normalized.indexOf('/');
        if (slashIndex >= 0) {
            normalized = normalized.substring(0, slashIndex);
        }
        int colonIndex = normalized.indexOf(':');
        if (colonIndex >= 0) {
            normalized = normalized.substring(0, colonIndex);
        }
        return normalized;
    }

    private String normalizeWebhook(String value) {
        return value == null ? "" : value.trim();
    }

    private String encodeSkinName(String playerName) {
        if (playerName == null || playerName.isBlank()) {
            return "Steve";
        }
        return playerName.trim();
    }

    private URI buildWebhookUri(String webhook) {
        URI uri = URI.create(webhook);
        String query = uri.getQuery();
        if (query == null || query.isBlank()) {
            return URI.create(webhook + "?wait=true");
        }
        if (query.contains("wait=")) {
            return uri;
        }
        return URI.create(webhook + "&wait=true");
    }

    private boolean isValidWebhook(String webhook) {
        if (webhook.isEmpty()) {
            return false;
        }

        try {
            URI uri = URI.create(webhook);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            String path = uri.getPath();
            return ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))
                    && host != null
                    && !host.isBlank()
                    && path != null
                    && path.contains("/api/webhooks/");
        } catch (Exception ignored) {
            return false;
        }
    }

    private String trimSingleLine(String value, int maxLength) {
        if (value == null) {
            return "";
        }
        String trimmed = value.replace('\n', ' ').replace('\r', ' ').trim();
        if (trimmed.length() <= maxLength) {
            return trimmed;
        }
        return trimmed.substring(0, Math.max(0, maxLength - 3)) + "...";
    }

    private int countSpawnersInInventory() {
        int count = 0;
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_31574(class_2246.field_10260.method_8389())) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private void disconnectAndDisable(String reason) {
        if (mc.method_1562() != null && mc.method_1562().method_48296() != null) {
            mc.method_1562().method_48296().method_10747(class_2561.method_43470(reason));
        }
        setEnabled(false);
    }

    private double distanceSqTo(class_2338 pos) {
        return mc.field_1724.method_5707(class_243.method_24953(pos));
    }

    private static double square(int value) {
        return (double) value * value;
    }

    private void resetRuntimeState() {
        currentTarget = null;
        disconnectScheduled = false;
        minedSpawnerCount = 0;
    }

    private record EnemyStatus(boolean hasAnyEnemy, boolean hasCriticalThreat, class_1657 threat, double distance) {
    }

    private record WebhookSnapshot(
            String webhook,
            String title,
            String description,
            int color,
            String playerName,
            String threatName,
            String distance,
            int spawnersInInventory,
            boolean allMined,
            String serverIp,
            String time,
            String skinRenderUrl,
            String disconnectReason
    ) {
    }
}
