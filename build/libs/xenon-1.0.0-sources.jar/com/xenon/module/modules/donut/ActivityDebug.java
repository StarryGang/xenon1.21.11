package com.xenon.module.modules.donut;

import com.xenon.gui.notification.NotificationManager;
import com.xenon.module.Category;
import com.xenon.module.Module;
import com.xenon.setting.Setting;
import com.xenon.utils.RenderUtils;
import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4184;
import net.minecraft.class_4587;

public final class ActivityDebug extends Module {

    private static final long NOTIFY_COOLDOWN_MS = 1250L;
    private static final double MARKER_SURFACE_Y = 57.0D;
    private static final double MARKER_SURFACE_THICKNESS = 0.05D;

    private final Setting<Float> yLevel = new Setting<>("y-level", 16.0f, -64.0f, 320.0f);
    private final Setting<Boolean> notification = new Setting<>("Notification", false);

    private final Set<class_1923> susChunks = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<Long, Long> lastNotifiedAt = new ConcurrentHashMap<>();
    private static final Color YELLOW = new Color(255, 220, 0, 180);
    private static final Color YELLOW_OUTLINE = new Color(255, 220, 0, 255);
    private final Map<Class<?>, List<Field>> doubleFields = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> nestedFields = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> blockPosFields = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> vec3Fields = new ConcurrentHashMap<>();
    private final ThreadLocal<Set<Integer>> exploredObjects = ThreadLocal.withInitial(() ->
            Collections.newSetFromMap(new ConcurrentHashMap<>())
    );

    public ActivityDebug() {
        super("ActivityDebug", Category.DONUT);
        addSetting(yLevel);
        addSetting(notification);
    }

    @Override
    public void onDisable() {
        susChunks.clear();
        lastNotifiedAt.clear();
        doubleFields.clear();
        nestedFields.clear();
        blockPosFields.clear();
        vec3Fields.clear();
    }

    @Override
    public void onPacketReceive(class_2596<?> packet) {
        if (packet instanceof class_2637 sectionUpdate) {
            sectionUpdate.method_30621((pos, state) -> checkAndAdd(pos.method_10263(), pos.method_10264(), pos.method_10260()));
            return;
        }

        if (packet instanceof class_2626 blockUpdate) {
            class_2338 pos = blockUpdate.method_11309();
            checkAndAdd(pos.method_10263(), pos.method_10264(), pos.method_10260());
            return;
        }

        exploredObjects.get().clear();
        analyzeObject(packet, 0);
    }

    private void analyzeObject(Object obj, int depth) {
        if (obj == null || depth > 3) {
            return;
        }

        int hash = System.identityHashCode(obj);
        if (!exploredObjects.get().add(hash)) {
            return;
        }

        Class<?> clazz = obj.getClass();

        blockPosFields.computeIfAbsent(clazz, c -> getFieldsOfType(c, class_2338.class));
        vec3Fields.computeIfAbsent(clazz, c -> getFieldsOfType(c, class_243.class));
        doubleFields.computeIfAbsent(clazz, c -> getFieldsOfType(c, double.class));
        nestedFields.computeIfAbsent(clazz, c -> {
            List<Field> list = new ArrayList<>();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (!Modifier.isStatic(f.getModifiers())
                            && !f.getType().isPrimitive()
                            && !f.getType().getName().startsWith("java.")
                            && !f.getType().isEnum()) {
                        f.setAccessible(true);
                        list.add(f);
                    }
                }
                c = c.getSuperclass();
            }
            return list;
        });

        for (Field f : blockPosFields.get(clazz)) {
            try {
                class_2338 bp = (class_2338) f.get(obj);
                if (bp != null) {
                    checkAndAdd(bp.method_10263(), bp.method_10264(), bp.method_10260());
                }
            } catch (Exception ignored) {
            }
        }

        for (Field f : vec3Fields.get(clazz)) {
            try {
                class_243 v = (class_243) f.get(obj);
                if (v != null) {
                    checkAndAdd(v.field_1352, v.field_1351, v.field_1350);
                }
            } catch (Exception ignored) {
            }
        }

        List<Field> dFields = doubleFields.get(clazz);
        if (dFields.size() >= 3) {
            try {
                double x = dFields.get(0).getDouble(obj);
                double y = dFields.get(1).getDouble(obj);
                double z = dFields.get(2).getDouble(obj);
                if (Math.abs(x) < 3.0E7 && Math.abs(z) < 3.0E7 && y > -2048 && y < 2048) {
                    checkAndAdd(x, y, z);
                }
            } catch (Exception ignored) {
            }
        }

        for (Field f : nestedFields.get(clazz)) {
            try {
                Object nestedObj = f.get(obj);
                if (nestedObj != null) {
                    analyzeObject(nestedObj, depth + 1);
                }
            } catch (Exception ignored) {
            }
        }
    }

    private List<Field> getFieldsOfType(Class<?> clazz, Class<?> type) {
        List<Field> list = new ArrayList<>();
        while (clazz != null && clazz != Object.class) {
            for (Field f : clazz.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && f.getType() == type) {
                    f.setAccessible(true);
                    list.add(f);
                }
            }
            clazz = clazz.getSuperclass();
        }
        return list;
    }

    private void checkAndAdd(double x, double y, double z) {
        if (mc.field_1724 != null && mc.field_1724.method_23318() < 0.0D) {
            return;
        }
        if (y <= yLevel.getValue()) {
            class_1923 chunkPos = new class_1923((int) Math.floor(x) >> 4, (int) Math.floor(z) >> 4);
            if (susChunks.add(chunkPos)) {
                maybeNotify(chunkPos, y);
            }
        }
    }

    private void maybeNotify(class_1923 chunkPos, double y) {
        if (!notification.getValue() || mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        long chunkKey = chunkPos.method_8324();
        long now = System.currentTimeMillis();
        long last = lastNotifiedAt.getOrDefault(chunkKey, 0L);
        if (now - last < NOTIFY_COOLDOWN_MS) {
            return;
        }

        lastNotifiedAt.put(chunkKey, now);
        NotificationManager.INSTANCE.push(
                "Activity detected",
                "Chunk " + chunkPos.field_9181 + ", " + chunkPos.field_9180 + "  Y " + (int) Math.floor(y),
                new class_1799(class_1802.field_8251),
                YELLOW_OUTLINE.getRGB()
        );
        mc.field_1687.method_43128(
                mc.field_1724,
                mc.field_1724.method_23317(),
                mc.field_1724.method_23318(),
                mc.field_1724.method_23321(),
                class_3417.field_14627,
                class_3419.field_15250,
                0.6f,
                1.05f
        );
    }

    @Override
    public void onRender(class_4587 matrices, float tickDelta) {
        if (mc.field_1687 == null) {
            return;
        }

        class_4184 camera = RenderUtils.getCamera();
        if (camera == null) {
            return;
        }

        class_243 camPos = RenderUtils.getCameraPos(camera);
        double markerBaseY = Math.max(mc.field_1687.method_31607(), Math.min(MARKER_SURFACE_Y, mc.field_1687.method_31600()));
        RenderUtils.WorldBatch batch = RenderUtils.beginWorldBatch(matrices);
        for (class_1923 cp : susChunks) {
            if (!RenderUtils.isWorldBoxVisible(cp.method_8326(), MARKER_SURFACE_Y, cp.method_8328(), cp.method_8327(), MARKER_SURFACE_Y + MARKER_SURFACE_THICKNESS, cp.method_8329())) {
                continue;
            }
            double x1 = cp.method_8326() - camPos.field_1352;
            double z1 = cp.method_8328() - camPos.field_1350;
            double y1 = markerBaseY - camPos.field_1351;
            double x2 = x1 + 16.0D;
            double y2 = y1 + MARKER_SURFACE_THICKNESS;
            double z2 = z1 + 16.0D;

            batch.renderFilledBox(x1, y1, z1, x2, y2, z2, YELLOW);
        }
        batch.flush();
    }
}
