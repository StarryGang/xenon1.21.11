package com.xenon.mixin;

import com.xenon.module.ModuleManager;
import com.xenon.module.modules.render.NoRender;
import com.xenon.utils.RenderUtils;
import com.xenon.utils.renderer.ProjectionUtil;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMixin {

    private static final Matrix4f capturedMatrix = new Matrix4f();
    private static boolean hasCapturedMatrix;
    private static float capturedTickDelta = 1.0f;

    @Inject(method = "render", at = @At("HEAD"))
    private void captureRenderState(
            class_9922 allocator,
            class_9779 tickCounter,
            boolean renderBlockOutline,
            class_4184 camera,
            Matrix4f positionMatrix,
            Matrix4f projectionMatrix,
            Matrix4f frustumMatrix,
            GpuBufferSlice fog,
            Vector4f fogColor,
            boolean renderTicking,
            CallbackInfo ci
    ) {
        capturedMatrix.set(positionMatrix);
        ProjectionUtil.modelViewMatrix.set(positionMatrix);
        ProjectionUtil.positionMatrix.set(positionMatrix);
        ProjectionUtil.projectionMatrix.set(projectionMatrix);
        RenderUtils.updateFrustum(positionMatrix, projectionMatrix, camera.method_71156());
        hasCapturedMatrix = true;
        capturedTickDelta = tickCounter.method_60637(false);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void onRender(CallbackInfo ci) {
        if (hasCapturedMatrix) {
            class_4587 matrices = new class_4587();
            matrices.method_34425(capturedMatrix);
            ModuleManager.INSTANCE.onRender(matrices, capturedTickDelta);
        }
    }

    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true)
    private void xenon$skipWeatherPass(
            net.minecraft.class_9909 frameGraphBuilder,
            GpuBufferSlice fog,
            CallbackInfo ci
    ) {
        if (NoRender.hideAllPrecipitation()) {
            ci.cancel();
        }
    }
}               
