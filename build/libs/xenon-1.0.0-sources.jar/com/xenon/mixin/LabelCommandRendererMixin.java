package com.xenon.mixin;

import com.xenon.utils.NametagRenderState;
import net.minecraft.class_11689;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_4597;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_11689.class)
public class LabelCommandRendererMixin {

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/font/TextRenderer;draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)V",
                    ordinal = 1
            )
    )
    private void xenon$drawHealthLabelsWithOutline(
            class_327 textRenderer,
            class_2561 text,
            float x,
            float y,
            int color,
            boolean shadow,
            Matrix4f matrix,
            class_4597 consumers,
            class_327.class_6415 layerType,
            int backgroundColor,
            int light
    ) {
        if (!NametagRenderState.isOutlinedLabel(text)) {
            textRenderer.method_27522(text, x, y, color, shadow, matrix, consumers, layerType, backgroundColor, light);
            return;
        }

        textRenderer.method_37296(text.method_30937(), x, y, color, 0xFF000000, matrix, consumers, light);
    }
}
