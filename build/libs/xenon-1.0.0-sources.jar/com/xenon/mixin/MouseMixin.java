package com.xenon.mixin;

import com.xenon.module.modules.render.Freecam;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_408;
import com.xenon.gui.HudEditor;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {

    private static double toScaledX(class_310 mc, double rawX) {
        if (mc == null || mc.method_22683() == null) return rawX;
        double w = mc.method_22683().method_4480();
        if (w <= 0.0) return rawX;
        return rawX * (mc.method_22683().method_4486() / w);
    }

    private static double toScaledY(class_310 mc, double rawY) {
        if (mc == null || mc.method_22683() == null) return rawY;
        double h = mc.method_22683().method_4507();
        if (h <= 0.0) return rawY;
        return rawY * (mc.method_22683().method_4502() / h);
    }

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true, require = 0)
    private void xenon$hudEditorMouseButtonClick(long window, @Coerce Object click, int actionOrMods, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc == null || !(mc.field_1755 instanceof class_408)) return;
        if (!(click instanceof class_11909 c)) return;

        if (actionOrMods == 1) {
            if (HudEditor.INSTANCE.onMouseClick(c.comp_4798(), c.comp_4799(), c.method_74245())) {
                ci.cancel();
            }
        } else if (actionOrMods == 0) {
            HudEditor.INSTANCE.onMouseRelease();
        }
    }

    // HUD drag logic only — crash fix is handled by MouseCrashFixMixin
    @Inject(method = "onCursorPos", at = @At("HEAD"), require = 0)
    private void xenon$hudEditorCursorPos(long window, double x, double y, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        if (!(mc.field_1755 instanceof class_408)) return;
        if (!HudEditor.INSTANCE.isDragging()) return;

        if (GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS) {
            HudEditor.INSTANCE.onMouseRelease();
            return;
        }

        HudEditor.INSTANCE.onMouseDrag(toScaledX(mc, x), toScaledY(mc, y));
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void xenon$useScrollForFreecamSpeed(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (Freecam.instance == null || !Freecam.instance.isEnabled()) return;
        if (class_310.method_1551().field_1755 != null) return;

        double scrollAmount = vertical != 0.0 ? vertical : horizontal;
        if (scrollAmount == 0.0) return;

        Freecam.instance.adjustSpeed(scrollAmount);
        ci.cancel();
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void xenon$hudEditorMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc == null || !(mc.field_1755 instanceof class_408)) return;

        double amount = vertical != 0.0 ? vertical : horizontal;
        if (amount == 0.0) return;

        double sx = toScaledX(mc, mc.field_1729.method_1603());
        double sy = toScaledY(mc, mc.field_1729.method_1604());
        if (HudEditor.INSTANCE.onMouseScroll(sx, sy, amount)) {
            ci.cancel();
        }
    }
}