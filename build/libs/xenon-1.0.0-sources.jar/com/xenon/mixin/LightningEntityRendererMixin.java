package com.xenon.mixin;

import com.xenon.module.modules.render.NoRender;
import net.minecraft.class_10041;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_919.class)
public class LightningEntityRendererMixin {

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LightningEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void xenon$hideLightningEntity(
            class_10041 state,
            class_4587 matrices,
            class_11659 queue,
            class_12075 cameraRenderState,
            CallbackInfo ci
    ) {
        if (NoRender.hideThunder()) {
            ci.cancel();
        }
    }
}
