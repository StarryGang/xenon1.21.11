package com.xenon.mixin;

import com.xenon.module.modules.render.Freecam;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) {
        if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            class_746 self = (class_746) (Object) this;
            self.method_5660(false);
            self.method_5728(false);
        }
    }
}
