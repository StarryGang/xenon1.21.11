package com.xenon.mixin;

import com.xenon.module.modules.render.NoRender;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_9976.class)
public abstract class WeatherRenderingMixin {

    @Invoker("getPrecipitationAt")
    protected abstract class_1959.class_1963 xenon$getPrecipitationAt(class_1937 world, class_2338 pos);

    @Redirect(
            method = "buildPrecipitationPieces",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/WeatherRendering;getPrecipitationAt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"
            )
    )
    private class_1959.class_1963 xenon$filterRenderedPrecipitation(class_9976 instance, class_1937 world, class_2338 pos) {
        return NoRender.filterPrecipitation(xenon$getPrecipitationAt(world, pos));
    }

    @Redirect(
            method = "addParticlesAndSound",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/WeatherRendering;getPrecipitationAt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"
            )
    )
    private class_1959.class_1963 xenon$filterWeatherParticlesAndSounds(class_9976 instance, class_1937 world, class_2338 pos) {
        return NoRender.filterPrecipitation(xenon$getPrecipitationAt(world, pos));
    }
}
