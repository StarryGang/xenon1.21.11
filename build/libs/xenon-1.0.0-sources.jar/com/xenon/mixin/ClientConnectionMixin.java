package com.xenon.mixin;

import com.xenon.module.ModuleManager;
import io.netty.channel.ChannelFutureListener;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class ClientConnectionMixin {
    @Inject(method = "handlePacket", at = @At("HEAD"))
    private static void onHandlePacket(class_2596<?> packet, class_2547 listener, CallbackInfo ci) {
        try {
            ModuleManager.INSTANCE.onPacketReceive(packet);
        } catch (Exception e) {}
    }

    @Inject(
            method = "send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onSend(class_2596<?> packet, ChannelFutureListener callbacks, boolean flush, CallbackInfo ci) {
        try {
            if (ModuleManager.INSTANCE.onPacketSend(packet)) {
                ci.cancel();
            }
        } catch (Exception ignored) {
        }
    }
}
