package com.xenon.mixin;

import com.xenon.gui.HudEditor;
import com.xenon.module.modules.client.SpotifyHud;
import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public class ChatScreenMixin {

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void xenon$mouseClicked(class_11909 click, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();
        if (button == 0) {
            if (SpotifyHud.handleClick(mouseX, mouseY)) {
                cir.setReturnValue(true);
                return;
            }
            if (HudEditor.INSTANCE.onMouseClick(mouseX, mouseY, button)) {
                cir.setReturnValue(true);
                return;
            }
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void xenon$render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        HudEditor.INSTANCE.render(context, mouseX, mouseY);
    }
}
