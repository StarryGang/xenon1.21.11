package com.xenon.mixin;

import com.mojang.authlib.GameProfile;
import com.xenon.module.modules.misc.SkinChanger;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_640.class)
public abstract class PlayerListEntryMixin {

    @Shadow
    public abstract GameProfile getProfile();

    @Inject(method = "getSkinTextures", at = @At("HEAD"), cancellable = true)
    private void xenon$overrideListEntrySkin(CallbackInfoReturnable<class_8685> cir) {
        GameProfile profile = getProfile();
        if (profile == null || profile.id() == null) {
            return;
        }

        class_8685 override = SkinChanger.getOverrideSkin(profile.id());
        if (override != null) {
            cir.setReturnValue(override);
        }
    }
}
