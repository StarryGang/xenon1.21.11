package com.xenon.mixin;

import com.xenon.module.modules.render.Freecam;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public class KeyboardInputMixin {

    @Inject(method = "tick()V", at = @At("RETURN"))
    private void onTickReturn(CallbackInfo ci) {
        if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            InputAccessor input = (InputAccessor) this;
            input.xenon$setPlayerInput(new class_10185(false, false, false, false, false, false, false));
            input.xenon$setMovementVector(class_241.field_1340);
        }
    }
}
