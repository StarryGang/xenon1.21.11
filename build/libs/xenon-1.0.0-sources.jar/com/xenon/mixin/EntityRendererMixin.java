package com.xenon.mixin;

import com.xenon.module.modules.misc.NameTags;
import com.xenon.module.modules.combat.Hitbox;
import com.xenon.utils.NametagRenderState;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public class EntityRendererMixin {

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void xenon$updateNametagState(class_1297 entity, class_10017 state, float tickDelta, CallbackInfo ci) {
        if (!(entity instanceof class_1309 living) || !NameTags.isActive()) {
            NametagRenderState.clear(state);
            return;
        }

        NameTags module = NameTags.instance;
        if (module == null || !module.shouldRenderForState(living, state.field_53332) || state.field_53333) {
            NametagRenderState.clear(state);
            return;
        }

        NametagRenderState.mark(state);
    }

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"), cancellable = true)
    private void xenon$renderCustomNametag(
            class_10017 state,
            class_4587 matrices,
            class_11659 queue,
            class_12075 cameraRenderState,
            CallbackInfo ci
    ) {
        if (!NametagRenderState.hasEntry(state)) {
            return;
        }

        ci.cancel();
    }

    @Inject(method = "getShadowRadius", at = @At("RETURN"), cancellable = true)
    private void xenon$hitbox(class_10017 state, CallbackInfoReturnable<Float> cir) {
        Hitbox module = Hitbox.INSTANCE;
        if (module != null && module.isEnabled()) {
            cir.setReturnValue(cir.getReturnValue() + module.size.getValue());
        }
    }
}
