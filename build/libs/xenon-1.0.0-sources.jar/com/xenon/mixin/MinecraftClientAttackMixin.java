package com.xenon.mixin;

import com.xenon.module.modules.combat.SpearSwap;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientAttackMixin {

    @Inject(method = "handleInputEvents", at = @At("HEAD"), require = 0)
    private void xenon$preInput(CallbackInfo ci) {
        SpearSwap m = SpearSwap.INSTANCE;
        if (m == null || !m.isEnabled()) return;
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1690 == null) return;
        if (mc.field_1755 != null) return;
        if (mc.field_1690.field_1886.method_1434()) {
            m.preAttack();
        } else {
            m.noAttack();
        }
    }
}
