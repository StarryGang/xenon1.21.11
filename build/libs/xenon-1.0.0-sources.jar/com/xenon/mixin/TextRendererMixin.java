package com.xenon.mixin;

import com.xenon.utils.NameProtectUtil;
import net.minecraft.class_327;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_327.class)
public class TextRendererMixin {

    @ModifyVariable(
            method = "prepare(Ljava/lang/String;FFIZI)Lnet/minecraft/client/font/TextRenderer$GlyphDrawable;",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private String xenon$replacePreparedString(String text) {
        return NameProtectUtil.replace(text);
    }

    @ModifyVariable(
            method = "prepare(Lnet/minecraft/text/OrderedText;FFIZZI)Lnet/minecraft/client/font/TextRenderer$GlyphDrawable;",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_5481 xenon$replacePreparedOrderedText(class_5481 orderedText) {
        return NameProtectUtil.replace(orderedText);
    }

    @ModifyVariable(
            method = "drawWithOutline(Lnet/minecraft/text/OrderedText;FFIILorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_5481 xenon$replaceOutlinedOrderedText(class_5481 orderedText) {
        return NameProtectUtil.replace(orderedText);
    }

    @ModifyVariable(
            method = "getWidth(Ljava/lang/String;)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private String xenon$replaceWidthString(String text) {
        return NameProtectUtil.replace(text);
    }

    @ModifyVariable(
            method = "getWidth(Lnet/minecraft/text/StringVisitable;)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_5348 xenon$replaceWidthVisitable(class_5348 visitable) {
        return NameProtectUtil.replace(visitable);
    }

    @ModifyVariable(
            method = "getWidth(Lnet/minecraft/text/OrderedText;)I",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private class_5481 xenon$replaceWidthOrderedText(class_5481 orderedText) {
        return NameProtectUtil.replace(orderedText);
    }
}
