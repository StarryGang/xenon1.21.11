package com.xenon.mixin;

import com.xenon.module.modules.misc.SkinChanger;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {

    @Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
    private void xenon$overrideOwnSkin(CallbackInfoReturnable<class_8685> cir) {
        class_742 self = (class_742) (Object) this;
        class_8685 override = SkinChanger.getOverrideSkin(self.method_5667());
        if (override != null) {
            cir.setReturnValue(override);
        }
    }
}
