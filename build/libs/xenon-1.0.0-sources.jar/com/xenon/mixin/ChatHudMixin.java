package com.xenon.mixin;

import com.xenon.module.modules.misc.NameProtect;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_338.class)
public class ChatHudMixin {

    @ModifyVariable(method = "addMessage", 
                    at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private class_2561 modifyChatMessage(class_2561 message) {
        if (message != null && NameProtect.instance != null && NameProtect.instance.isEnabled()) {
            if (class_310.method_1551().method_1548() != null) {
                String name = class_310.method_1551().method_1548().method_1676();
                if (name != null) {
                    String str = message.getString();
                    if (str.contains(name)) {
                        // We replace the entire text with a literal string to replace the name
                        // A more advanced approach would walk the Text tree, but this works reliably for NameProtect in chat
                        return class_2561.method_43470(str.replace(name, NameProtect.instance.getFakeName()));
                    }
                }
            }
        }
        return message;
    }
}
