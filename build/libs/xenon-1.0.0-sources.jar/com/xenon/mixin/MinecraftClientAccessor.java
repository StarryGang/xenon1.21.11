package com.xenon.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown")
    int xenon$getItemUseCooldown();

    @Accessor("itemUseCooldown")
    void xenon$setItemUseCooldown(int cooldown);
}
