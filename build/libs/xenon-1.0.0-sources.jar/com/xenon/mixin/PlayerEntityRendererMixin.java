package com.xenon.mixin;

import com.xenon.utils.NametagRenderState;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class PlayerEntityRendererMixin {

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"), cancellable = true)
    private void xenon$renderPlayerNametag(
            class_10055 state,
            class_4587 matrices,
            class_11659 queue,
            class_12075 cameraRenderState,
            CallbackInfo ci
    ) {
        if (!NametagRenderState.hasEntry(state)) {
            return;
        }

        ci.cancel();
    }
}
