package com.xenon.mixin;

import com.xenon.module.modules.misc.SwingSpeed;
import net.minecraft.class_1268;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class LivingEntityMixin {

    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void onGetHandSwingDuration(CallbackInfoReturnable<Integer> cir) {
        SwingSpeed module = SwingSpeed.instance;
        if (module == null || !module.isEnabled()) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || (Object) this != client.field_1724) {
            return;
        }

        class_1309 self = (class_1309) (Object) this;
        class_1799 stack = self.method_5998(class_1268.field_5808);
        int baseDuration = stack.method_75218().comp_4976();
        if (class_1292.method_5576(self)) {
            baseDuration -= 1 + class_1292.method_5575(self);
        } else if (self.method_6059(class_1294.field_5901)) {
            baseDuration += (1 + self.method_6112(class_1294.field_5901).method_5578()) * 2;
        }

        float speed = module.getSwingSpeed();
        int adjustedDuration = Math.max(1, Math.round(baseDuration / speed));
        cir.setReturnValue(adjustedDuration);
    }
}
