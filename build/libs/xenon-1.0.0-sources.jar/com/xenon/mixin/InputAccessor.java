package com.xenon.mixin;

import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_744.class)
public interface InputAccessor {
    @Accessor("playerInput")
    void xenon$setPlayerInput(class_10185 playerInput);

    @Accessor("movementVector")
    void xenon$setMovementVector(class_241 movementVector);
}
