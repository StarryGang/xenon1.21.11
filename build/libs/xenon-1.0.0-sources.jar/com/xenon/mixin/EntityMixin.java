package com.xenon.mixin;

import com.xenon.module.modules.render.Freecam;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import com.xenon.module.modules.misc.Freelook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class EntityMixin {

    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void onChangeLookDirection(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        class_1297 self = (class_1297) (Object) this;
        if (self != class_310.method_1551().field_1724) {
            return;
        }

        if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            Freecam.instance.updateRotation(cursorDeltaX * 0.15D * Freecam.instance.getLookSensitivity(), cursorDeltaY * 0.15D * Freecam.instance.getLookSensitivity());
            ci.cancel();
            return;
        }

        if (Freelook.instance != null && Freelook.instance.isCameraActive()) {
            Freelook.instance.consumeMouseDelta(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }

    @Inject(method = "isSneaking", at = @At("HEAD"), cancellable = true)
    private void onIsSneaking(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            if ((Object) this == class_310.method_1551().field_1724) {
                cir.setReturnValue(false);
            }
        }
    }

    @Inject(method = "shouldRender(D)Z", at = @At("HEAD"), cancellable = true)
    private void onShouldRender(double distance, org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> cir) {
        if (Freecam.instance != null && Freecam.instance.isEnabled()) {
            // 10 chunks = 160 blocks. Squared: 25600.
            if (distance < 25600.0D) {
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void onGetDisplayName(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<net.minecraft.class_2561> cir) {
        if (com.xenon.module.modules.misc.NameProtect.instance != null && com.xenon.module.modules.misc.NameProtect.instance.isEnabled()) {
            if (class_310.method_1551().method_1548() != null) {
                String name = class_310.method_1551().method_1548().method_1676();
                if (name != null) {
                    net.minecraft.class_2561 returned = cir.getReturnValue();
                    if (returned != null) {
                        String str = returned.getString();
                        if (str.contains(name)) {
                            cir.setReturnValue(net.minecraft.class_2561.method_43470(str.replace(name, com.xenon.module.modules.misc.NameProtect.instance.getFakeName())));
                        }
                    }
                }
            }
        }
    }

    @Inject(method = "getName", at = @At("RETURN"), cancellable = true)
    private void onGetName(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<net.minecraft.class_2561> cir) {
        if (com.xenon.module.modules.misc.NameProtect.instance != null && com.xenon.module.modules.misc.NameProtect.instance.isEnabled()) {
            if (class_310.method_1551().method_1548() != null) {
                String name = class_310.method_1551().method_1548().method_1676();
                if (name != null) {
                    net.minecraft.class_2561 returned = cir.getReturnValue();
                    if (returned != null) {
                        String str = returned.getString();
                        if (str.contains(name)) {
                            cir.setReturnValue(net.minecraft.class_2561.method_43470(str.replace(name, com.xenon.module.modules.misc.NameProtect.instance.getFakeName())));
                        }
                    }
                }
            }
        }
    }
}
