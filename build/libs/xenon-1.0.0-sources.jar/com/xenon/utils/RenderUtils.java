package com.xenon.utils;

import com.xenon.utils.renderer.ProjectionUtil;
import java.util.LinkedHashMap;
import java.util.SequencedMap;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_310;
import net.minecraft.class_3545;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_9799;
import net.minecraft.class_9974;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.awt.Color;

public class RenderUtils {

    private static final Matrix4f POSITION_PROJECTION_MATRIX = new Matrix4f();
    private static final FrustumIntersection FRUSTUM = new FrustumIntersection();
    private static boolean frustumReady;
    private static double frustumX;
    private static double frustumY;
    private static double frustumZ;

    public static final class WorldBatch {
        private final class_4587 matrices;
        private final class_9799 allocator;
        private final class_4597.class_4598 immediate;
        private boolean dirty;
        private boolean closed;

        private WorldBatch(class_4587 matrices) {
            this.matrices = matrices;
            this.allocator = new class_9799(2 * 1024 * 1024); // 2 MiB
            this.immediate = class_4597.method_22991(this.allocator);
        }

        public void renderFilledBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
            class_4588 fillConsumer = immediate.method_73477(class_12249.method_76019());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

            class_4587.class_4665 entry = matrices.method_23760();
            float fx1 = (float) x1;
            float fy1 = (float) y1;
            float fz1 = (float) z1;
            float fx2 = (float) x2;
            float fy2 = (float) y2;
            float fz2 = (float) z2;

            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            dirty = true;
        }

        public void renderOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
            class_4588 lineConsumer = immediate.method_73477(class_12249.method_76015());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();
            class_9974.method_62296(matrices, lineConsumer, class_259.method_1081(x1, y1, z1, x2, y2, z2), 0, 0, 0, argb, 2.0f);
            dirty = true;
        }

        public void renderLine(Color color, class_243 start, class_243 end, float lineWidth) {
            class_4588 lineConsumer = immediate.method_73477(class_12249.method_76015());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

            class_4587.class_4665 entry = matrices.method_23760();
            Vector3f normal = new Vector3f(
                    (float) (end.field_1352 - start.field_1352),
                    (float) (end.field_1351 - start.field_1351),
                    (float) (end.field_1350 - start.field_1350)
            ).normalize();

            float width = Math.max(1.0f, lineWidth);
            lineConsumer.method_56824(entry, (float) start.field_1352, (float) start.field_1351, (float) start.field_1350).method_39415(argb).method_61959(entry, normal).method_75298(width);
            lineConsumer.method_56824(entry, (float) end.field_1352, (float) end.field_1351, (float) end.field_1350).method_39415(argb).method_61959(entry, normal).method_75298(width);
            dirty = true;
        }

        public void flush() {
            if (closed) return;
            try {
                if (dirty) {
                    org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);
                    immediate.method_22993();
                    org.lwjgl.opengl.GL11.glEnable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);
                    dirty = false;
                }
            } finally {
                allocator.close();
                closed = true;
            }
        }
    }

    /**
     * Fast-path batch for helper methods (renderOutlineBox/renderFilledBox/renderLine) to avoid allocating/closing
     * a new BufferAllocator on every single draw call.
     *
     * Semantics: still draws immediately (flush per call), just reuses the backing buffers.
     */
    private static final class ReusableWorldBatch {
        private final class_9799 allocator = new class_9799(512 * 1024); // 512 KiB
        private final class_4597.class_4598 immediate = class_4597.method_22991(this.allocator);
        private class_4587 matrices;
        private boolean dirty;

        void begin(class_4587 matrices) {
            this.matrices = matrices;
            this.dirty = false;
        }

        void renderFilledBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
            class_4588 fillConsumer = immediate.method_73477(class_12249.method_76019());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

            class_4587.class_4665 entry = matrices.method_23760();
            float fx1 = (float) x1;
            float fy1 = (float) y1;
            float fz1 = (float) z1;
            float fx2 = (float) x2;
            float fy2 = (float) y2;
            float fz2 = (float) z2;

            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);

            fillConsumer.method_56824(entry, fx1, fy1, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx1, fy1, fz1).method_39415(argb);

            fillConsumer.method_56824(entry, fx2, fy1, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz1).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy2, fz2).method_39415(argb);
            fillConsumer.method_56824(entry, fx2, fy1, fz2).method_39415(argb);
            dirty = true;
        }

        void renderOutlineBox(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
            class_4588 lineConsumer = immediate.method_73477(class_12249.method_76015());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();
            class_9974.method_62296(matrices, lineConsumer, class_259.method_1081(x1, y1, z1, x2, y2, z2), 0, 0, 0, argb, 2.0f);
            dirty = true;
        }

        void renderLine(Color color, class_243 start, class_243 end, float lineWidth) {
            class_4588 lineConsumer = immediate.method_73477(class_12249.method_76015());
            int argb = (color.getAlpha() << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

            class_4587.class_4665 entry = matrices.method_23760();
            Vector3f normal = new Vector3f(
                    (float) (end.field_1352 - start.field_1352),
                    (float) (end.field_1351 - start.field_1351),
                    (float) (end.field_1350 - start.field_1350)
            ).normalize();

            float width = Math.max(1.0f, lineWidth);
            lineConsumer.method_56824(entry, (float) start.field_1352, (float) start.field_1351, (float) start.field_1350).method_39415(argb).method_61959(entry, normal).method_75298(width);
            lineConsumer.method_56824(entry, (float) end.field_1352, (float) end.field_1351, (float) end.field_1350).method_39415(argb).method_61959(entry, normal).method_75298(width);
            dirty = true;
        }

        void flush() {
            if (!dirty) return;
            org.lwjgl.opengl.GL11.glDisable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);
            immediate.method_22993();
            org.lwjgl.opengl.GL11.glEnable(org.lwjgl.opengl.GL11.GL_DEPTH_TEST);
            dirty = false;
        }
    }

    private static final ThreadLocal<ReusableWorldBatch> REUSABLE_BATCH =
            ThreadLocal.withInitial(ReusableWorldBatch::new);

    public static WorldBatch beginWorldBatch(class_4587 matrices) {
        return new WorldBatch(matrices);
    }

    public static void updateFrustum(Matrix4f positionMatrix, Matrix4f projectionMatrix, class_243 cameraPos) {
        if (positionMatrix == null || projectionMatrix == null || cameraPos == null) {
            frustumReady = false;
            return;
        }

        projectionMatrix.mul(positionMatrix, POSITION_PROJECTION_MATRIX);
        FRUSTUM.set(POSITION_PROJECTION_MATRIX);
        frustumX = cameraPos.field_1352;
        frustumY = cameraPos.field_1351;
        frustumZ = cameraPos.field_1350;
        frustumReady = true;
    }

    public static boolean isWorldBoxVisible(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        if (!frustumReady) {
            return true;
        }

        float relMinX = (float) (minX - frustumX);
        float relMinY = (float) (minY - frustumY);
        float relMinZ = (float) (minZ - frustumZ);
        float relMaxX = (float) (maxX - frustumX);
        float relMaxY = (float) (maxY - frustumY);
        float relMaxZ = (float) (maxZ - frustumZ);
        int result = FRUSTUM.intersectAab(relMinX, relMinY, relMinZ, relMaxX, relMaxY, relMaxZ);
        return result == FrustumIntersection.INTERSECT || result == FrustumIntersection.INSIDE;
    }

    public static class_4184 getCamera() {
        return class_310.method_1551().field_1773.method_19418();
    }

    private static java.lang.reflect.Method cameraPosMethod;
    public static class_243 getCameraPos(class_4184 camera) {
        if (cameraPosMethod == null) {
            for (java.lang.reflect.Method m : class_4184.class.getMethods()) {
                if (m.getReturnType() == class_243.class && m.getParameterCount() == 0) {
                    cameraPosMethod = m;
                    break;
                }
            }
        }
        try {
            return (class_243) cameraPosMethod.invoke(camera);
        } catch (Exception e) {
            return class_310.method_1551().field_1724.method_5836(1.0f);
        }
    }

    public static void renderFilledBox(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        ReusableWorldBatch batch = REUSABLE_BATCH.get();
        batch.begin(matrices);
        batch.renderFilledBox(x1, y1, z1, x2, y2, z2, color);
        batch.flush();
    }

    public static void renderOutlineBox(class_4587 matrices, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        ReusableWorldBatch batch = REUSABLE_BATCH.get();
        batch.begin(matrices);
        batch.renderOutlineBox(x1, y1, z1, x2, y2, z2, color);
        batch.flush();
    }

    public static void renderLine(class_4587 matrices, Color color, class_243 start, class_243 end) {
        renderLine(matrices, color, start, end, 2.0f);
    }

    public static void renderLine(class_4587 matrices, Color color, class_243 start, class_243 end, float lineWidth) {
        ReusableWorldBatch batch = REUSABLE_BATCH.get();
        batch.begin(matrices);
        batch.renderLine(color, start, end, lineWidth);
        batch.flush();
    }

    public static class_243 getCameraForward(class_4184 camera) {
        return new class_243(0.0D, 0.0D, 1.0D)
                .method_1037(-(float) Math.toRadians(camera.method_19329()))
                .method_1024(-(float) Math.toRadians(camera.method_19330()))
                .method_1029();
    }

    public static class_243 getCameraRight(class_4184 camera) {
        return new class_243(1.0D, 0.0D, 0.0D)
                .method_1024(-(float) Math.toRadians(camera.method_19330()))
                .method_1029();
    }

    public static class_243 getCameraUp(class_243 cameraForward, class_243 cameraRight) {
        return cameraForward.method_1036(cameraRight).method_1029();
    }

    public static class_243 getSpreadTracerEnd(
            double targetX,
            double targetY,
            double targetZ,
            class_243 cameraForward,
            class_243 cameraRight,
            class_243 cameraUp,
            double endDistance,
            double behindMinSpread
    ) {
        double rightAmount = (targetX * cameraRight.field_1352) + (targetY * cameraRight.field_1351) + (targetZ * cameraRight.field_1350);
        double upAmount = (targetX * cameraUp.field_1352) + (targetY * cameraUp.field_1351) + (targetZ * cameraUp.field_1350);
        double forwardAmount = (targetX * cameraForward.field_1352) + (targetY * cameraForward.field_1351) + (targetZ * cameraForward.field_1350);
        double safeForward = Math.max(Math.abs(forwardAmount), 0.25D);
        double projectedRight = rightAmount / safeForward;
        double projectedUp = upAmount / safeForward;

        if (forwardAmount <= 0.0D) {
            double projectedLength = Math.hypot(projectedRight, projectedUp);
            if (projectedLength < behindMinSpread) {
                if (projectedLength < 1.0E-4D) {
                    projectedRight = behindMinSpread;
                    projectedUp = 0.0D;
                } else {
                    double scale = behindMinSpread / projectedLength;
                    projectedRight *= scale;
                    projectedUp *= scale;
                }
            }
        }

        return cameraForward
                .method_1019(cameraRight.method_1021(projectedRight))
                .method_1019(cameraUp.method_1021(projectedUp))
                .method_1029()
                .method_1021(endDistance);
    }

    public static class_243 getSpreadTracerEnd(
            class_243 target,
            class_243 cameraForward,
            class_243 cameraRight,
            class_243 cameraUp,
            double endDistance,
            double behindMinSpread
    ) {
        return getSpreadTracerEnd(target.field_1352, target.field_1351, target.field_1350, cameraForward, cameraRight, cameraUp, endDistance, behindMinSpread);
    }

    public static class_243 getClampedTracerEnd(
            class_243 cameraRelativeTarget,
            class_243 worldTarget,
            class_243 cameraForward,
            class_243 cameraRight,
            class_243 cameraUp,
            double projectionDistance
    ) {
        class_310 client = class_310.method_1551();
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        class_3545<class_243, Boolean> projection = ProjectionUtil.project(
                ProjectionUtil.modelViewMatrix,
                ProjectionUtil.projectionMatrix,
                worldTarget
        );
        if (projection != null && projection.method_15441()) {
            class_243 screenPos = projection.method_15442();
            if (screenPos.field_1352 >= 0.0D && screenPos.field_1352 <= screenWidth && screenPos.field_1351 >= 0.0D && screenPos.field_1351 <= screenHeight) {
                return cameraRelativeTarget;
            }
        }

        Vector3f edgePoint = ProjectionUtil.projectWithClamp(
                ProjectionUtil.modelViewMatrix,
                ProjectionUtil.projectionMatrix,
                worldTarget
        );
        if (edgePoint == null) {
            return cameraRelativeTarget;
        }

        return getRayToScreenPoint(edgePoint.x, edgePoint.y, screenWidth, screenHeight, cameraForward, cameraRight, cameraUp)
                .method_1021(projectionDistance);
    }

    private static class_243 getRayToScreenPoint(
            float screenX,
            float screenY,
            int screenWidth,
            int screenHeight,
            class_243 cameraForward,
            class_243 cameraRight,
            class_243 cameraUp
    ) {
        double ndcX = (screenX / screenWidth) * 2.0D - 1.0D;
        double ndcY = 1.0D - (screenY / screenHeight) * 2.0D;

        double aspect = ProjectionUtil.projectionMatrix.m11() / ProjectionUtil.projectionMatrix.m00();
        double tanHalfFov = 1.0D / ProjectionUtil.projectionMatrix.m11();

        return cameraForward
                .method_1019(cameraRight.method_1021(ndcX * aspect * tanHalfFov))
                .method_1019(cameraUp.method_1021(ndcY * tanHalfFov))
                .method_1029();
    }
}
