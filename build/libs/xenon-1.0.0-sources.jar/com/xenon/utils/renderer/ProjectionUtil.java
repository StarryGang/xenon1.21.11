package com.xenon.utils.renderer;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3545;
import net.minecraft.class_4184;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public class ProjectionUtil {

    public static final Matrix4f projectionMatrix = new Matrix4f();
    public static final Matrix4f modelViewMatrix = new Matrix4f();
    public static final Matrix4f positionMatrix = new Matrix4f();

    static class_310 mc = class_310.method_1551();

    public static final class ScreenProjection {
        public double x;
        public double y;
        public double z;
        public double w;
        public boolean visible;

        public void set(double x, double y, double z, double w, boolean visible) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.w = w;
            this.visible = visible;
        }
    }

    public static class_243 worldSpaceToScreenSpace(class_243 pos) {
        class_4184 camera = mc.method_1561().field_4686;
        int displayHeight = mc.method_22683().method_4507();
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        Vector3f target = new Vector3f();

        double deltaX = pos.field_1352 - camera.method_71156().field_1352;
        double deltaY = pos.field_1351 - camera.method_71156().field_1351;
        double deltaZ = pos.field_1350 - camera.method_71156().field_1350;

        Vector4f transformedCoordinates = new Vector4f((float) deltaX, (float) deltaY, (float) deltaZ, 1.f).mul(positionMatrix);

        Matrix4f matrixProj = new Matrix4f(projectionMatrix);
        Matrix4f matrixModel = new Matrix4f(modelViewMatrix);

        matrixProj.mul(matrixModel).project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);

        return new class_243(target.x / mc.method_22683().method_4495(), (displayHeight - target.y) / mc.method_22683().method_4495(), target.z);
    }

    public static class_3545<class_243, Boolean> project(Matrix4f modelView, Matrix4f projection, class_243 vector) {
        if (mc.field_1773 == null || mc.method_1560() == null) return null;

        ScreenProjection screenProjection = new ScreenProjection();
        if (!projectToScreen(modelView, projection, vector.field_1352, vector.field_1351, vector.field_1350, screenProjection)) {
            return null;
        }

        return new class_3545<>(new class_243(screenProjection.x, screenProjection.y, screenProjection.z), screenProjection.visible);
    }

    public static boolean projectToScreen(Matrix4f modelView, Matrix4f projection, double worldX, double worldY, double worldZ, ScreenProjection output) {
        if (mc.field_1773 == null || mc.method_1560() == null || output == null) {
            return false;
        }

        class_243 cameraPos = mc.field_1773.method_19418().method_71156();
        double relX = worldX - cameraPos.field_1352;
        double relY = worldY - cameraPos.field_1351;
        double relZ = worldZ - cameraPos.field_1350;

        double viewX = modelView.m00() * relX + modelView.m10() * relY + modelView.m20() * relZ + modelView.m30();
        double viewY = modelView.m01() * relX + modelView.m11() * relY + modelView.m21() * relZ + modelView.m31();
        double viewZ = modelView.m02() * relX + modelView.m12() * relY + modelView.m22() * relZ + modelView.m32();
        double viewW = modelView.m03() * relX + modelView.m13() * relY + modelView.m23() * relZ + modelView.m33();

        double clipX = projection.m00() * viewX + projection.m10() * viewY + projection.m20() * viewZ + projection.m30() * viewW;
        double clipY = projection.m01() * viewX + projection.m11() * viewY + projection.m21() * viewZ + projection.m31() * viewW;
        double clipZ = projection.m02() * viewX + projection.m12() * viewY + projection.m22() * viewZ + projection.m32() * viewW;
        double clipW = projection.m03() * viewX + projection.m13() * viewY + projection.m23() * viewZ + projection.m33() * viewW;

        boolean isVisible = clipW > 0.0;
        double invW = clipW != 0.0 ? 1.0 / clipW : 0.0;
        double ndcX = clipX * invW;
        double ndcY = clipY * invW;
        double ndcZ = clipZ * invW;

        double screenX = (ndcX * 0.5 + 0.5) * mc.method_22683().method_4486();
        double screenY = (0.5 - ndcY * 0.5) * mc.method_22683().method_4502();

        output.set(screenX, screenY, ndcZ, clipW, isVisible);
        return true;
    }

    public static Vector3f projectVector(Matrix4f modelView, Matrix4f projection, class_243 vector) {
        class_3545<class_243, Boolean> result = project(modelView, projection, vector);
        if (result == null) return null;
        class_243 pos = result.method_15442();
        return new Vector3f((float) pos.field_1352, (float) pos.field_1351, (float) pos.field_1350);
    }

    public static Vector3f project(double x, double y, double z) {
        if (mc.field_1773 == null || mc.method_1560() == null) return null;
        return project(new class_243(x, y, z));
    }

    public static Vector3f project(class_243 vector) {
        if (mc.field_1773 == null || mc.method_1560() == null) return null;
        class_243 result = worldSpaceToScreenSpace(vector);
        if (result.field_1350 < 0 || result.field_1350 > 1) return null;
        return new Vector3f((float) result.field_1352, (float) result.field_1351, (float) result.field_1350);
    }

    public static Vector3f projectWithClamp(Matrix4f modelView, Matrix4f projection, class_243 vector) {
        if (mc.field_1773 == null || mc.method_1560() == null) return null;

        class_243 camPos = vector.method_1020(mc.field_1773.method_19418().method_71156());
        if (camPos.method_1027() < 0.0001) {
            return new Vector3f(mc.method_22683().method_4486() / 2f, mc.method_22683().method_4502() / 2f, 0);
        }
        Vector4f vec = new Vector4f((float) camPos.field_1352, (float) camPos.field_1351, (float) camPos.field_1350, 1F);

        vec.mul(modelView);
        vec.mul(projection);

        boolean isBehind = vec.w() <= 0.0f;

        float w = Math.abs(vec.w());
        if (w < 0.001f) w = 0.001f;

        float nX = vec.x() / w;
        float nY = vec.y() / w;

        float screenWidth = mc.method_22683().method_4486();
        float screenHeight = mc.method_22683().method_4502();
        float centerX = screenWidth / 2f;
        float centerY = screenHeight / 2f;

        float screenX = (nX * 0.5f + 0.5f) * screenWidth;
        float screenY = (0.5f - nY * 0.5f) * screenHeight;

        if (!isBehind && screenX >= 0 && screenX <= screenWidth && screenY >= 0 && screenY <= screenHeight) {
            return new Vector3f(screenX, screenY, 0);
        }

        float dirX = screenX - centerX;
        float dirY = screenY - centerY;

        if (dirX == 0 && dirY == 0) {
            dirY = 1;
        }

        float margin = 10f;
        float halfW = screenWidth / 2f - margin;
        float halfH = screenHeight / 2f - margin;

        float kX = Float.MAX_VALUE;
        float kY = Float.MAX_VALUE;

        if (dirX != 0) kX = Math.abs(halfW / dirX);
        if (dirY != 0) kY = Math.abs(halfH / dirY);

        float k = Math.min(kX, kY);

        return new Vector3f(centerX + dirX * k, centerY + dirY * k, 0);
    }
}
