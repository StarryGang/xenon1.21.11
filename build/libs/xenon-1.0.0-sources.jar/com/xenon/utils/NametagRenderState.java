package com.xenon.utils;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_10017;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;

public final class NametagRenderState {

    private static final Set<class_10017> OVERRIDDEN_LABELS = Collections.newSetFromMap(new WeakHashMap<>());

    private NametagRenderState() {
    }

    public static void clear(class_10017 state) {
        OVERRIDDEN_LABELS.remove(state);
    }

    public static void mark(class_10017 state) {
        OVERRIDDEN_LABELS.add(state);
    }

    public static boolean hasEntry(class_10017 state) {
        return OVERRIDDEN_LABELS.contains(state);
    }

    public static boolean isOutlinedLabel(class_2561 text) {
        return false;
    }

    public record ItemEntry(class_1799 stack) {
    }

    public record Entry(
            Object entity,
            class_243 labelPos,
            class_2561 nameLabel,
            class_2561 healthLabel,
            List<ItemEntry> items
    ) {
    }
}
