package com.xenon.utils;

import com.xenon.module.modules.misc.NameProtect;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public final class NameProtectUtil {

    private NameProtectUtil() {
    }

    public static String replace(String text) {
        if (text == null || !isActive()) {
            return text;
        }

        String realName = getRealName();
        String fakeName = getFakeName();
        if (realName == null || fakeName == null || realName.isBlank() || realName.equals(fakeName)) {
            return text;
        }

        return text.contains(realName) ? text.replace(realName, fakeName) : text;
    }

    public static class_5348 replace(class_5348 visitable) {
        if (visitable == null || !isActive()) {
            return visitable;
        }

        List<StyledChunk> replaced = replaceChunks(collect(visitable));
        if (replaced == null) {
            return visitable;
        }

        if (replaced.isEmpty()) {
            return class_5348.field_25310;
        }

        List<class_5348> parts = new ArrayList<>(replaced.size());
        for (StyledChunk chunk : replaced) {
            parts.add(class_5348.method_29431(chunk.text(), chunk.style()));
        }
        return class_5348.method_29432(parts);
    }

    public static class_5481 replace(class_5481 orderedText) {
        if (orderedText == null || !isActive()) {
            return orderedText;
        }

        List<StyledChunk> replaced = replaceChunks(collect(orderedText));
        if (replaced == null) {
            return orderedText;
        }

        if (replaced.isEmpty()) {
            return class_5481.method_34905();
        }

        List<class_5481> parts = new ArrayList<>(replaced.size());
        for (StyledChunk chunk : replaced) {
            parts.add(class_5481.method_30747(chunk.text(), chunk.style()));
        }
        return class_5481.method_30749(parts);
    }

    private static boolean isActive() {
        return NameProtect.instance != null
                && NameProtect.instance.isEnabled()
                && getRealName() != null
                && !getRealName().isBlank();
    }

    private static String getRealName() {
        class_310 client = class_310.method_1551();
        if (client == null || client.method_1548() == null) {
            return null;
        }
        return client.method_1548().method_1676();
    }

    private static String getFakeName() {
        if (NameProtect.instance == null) {
            return null;
        }
        return NameProtect.instance.getFakeName();
    }

    private static List<StyledChunk> collect(class_5348 visitable) {
        List<StyledChunk> chunks = new ArrayList<>();
        visitable.method_27658((style, text) -> {
            appendCodePoints(chunks, text, style);
            return Optional.empty();
        }, class_2583.field_24360);
        return chunks;
    }

    private static List<StyledChunk> collect(class_5481 orderedText) {
        List<StyledChunk> chunks = new ArrayList<>();
        orderedText.accept((index, style, codePoint) -> {
            chunks.add(new StyledChunk(new String(Character.toChars(codePoint)), style));
            return true;
        });
        return chunks;
    }

    private static void appendCodePoints(List<StyledChunk> chunks, String text, class_2583 style) {
        if (text == null || text.isEmpty()) {
            return;
        }

        for (int offset = 0; offset < text.length(); ) {
            int codePoint = text.codePointAt(offset);
            chunks.add(new StyledChunk(new String(Character.toChars(codePoint)), style));
            offset += Character.charCount(codePoint);
        }
    }

    private static List<StyledChunk> replaceChunks(List<StyledChunk> chunks) {
        String realName = getRealName();
        String fakeName = getFakeName();
        if (realName == null || fakeName == null || realName.isBlank() || realName.equals(fakeName)) {
            return null;
        }

        StringBuilder plainBuilder = new StringBuilder();
        List<Integer> chunkStarts = new ArrayList<>(chunks.size());
        for (StyledChunk chunk : chunks) {
            chunkStarts.add(plainBuilder.length());
            plainBuilder.append(chunk.text());
        }

        String plain = plainBuilder.toString();
        if (!plain.contains(realName)) {
            return null;
        }

        List<StyledChunk> replaced = new ArrayList<>();
        int chunkIndex = 0;
        int searchFrom = 0;
        int matchIndex;
        while ((matchIndex = plain.indexOf(realName, searchFrom)) >= 0) {
            while (chunkIndex < chunks.size() && chunkStarts.get(chunkIndex) < matchIndex) {
                replaced.add(chunks.get(chunkIndex++));
            }

            class_2583 style = chunkIndex < chunks.size() ? chunks.get(chunkIndex).style() : class_2583.field_24360;
            replaced.add(new StyledChunk(fakeName, style));

            int matchEnd = matchIndex + realName.length();
            while (chunkIndex < chunks.size() && chunkStarts.get(chunkIndex) < matchEnd) {
                chunkIndex++;
            }
            searchFrom = matchEnd;
        }

        while (chunkIndex < chunks.size()) {
            replaced.add(chunks.get(chunkIndex++));
        }

        return merge(replaced);
    }

    private static List<StyledChunk> merge(List<StyledChunk> chunks) {
        if (chunks.isEmpty()) {
            return chunks;
        }

        List<StyledChunk> merged = new ArrayList<>(chunks.size());
        StyledChunk current = chunks.getFirst();
        for (int i = 1; i < chunks.size(); i++) {
            StyledChunk next = chunks.get(i);
            if (Objects.equals(current.style(), next.style())) {
                current = new StyledChunk(current.text() + next.text(), current.style());
                continue;
            }
            merged.add(current);
            current = next;
        }
        merged.add(current);
        return merged;
    }

    private record StyledChunk(String text, class_2583 style) {
        private StyledChunk {
            style = style == null ? class_2583.field_24360 : style;
        }
    }
}
