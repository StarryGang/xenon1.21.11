package com.xenon.utils;

import com.xenon.module.modules.donut.FakeRoles;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public final class FakeRolesUtil {
   private FakeRolesUtil() {
   }

   public static String replace(String text) {
      if (text != null && FakeRoles.isActive()) {
         String realName = getRealName();
         if (realName == null || realName.isBlank()) {
            return text;
         } else if (!text.contains(realName)) {
            return text;
         } else {
            String prefixed = FakeRoles.getPrefixedNameString();
            return prefixed != null && !prefixed.equals(realName) ? text.replace(realName, prefixed) : text;
         }
      } else {
         return text;
      }
   }

   public static class_5481 replace(class_5481 orderedText) {
      if (orderedText != null && FakeRoles.isActive()) {
         List<FakeRolesUtil.StyledChar> replaced = replaceChunks(collectOrdered(orderedText));
         if (replaced == null) {
            return orderedText;
         } else if (replaced.isEmpty()) {
            return class_5481.method_34905();
         } else {
            List<class_5481> parts = new ArrayList<>(replaced.size());

            for (FakeRolesUtil.StyledChar sc : replaced) {
               parts.add(class_5481.method_30747(sc.text(), sc.style()));
            }

            return class_5481.method_30749(parts);
         }
      } else {
         return orderedText;
      }
   }

   public static class_5348 replace(class_5348 visitable) {
      if (visitable != null && FakeRoles.isActive()) {
         List<FakeRolesUtil.StyledChar> replaced = replaceChunks(collectVisitable(visitable));
         if (replaced == null) {
            return visitable;
         } else if (replaced.isEmpty()) {
            return class_5348.field_25310;
         } else {
            List<class_5348> parts = new ArrayList<>(replaced.size());

            for (FakeRolesUtil.StyledChar sc : replaced) {
               parts.add(class_5348.method_29431(sc.text(), sc.style()));
            }

            return class_5348.method_29432(parts);
         }
      } else {
         return visitable;
      }
   }

   private static String getRealName() {
      class_310 client = class_310.method_1551();
      return client != null && client.method_1548() != null ? client.method_1548().method_1676() : null;
   }

   private static List<FakeRolesUtil.StyledChar> collectOrdered(class_5481 orderedText) {
      List<FakeRolesUtil.StyledChar> chars = new ArrayList<>();
      orderedText.accept((index, style, codePoint) -> {
         chars.add(new FakeRolesUtil.StyledChar(new String(Character.toChars(codePoint)), style));
         return true;
      });
      return chars;
   }

   private static List<FakeRolesUtil.StyledChar> collectVisitable(class_5348 visitable) {
      List<FakeRolesUtil.StyledChar> chars = new ArrayList<>();
      visitable.method_27658((style, text) -> {
         int i = 0;

         while (i < text.length()) {
            int cp = text.codePointAt(i);
            chars.add(new FakeRolesUtil.StyledChar(new String(Character.toChars(cp)), style));
            i += Character.charCount(cp);
         }

         return Optional.empty();
      }, class_2583.field_24360);
      return chars;
   }

   private static List<FakeRolesUtil.StyledChar> replaceChunks(List<FakeRolesUtil.StyledChar> chars) {
      String realName = getRealName();
      if (realName != null && !realName.isBlank()) {
         String prefixString = FakeRoles.getRolePrefixString();
         if (prefixString == null) {
            return null;
         } else {
            StringBuilder plain = new StringBuilder();
            List<Integer> charStarts = new ArrayList<>(chars.size());

            for (FakeRolesUtil.StyledChar sc : chars) {
               charStarts.add(plain.length());
               plain.append(sc.text());
            }

            String plainStr = plain.toString();
            if (!plainStr.contains(realName)) {
               return null;
            } else {
               class_2583 nameStyle = FakeRoles.getRoleNameStyle();
               List<FakeRolesUtil.StyledChar> result = new ArrayList<>();
               int chunkIndex = 0;
               int searchFrom = 0;

               int matchIndex;
               while ((matchIndex = plainStr.indexOf(realName, searchFrom)) >= 0) {
                  while (chunkIndex < chars.size() && charStarts.get(chunkIndex) < matchIndex) {
                     result.add(chars.get(chunkIndex++));
                  }

                  int i = 0;

                  while (i < prefixString.length()) {
                     int cp = prefixString.codePointAt(i);
                     result.add(new FakeRolesUtil.StyledChar(new String(Character.toChars(cp)), FakeRoles.getRolePrefixStyleForChar(cp)));
                     i += Character.charCount(cp);
                  }

                  i = 0;

                  while (i < realName.length()) {
                     int cp = realName.codePointAt(i);
                     result.add(new FakeRolesUtil.StyledChar(new String(Character.toChars(cp)), nameStyle));
                     i += Character.charCount(cp);
                  }

                  i = matchIndex + realName.length();

                  while (chunkIndex < chars.size() && charStarts.get(chunkIndex) < i) {
                     chunkIndex++;
                  }

                  searchFrom = i;
               }

               while (chunkIndex < chars.size()) {
                  result.add(chars.get(chunkIndex++));
               }

               return merge(result);
            }
         }
      } else {
         return null;
      }
   }

   private static List<FakeRolesUtil.StyledChar> merge(List<FakeRolesUtil.StyledChar> chars) {
      if (chars.isEmpty()) {
         return chars;
      } else {
         List<FakeRolesUtil.StyledChar> merged = new ArrayList<>(chars.size());
         FakeRolesUtil.StyledChar current = chars.getFirst();

         for (int i = 1; i < chars.size(); i++) {
            FakeRolesUtil.StyledChar next = chars.get(i);
            if (Objects.equals(current.style(), next.style())) {
               current = new FakeRolesUtil.StyledChar(current.text() + next.text(), current.style());
            } else {
               merged.add(current);
               current = next;
            }
         }

         merged.add(current);
         return merged;
      }
   }

   private static record StyledChar(String text, class_2583 style) {
      private StyledChar(String text, class_2583 style) {
         style = style == null ? class_2583.field_24360 : style;
         this.text = text;
         this.style = style;
      }
   }
}
