package com.xenon.setting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class BlocksSetting extends Setting<Set<class_2248>> {

    private final List<class_2248> availableBlocks;
    private long version;

    public BlocksSetting(String name, class_2248... defaults) {
        super(name, createDefaultSet(defaults));
        this.availableBlocks = class_7923.field_41175.method_10220()
                .filter(block -> block != class_2246.field_10124)
                .sorted(Comparator.comparing(this::getDisplayName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    @Override
    public void setValue(Set<class_2248> value) {
        LinkedHashSet<class_2248> next = new LinkedHashSet<>();
        if (value != null) {
            for (class_2248 block : value) {
                if (block != null && block != class_2246.field_10124) {
                    next.add(block);
                }
            }
        }

        super.setValue(next);
        version++;
    }

    public boolean contains(class_2248 block) {
        return block != null && getValue().contains(block);
    }

    public void toggle(class_2248 block) {
        if (block == null || block == class_2246.field_10124) {
            return;
        }

        LinkedHashSet<class_2248> next = new LinkedHashSet<>(getValue());
        if (!next.add(block)) {
            next.remove(block);
        }
        setValue(next);
    }

    public void clear() {
        if (getValue().isEmpty()) {
            return;
        }
        setValue(Collections.emptySet());
    }

    public int size() {
        return getValue().size();
    }

    public long getVersion() {
        return version;
    }

    public Set<class_2248> getSelectedBlocks() {
        return Collections.unmodifiableSet(getValue());
    }

    public List<class_2248> getAvailableBlocks() {
        return availableBlocks;
    }

    public List<class_2248> filter(String query) {
        String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (normalized.isEmpty()) {
            return availableBlocks;
        }

        List<class_2248> filtered = new ArrayList<>();
        for (class_2248 block : availableBlocks) {
            String displayName = getDisplayName(block).toLowerCase(Locale.ROOT);
            class_2960 id = class_7923.field_41175.method_10221(block);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (displayName.contains(normalized) || idString.contains(normalized)) {
                filtered.add(block);
            }
        }
        return filtered;
    }

    public String getDisplayName(class_2248 block) {
        try {
            return block.method_9518().getString();
        } catch (Exception ignored) {
            class_2960 id = class_7923.field_41175.method_10221(block);
            return id == null ? "Block" : id.method_12832();
        }
    }

    public String getSummary() {
        if (getValue().isEmpty()) {
            return "None";
        }

        class_2248 first = getValue().iterator().next();
        String firstName = getDisplayName(first);
        int extra = getValue().size() - 1;
        return extra > 0 ? firstName + " +" + extra : firstName;
    }

    private static Set<class_2248> createDefaultSet(class_2248... defaults) {
        LinkedHashSet<class_2248> selected = new LinkedHashSet<>();
        if (defaults != null) {
            Collections.addAll(selected, defaults);
            selected.remove(null);
            selected.remove(class_2246.field_10124);
        }
        return selected;
    }
}
