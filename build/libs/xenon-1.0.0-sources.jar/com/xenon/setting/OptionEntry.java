package com.xenon.setting;

import net.minecraft.class_1799;

public record OptionEntry(String value, String label, class_1799 previewStack) {
    public class_1799 getPreviewStack() {
        return previewStack == null ? class_1799.field_8037 : previewStack.method_7972();
    }
}
