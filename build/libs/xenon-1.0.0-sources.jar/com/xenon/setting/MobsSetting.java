package com.xenon.setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class MobsSetting extends Setting<Set<class_1299<?>>> {

    private final List<class_1299<?>> availableMobs;
    private long version;

    public MobsSetting(String name, class_1299<?>... defaults) {
        super(name, createDefaultSet(defaults));
        this.availableMobs = class_7923.field_41177.method_10220()
                .filter(MobsSetting::isLivingMob)
                .sorted(Comparator.comparing(this::getDisplayName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    private static boolean isLivingMob(class_1299<?> type) {
        class_1311 g = type.method_5891();
        return g == class_1311.field_6302
                || g == class_1311.field_6294
                || g == class_1311.field_6303
                || g == class_1311.field_34447
                || g == class_1311.field_30092
                || g == class_1311.field_6300
                || g == class_1311.field_24460;
    }

    @Override
    public void setValue(Set<class_1299<?>> value) {
        LinkedHashSet<class_1299<?>> next = new LinkedHashSet<>();
        if (value != null) {
            for (class_1299<?> t : value) {
                if (t != null) next.add(t);
            }
        }
        super.setValue(next);
        version++;
    }

    public boolean contains(class_1299<?> type) {
        return type != null && getValue().contains(type);
    }

    public void toggle(class_1299<?> type) {
        if (type == null) return;
        LinkedHashSet<class_1299<?>> next = new LinkedHashSet<>(getValue());
        if (!next.add(type)) next.remove(type);
        setValue(next);
    }

    public void clear() {
        if (getValue().isEmpty()) return;
        setValue(Collections.emptySet());
    }

    public int size() { return getValue().size(); }
    public long getVersion() { return version; }

    public Set<class_1299<?>> getSelectedMobs() {
        return Collections.unmodifiableSet(getValue());
    }

    public List<class_1299<?>> getAvailableMobs() { return availableMobs; }

    public List<class_1299<?>> filter(String query) {
        String normalized = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (normalized.isEmpty()) return availableMobs;
        List<class_1299<?>> filtered = new ArrayList<>();
        for (class_1299<?> t : availableMobs) {
            String displayName = getDisplayName(t).toLowerCase(Locale.ROOT);
            class_2960 id = class_7923.field_41177.method_10221(t);
            String idString = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
            if (displayName.contains(normalized) || idString.contains(normalized)) {
                filtered.add(t);
            }
        }
        return filtered;
    }

    public String getDisplayName(class_1299<?> type) {
        try {
            return type.method_5897().getString();
        } catch (Exception ignored) {
            class_2960 id = class_7923.field_41177.method_10221(type);
            return id == null ? "Mob" : id.method_12832();
        }
    }

    public String getSummary() {
        if (getValue().isEmpty()) return "None";
        class_1299<?> first = getValue().iterator().next();
        String firstName = getDisplayName(first);
        int extra = getValue().size() - 1;
        return extra > 0 ? firstName + " +" + extra : firstName;
    }

    private static Set<class_1299<?>> createDefaultSet(class_1299<?>... defaults) {
        LinkedHashSet<class_1299<?>> selected = new LinkedHashSet<>();
        if (defaults != null) {
            Collections.addAll(selected, defaults);
            selected.remove(null);
        }
        return selected;
    }
}
