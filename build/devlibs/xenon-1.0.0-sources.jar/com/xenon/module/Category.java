package com.xenon.module;

public enum Category {
    MISC("Misc"),
    RENDER("Render"),
    COMBAT("Combat"),
    DONUT("Donut"),
    CLIENT("Client");

    private final String name;

    Category(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
